/********************************************************************************
** Form generated from reading UI file 'dialog_dcb.ui'
**
** Created: Mon Aug 10 11:27:57 2020
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_DCB_H
#define UI_DIALOG_DCB_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QSpacerItem>
#include <QtGui/QTabWidget>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_dialog_dcb
{
public:
    QGridLayout *gridLayout;
    QTabWidget *tab_dcb;
    QWidget *DCB1;
    QGridLayout *gridLayout_22;
    QSpacerItem *horizontalSpacer_54;
    QLabel *label_118;
    QSpacerItem *horizontalSpacer_50;
    QLabel *label_125;
    QSpacerItem *horizontalSpacer_49;
    QLabel *label_126;
    QSpacerItem *horizontalSpacer_53;
    QLabel *label_117;
    QSpacerItem *horizontalSpacer_51;
    QLabel *label_124;
    QSpacerItem *horizontalSpacer_52;
    QLabel *label_114;
    QLabel *fpga1_con_dcb_1;
    QLabel *fpga2_con_dcb_1;
    QLabel *fpga3_con_dcb_1;
    QLabel *fpga4_con_dcb_1;
    QLabel *fpga5_con_dcb_1;
    QLabel *label_121;
    QLabel *fpga1_hlt_dcb_1;
    QLabel *fpga2_hlt_dcb_1;
    QLabel *fpga3_hlt_dcb_1;
    QLabel *fpga4_hlt_dcb_1;
    QLabel *fpga5_hlt_dcb_1;
    QLabel *label_119;
    QLabel *fpga1_rdy_dcb_1;
    QLabel *fpga2_rdy_dcb_1;
    QLabel *fpga3_rdy_dcb_1;
    QLabel *fpga4_rdy_dcb_1;
    QLabel *fpga5_rdy_dcb_1;
    QLabel *label_116;
    QLabel *fpga1_d18_dcb_1;
    QLabel *fpga2_d18_dcb_1;
    QLabel *fpga3_d18_dcb_1;
    QLabel *fpga4_d18_dcb_1;
    QLabel *fpga5_d18_dcb_1;
    QLabel *label_127;
    QLabel *fpga1_d25_dcb_1;
    QLabel *fpga2_d25_dcb_1;
    QLabel *fpga3_d25_dcb_1;
    QLabel *fpga4_d25_dcb_1;
    QLabel *fpga5_d25_dcb_1;
    QLabel *label_120;
    QLabel *fpga1_d33_dcb_1;
    QLabel *fpga2_d33_dcb_1;
    QLabel *fpga3_d33_dcb_1;
    QLabel *fpga4_d33_dcb_1;
    QLabel *fpga5_d33_dcb_1;
    QLabel *label_123;
    QLabel *fpga1_d5_dcb_1;
    QLabel *fpga2_d5_dcb_1;
    QLabel *fpga3_d5_dcb_1;
    QLabel *fpga4_d5_dcb_1;
    QLabel *fpga5_d5_dcb_1;
    QLabel *label_115;
    QLabel *fpga1_a18_dcb_1;
    QLabel *fpga2_a18_dcb_1;
    QLabel *fpga3_a18_dcb_1;
    QLabel *fpga4_a18_dcb_1;
    QLabel *fpga5_a18_dcb_1;
    QLabel *label_122;
    QLabel *fpga1_a33_dcb_1;
    QLabel *fpga2_a33_dcb_1;
    QLabel *fpga3_a33_dcb_1;
    QLabel *fpga4_a33_dcb_1;
    QLabel *fpga5_a33_dcb_1;
    QWidget *DCB2;
    QGridLayout *gridLayout_16;
    QLabel *label_34;
    QSpacerItem *horizontalSpacer_14;
    QLabel *label_39;
    QSpacerItem *horizontalSpacer_12;
    QLabel *label_40;
    QSpacerItem *horizontalSpacer_17;
    QLabel *label_16;
    QSpacerItem *horizontalSpacer_15;
    QLabel *label_8;
    QSpacerItem *horizontalSpacer_16;
    QLabel *label_14;
    QLabel *fpga1_con_dcb_2;
    QLabel *fpga2_con_dcb_2;
    QLabel *fpga3_con_dcb_2;
    QLabel *fpga4_con_dcb_2;
    QLabel *fpga5_con_dcb_2;
    QLabel *label_43;
    QLabel *fpga1_hlt_dcb_2;
    QLabel *fpga2_hlt_dcb_2;
    QLabel *fpga3_hlt_dcb_2;
    QLabel *fpga4_hlt_dcb_2;
    QLabel *fpga5_hlt_dcb_2;
    QLabel *label_35;
    QLabel *fpga1_rdy_dcb_2;
    QLabel *fpga2_rdy_dcb_2;
    QLabel *fpga3_rdy_dcb_2;
    QLabel *fpga4_rdy_dcb_2;
    QLabel *fpga5_rdy_dcb_2;
    QLabel *label_33;
    QLabel *fpga1_d18_dcb_2;
    QLabel *fpga2_d18_dcb_2;
    QLabel *fpga3_d18_dcb_2;
    QLabel *fpga4_d18_dcb_2;
    QLabel *fpga5_d18_dcb_2;
    QLabel *label_41;
    QLabel *fpga1_d25_dcb_2;
    QLabel *fpga2_d25_dcb_2;
    QLabel *fpga3_d25_dcb_2;
    QLabel *fpga4_d25_dcb_2;
    QLabel *fpga5_d25_dcb_2;
    QLabel *label_36;
    QLabel *fpga1_d33_dcb_2;
    QLabel *fpga2_d33_dcb_2;
    QLabel *fpga3_d33_dcb_2;
    QLabel *fpga4_d33_dcb_2;
    QLabel *fpga5_d33_dcb_2;
    QLabel *label_38;
    QLabel *fpga1_d5_dcb_2;
    QLabel *fpga2_d5_dcb_2;
    QLabel *fpga3_d5_dcb_2;
    QLabel *fpga4_d5_dcb_2;
    QLabel *fpga5_d5_dcb_2;
    QLabel *label_32;
    QLabel *fpga1_a18_dcb_2;
    QLabel *fpga2_a18_dcb_2;
    QLabel *fpga3_a18_dcb_2;
    QLabel *fpga4_a18_dcb_2;
    QLabel *fpga5_a18_dcb_2;
    QLabel *label_37;
    QLabel *fpga1_a33_dcb_2;
    QLabel *fpga2_a33_dcb_2;
    QLabel *fpga3_a33_dcb_2;
    QLabel *fpga4_a33_dcb_2;
    QLabel *fpga5_a33_dcb_2;
    QSpacerItem *horizontalSpacer_18;
    QWidget *DCB3;
    QGridLayout *gridLayout_17;
    QSpacerItem *horizontalSpacer_22;
    QLabel *label_51;
    QSpacerItem *horizontalSpacer_24;
    QLabel *label_50;
    QSpacerItem *horizontalSpacer_21;
    QLabel *label_56;
    QSpacerItem *horizontalSpacer_19;
    QLabel *label_57;
    QSpacerItem *horizontalSpacer_23;
    QLabel *label_46;
    QSpacerItem *horizontalSpacer_20;
    QLabel *label_48;
    QLabel *fpga1_con_dcb_3;
    QLabel *fpga2_con_dcb_3;
    QLabel *fpga3_con_dcb_3;
    QLabel *fpga4_con_dcb_3;
    QLabel *fpga5_con_dcb_3;
    QLabel *label_52;
    QLabel *fpga1_hlt_dcb_3;
    QLabel *fpga2_hlt_dcb_3;
    QLabel *fpga3_hlt_dcb_3;
    QLabel *fpga4_hlt_dcb_3;
    QLabel *fpga5_hlt_dcb_3;
    QLabel *label_47;
    QLabel *fpga1_rdy_dcb_3;
    QLabel *fpga2_rdy_dcb_3;
    QLabel *fpga3_rdy_dcb_3;
    QLabel *fpga4_rdy_dcb_3;
    QLabel *fpga5_rdy_dcb_3;
    QLabel *label_53;
    QLabel *fpga1_d18_dcb_3;
    QLabel *fpga2_d18_dcb_3;
    QLabel *fpga3_d18_dcb_3;
    QLabel *fpga4_d18_dcb_3;
    QLabel *fpga5_d18_dcb_3;
    QLabel *label_55;
    QLabel *fpga1_d25_dcb_3;
    QLabel *fpga2_d25_dcb_3;
    QLabel *fpga3_d25_dcb_3;
    QLabel *fpga4_d25_dcb_3;
    QLabel *fpga5_d25_dcb_3;
    QLabel *label_49;
    QLabel *fpga1_d33_dcb_3;
    QLabel *fpga2_d33_dcb_3;
    QLabel *fpga3_d33_dcb_3;
    QLabel *fpga4_d33_dcb_3;
    QLabel *fpga5_d33_dcb_3;
    QLabel *label_54;
    QLabel *fpga1_d5_dcb_3;
    QLabel *fpga2_d5_dcb_3;
    QLabel *fpga3_d5_dcb_3;
    QLabel *fpga4_d5_dcb_3;
    QLabel *fpga5_d5_dcb_3;
    QLabel *label_44;
    QLabel *fpga1_a18_dcb_3;
    QLabel *fpga2_a18_dcb_3;
    QLabel *fpga3_a18_dcb_3;
    QLabel *fpga4_a18_dcb_3;
    QLabel *fpga5_a18_dcb_3;
    QLabel *label_45;
    QLabel *fpga1_a33_dcb_3;
    QLabel *fpga2_a33_dcb_3;
    QLabel *fpga3_a33_dcb_3;
    QLabel *fpga4_a33_dcb_3;
    QLabel *fpga5_a33_dcb_3;
    QWidget *DCB4;
    QGridLayout *gridLayout_18;
    QSpacerItem *horizontalSpacer_29;
    QLabel *label_68;
    QSpacerItem *horizontalSpacer_25;
    QLabel *label_70;
    QSpacerItem *horizontalSpacer_27;
    QLabel *label_63;
    QSpacerItem *horizontalSpacer_28;
    QLabel *label_67;
    QSpacerItem *horizontalSpacer_30;
    QLabel *label_61;
    QSpacerItem *horizontalSpacer_26;
    QLabel *label_59;
    QLabel *fpga1_con_dcb_4;
    QLabel *fpga2_con_dcb_4;
    QLabel *fpga3_con_dcb_4;
    QLabel *fpga4_con_dcb_4;
    QLabel *fpga5_con_dcb_4;
    QLabel *label_58;
    QLabel *fpga1_hlt_dcb_4;
    QLabel *fpga2_hlt_dcb_4;
    QLabel *fpga3_hlt_dcb_4;
    QLabel *fpga4_hlt_dcb_4;
    QLabel *fpga5_hlt_dcb_4;
    QLabel *label_66;
    QLabel *fpga1_rdy_dcb_4;
    QLabel *fpga2_rdy_dcb_4;
    QLabel *fpga3_rdy_dcb_4;
    QLabel *fpga4_rdy_dcb_4;
    QLabel *fpga5_rdy_dcb_4;
    QLabel *label_64;
    QLabel *fpga1_d18_dcb_4;
    QLabel *fpga2_d18_dcb_4;
    QLabel *fpga3_d18_dcb_4;
    QLabel *fpga4_d18_dcb_4;
    QLabel *fpga5_d18_dcb_4;
    QLabel *label_71;
    QLabel *fpga1_d25_dcb_4;
    QLabel *fpga2_d25_dcb_4;
    QLabel *fpga3_d25_dcb_4;
    QLabel *fpga4_d25_dcb_4;
    QLabel *fpga5_d25_dcb_4;
    QLabel *label_62;
    QLabel *fpga1_d33_dcb_4;
    QLabel *fpga2_d33_dcb_4;
    QLabel *fpga3_d33_dcb_4;
    QLabel *fpga4_d33_dcb_4;
    QLabel *fpga5_d33_dcb_4;
    QLabel *label_65;
    QLabel *fpga1_d5_dcb_4;
    QLabel *fpga2_d5_dcb_4;
    QLabel *fpga3_d5_dcb_4;
    QLabel *fpga4_d5_dcb_4;
    QLabel *fpga5_d5_dcb_4;
    QLabel *label_69;
    QLabel *fpga1_a18_dcb_4;
    QLabel *fpga2_a18_dcb_4;
    QLabel *fpga3_a18_dcb_4;
    QLabel *fpga4_a18_dcb_4;
    QLabel *fpga5_a18_dcb_4;
    QLabel *label_60;
    QLabel *fpga1_a33_dcb_4;
    QLabel *fpga2_a33_dcb_4;
    QLabel *fpga3_a33_dcb_4;
    QLabel *fpga4_a33_dcb_4;
    QLabel *fpga5_a33_dcb_4;
    QWidget *DCB5;
    QGridLayout *gridLayout_19;
    QSpacerItem *horizontalSpacer_32;
    QLabel *label_74;
    QSpacerItem *horizontalSpacer_31;
    QLabel *label_85;
    QSpacerItem *horizontalSpacer_34;
    QLabel *label_82;
    QSpacerItem *horizontalSpacer_33;
    QLabel *label_75;
    QSpacerItem *horizontalSpacer_35;
    QLabel *label_77;
    QSpacerItem *horizontalSpacer_36;
    QLabel *label_73;
    QLabel *fpga1_con_dcb_5;
    QLabel *fpga2_con_dcb_5;
    QLabel *fpga3_con_dcb_5;
    QLabel *fpga4_con_dcb_5;
    QLabel *fpga5_con_dcb_5;
    QLabel *label_84;
    QLabel *fpga1_hlt_dcb_5;
    QLabel *fpga2_hlt_dcb_5;
    QLabel *fpga3_hlt_dcb_5;
    QLabel *fpga4_hlt_dcb_5;
    QLabel *fpga5_hlt_dcb_5;
    QLabel *label_80;
    QLabel *fpga1_rdy_dcb_5;
    QLabel *fpga2_rdy_dcb_5;
    QLabel *fpga3_rdy_dcb_5;
    QLabel *fpga4_rdy_dcb_5;
    QLabel *fpga5_rdy_dcb_5;
    QLabel *label_78;
    QLabel *fpga1_d18_dcb_5;
    QLabel *fpga2_d18_dcb_5;
    QLabel *fpga3_d18_dcb_5;
    QLabel *fpga4_d18_dcb_5;
    QLabel *fpga5_d18_dcb_5;
    QLabel *label_81;
    QLabel *fpga1_d25_dcb_5;
    QLabel *fpga2_d25_dcb_5;
    QLabel *fpga3_d25_dcb_5;
    QLabel *fpga4_d25_dcb_5;
    QLabel *fpga5_d25_dcb_5;
    QLabel *label_72;
    QLabel *fpga1_d33_dcb_5;
    QLabel *fpga2_d33_dcb_5;
    QLabel *fpga3_d33_dcb_5;
    QLabel *fpga4_d33_dcb_5;
    QLabel *fpga5_d33_dcb_5;
    QLabel *label_79;
    QLabel *fpga1_d5_dcb_5;
    QLabel *fpga2_d5_dcb_5;
    QLabel *fpga3_d5_dcb_5;
    QLabel *fpga4_d5_dcb_5;
    QLabel *fpga5_d5_dcb_5;
    QLabel *label_83;
    QLabel *fpga1_a18_dcb_5;
    QLabel *fpga2_a18_dcb_5;
    QLabel *fpga3_a18_dcb_5;
    QLabel *fpga4_a18_dcb_5;
    QLabel *fpga5_a18_dcb_5;
    QLabel *label_76;
    QLabel *fpga1_a33_dcb_5;
    QLabel *fpga2_a33_dcb_5;
    QLabel *fpga3_a33_dcb_5;
    QLabel *fpga4_a33_dcb_5;
    QLabel *fpga5_a33_dcb_5;
    QWidget *DCB6;
    QGridLayout *gridLayout_20;
    QSpacerItem *horizontalSpacer_39;
    QLabel *label_97;
    QSpacerItem *horizontalSpacer_37;
    QLabel *label_98;
    QSpacerItem *horizontalSpacer_40;
    QLabel *label_93;
    QSpacerItem *horizontalSpacer_38;
    QLabel *label_86;
    QSpacerItem *horizontalSpacer_41;
    QLabel *label_90;
    QSpacerItem *horizontalSpacer_42;
    QLabel *label_91;
    QLabel *fpga1_con_dcb_6;
    QLabel *fpga2_con_dcb_6;
    QLabel *fpga3_con_dcb_6;
    QLabel *fpga4_con_dcb_6;
    QLabel *fpga5_con_dcb_6;
    QLabel *label_89;
    QLabel *fpga1_hlt_dcb_6;
    QLabel *fpga2_hlt_dcb_6;
    QLabel *fpga3_hlt_dcb_6;
    QLabel *fpga4_hlt_dcb_6;
    QLabel *fpga5_hlt_dcb_6;
    QLabel *label_92;
    QLabel *fpga1_rdy_dcb_6;
    QLabel *fpga2_rdy_dcb_6;
    QLabel *fpga3_rdy_dcb_6;
    QLabel *fpga4_rdy_dcb_6;
    QLabel *fpga5_rdy_dcb_6;
    QLabel *label_88;
    QLabel *fpga1_d18_dcb_6;
    QLabel *fpga2_d18_dcb_6;
    QLabel *fpga3_d18_dcb_6;
    QLabel *fpga4_d18_dcb_6;
    QLabel *fpga5_d18_dcb_6;
    QLabel *label_94;
    QLabel *fpga1_d25_dcb_6;
    QLabel *fpga2_d25_dcb_6;
    QLabel *fpga3_d25_dcb_6;
    QLabel *fpga4_d25_dcb_6;
    QLabel *fpga5_d25_dcb_6;
    QLabel *label_96;
    QLabel *fpga1_d33_dcb_6;
    QLabel *fpga2_d33_dcb_6;
    QLabel *fpga3_d33_dcb_6;
    QLabel *fpga4_d33_dcb_6;
    QLabel *fpga5_d33_dcb_6;
    QLabel *label_95;
    QLabel *fpga1_d5_dcb_6;
    QLabel *fpga2_d5_dcb_6;
    QLabel *fpga3_d5_dcb_6;
    QLabel *fpga4_d5_dcb_6;
    QLabel *fpga5_d5_dcb_6;
    QLabel *label_99;
    QLabel *fpga1_a18_dcb_6;
    QLabel *fpga2_a18_dcb_6;
    QLabel *fpga3_a18_dcb_6;
    QLabel *fpga4_a18_dcb_6;
    QLabel *fpga5_a18_dcb_6;
    QLabel *label_87;
    QLabel *fpga1_a33_dcb_6;
    QLabel *fpga2_a33_dcb_6;
    QLabel *fpga3_a33_dcb_6;
    QLabel *fpga4_a33_dcb_6;
    QLabel *fpga5_a33_dcb_6;
    QWidget *DCB7;
    QGridLayout *gridLayout_21;
    QSpacerItem *horizontalSpacer_43;
    QLabel *label_106;
    QSpacerItem *horizontalSpacer_46;
    QLabel *label_111;
    QSpacerItem *horizontalSpacer_45;
    QLabel *label_107;
    QSpacerItem *horizontalSpacer_48;
    QLabel *label_103;
    QSpacerItem *horizontalSpacer_44;
    QLabel *label_102;
    QSpacerItem *horizontalSpacer_47;
    QLabel *label_100;
    QLabel *fpga1_con_dcb_7;
    QLabel *fpga2_con_dcb_7;
    QLabel *fpga3_con_dcb_7;
    QLabel *fpga4_con_dcb_7;
    QLabel *fpga5_con_dcb_7;
    QLabel *label_108;
    QLabel *fpga1_hlt_dcb_7;
    QLabel *fpga2_hlt_dcb_7;
    QLabel *fpga3_hlt_dcb_7;
    QLabel *fpga4_hlt_dcb_7;
    QLabel *fpga5_hlt_dcb_7;
    QLabel *label_110;
    QLabel *fpga1_rdy_dcb_7;
    QLabel *fpga2_rdy_dcb_7;
    QLabel *fpga3_rdy_dcb_7;
    QLabel *fpga4_rdy_dcb_7;
    QLabel *fpga5_rdy_dcb_7;
    QLabel *label_113;
    QLabel *fpga1_d18_dcb_7;
    QLabel *fpga2_d18_dcb_7;
    QLabel *fpga3_d18_dcb_7;
    QLabel *fpga4_d18_dcb_7;
    QLabel *fpga5_d18_dcb_7;
    QLabel *label_109;
    QLabel *fpga1_d25_dcb_7;
    QLabel *fpga2_d25_dcb_7;
    QLabel *fpga3_d25_dcb_7;
    QLabel *fpga4_d25_dcb_7;
    QLabel *fpga5_d25_dcb_7;
    QLabel *label_112;
    QLabel *fpga1_d33_dcb_7;
    QLabel *fpga2_d33_dcb_7;
    QLabel *fpga3_d33_dcb_7;
    QLabel *fpga4_d33_dcb_7;
    QLabel *fpga5_d33_dcb_7;
    QLabel *label_104;
    QLabel *fpga1_d5_dcb_7;
    QLabel *fpga2_d5_dcb_7;
    QLabel *fpga3_d5_dcb_7;
    QLabel *fpga4_d5_dcb_7;
    QLabel *fpga5_d5_dcb_7;
    QLabel *label_105;
    QLabel *fpga1_a18_dcb_7;
    QLabel *fpga2_a18_dcb_7;
    QLabel *fpga3_a18_dcb_7;
    QLabel *fpga4_a18_dcb_7;
    QLabel *fpga5_a18_dcb_7;
    QLabel *label_101;
    QLabel *fpga1_a33_dcb_7;
    QLabel *fpga2_a33_dcb_7;
    QLabel *fpga3_a33_dcb_7;
    QLabel *fpga4_a33_dcb_7;
    QLabel *fpga5_a33_dcb_7;

    void setupUi(QDialog *dialog_dcb)
    {
        if (dialog_dcb->objectName().isEmpty())
            dialog_dcb->setObjectName(QString::fromUtf8("dialog_dcb"));
        dialog_dcb->resize(466, 491);
        dialog_dcb->setMinimumSize(QSize(466, 491));
        dialog_dcb->setMaximumSize(QSize(466, 491));
        dialog_dcb->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
""));
        gridLayout = new QGridLayout(dialog_dcb);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        tab_dcb = new QTabWidget(dialog_dcb);
        tab_dcb->setObjectName(QString::fromUtf8("tab_dcb"));
        tab_dcb->setFocusPolicy(Qt::NoFocus);
        tab_dcb->setStyleSheet(QString::fromUtf8("QTabBar::tab:!selected	{\n"
"	font: 75 9pt \"Sans Serif\";\n"
"	background-color: rgb(193, 193, 193);\n"
"	border-top-left-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	margin-left: px;\n"
"	margin-right: px;\n"
"	border: 1px solid black;\n"
"	border-bottom-color: black;\n"
"	min-width: 8ex;\n"
"}\n"
"QTabBar::tab:selected	{\n"
"	border-bottom-color: rgb(255, 255, 255);	\n"
"	font: 75  9pt \"Sans Serif\";\n"
"	border-top-left-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	margin-left: px;\n"
"	margin-right: px;\n"
"	border: 1px solid black;\n"
"	min-width: 8ex;\n"
"}\n"
"QTabWidget::pane	{\n"
"	border: 1px solid black\n"
"}"));
        DCB1 = new QWidget();
        DCB1->setObjectName(QString::fromUtf8("DCB1"));
        DCB1->setStyleSheet(QString::fromUtf8(""));
        gridLayout_22 = new QGridLayout(DCB1);
        gridLayout_22->setObjectName(QString::fromUtf8("gridLayout_22"));
        horizontalSpacer_54 = new QSpacerItem(129, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_22->addItem(horizontalSpacer_54, 0, 0, 1, 1);

        label_118 = new QLabel(DCB1);
        label_118->setObjectName(QString::fromUtf8("label_118"));
        label_118->setMaximumSize(QSize(300, 16777215));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        label_118->setFont(font);
        label_118->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_118, 0, 1, 1, 1);

        horizontalSpacer_50 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_22->addItem(horizontalSpacer_50, 0, 2, 1, 1);

        label_125 = new QLabel(DCB1);
        label_125->setObjectName(QString::fromUtf8("label_125"));
        label_125->setFont(font);
        label_125->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_125, 0, 3, 1, 1);

        horizontalSpacer_49 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_22->addItem(horizontalSpacer_49, 0, 4, 1, 1);

        label_126 = new QLabel(DCB1);
        label_126->setObjectName(QString::fromUtf8("label_126"));
        label_126->setFont(font);
        label_126->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_126, 0, 5, 1, 1);

        horizontalSpacer_53 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_22->addItem(horizontalSpacer_53, 0, 6, 1, 1);

        label_117 = new QLabel(DCB1);
        label_117->setObjectName(QString::fromUtf8("label_117"));
        label_117->setFont(font);
        label_117->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_117, 0, 7, 1, 1);

        horizontalSpacer_51 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_22->addItem(horizontalSpacer_51, 0, 8, 1, 1);

        label_124 = new QLabel(DCB1);
        label_124->setObjectName(QString::fromUtf8("label_124"));
        label_124->setFont(font);
        label_124->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_124, 0, 9, 1, 1);

        horizontalSpacer_52 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_22->addItem(horizontalSpacer_52, 0, 10, 1, 1);

        label_114 = new QLabel(DCB1);
        label_114->setObjectName(QString::fromUtf8("label_114"));
        label_114->setFont(font);

        gridLayout_22->addWidget(label_114, 1, 0, 1, 1);

        fpga1_con_dcb_1 = new QLabel(DCB1);
        fpga1_con_dcb_1->setObjectName(QString::fromUtf8("fpga1_con_dcb_1"));
        fpga1_con_dcb_1->setMaximumSize(QSize(46, 40));
        fpga1_con_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga1_con_dcb_1, 1, 1, 1, 1);

        fpga2_con_dcb_1 = new QLabel(DCB1);
        fpga2_con_dcb_1->setObjectName(QString::fromUtf8("fpga2_con_dcb_1"));
        fpga2_con_dcb_1->setMaximumSize(QSize(46, 40));
        fpga2_con_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga2_con_dcb_1, 1, 3, 1, 1);

        fpga3_con_dcb_1 = new QLabel(DCB1);
        fpga3_con_dcb_1->setObjectName(QString::fromUtf8("fpga3_con_dcb_1"));
        fpga3_con_dcb_1->setMaximumSize(QSize(46, 40));
        fpga3_con_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga3_con_dcb_1, 1, 5, 1, 1);

        fpga4_con_dcb_1 = new QLabel(DCB1);
        fpga4_con_dcb_1->setObjectName(QString::fromUtf8("fpga4_con_dcb_1"));
        fpga4_con_dcb_1->setMaximumSize(QSize(46, 40));
        fpga4_con_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga4_con_dcb_1, 1, 7, 1, 1);

        fpga5_con_dcb_1 = new QLabel(DCB1);
        fpga5_con_dcb_1->setObjectName(QString::fromUtf8("fpga5_con_dcb_1"));
        fpga5_con_dcb_1->setMaximumSize(QSize(46, 40));
        fpga5_con_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga5_con_dcb_1, 1, 9, 1, 1);

        label_121 = new QLabel(DCB1);
        label_121->setObjectName(QString::fromUtf8("label_121"));
        label_121->setFont(font);

        gridLayout_22->addWidget(label_121, 2, 0, 1, 1);

        fpga1_hlt_dcb_1 = new QLabel(DCB1);
        fpga1_hlt_dcb_1->setObjectName(QString::fromUtf8("fpga1_hlt_dcb_1"));
        fpga1_hlt_dcb_1->setMaximumSize(QSize(46, 40));
        fpga1_hlt_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga1_hlt_dcb_1, 2, 1, 1, 1);

        fpga2_hlt_dcb_1 = new QLabel(DCB1);
        fpga2_hlt_dcb_1->setObjectName(QString::fromUtf8("fpga2_hlt_dcb_1"));
        fpga2_hlt_dcb_1->setMaximumSize(QSize(46, 40));
        fpga2_hlt_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga2_hlt_dcb_1, 2, 3, 1, 1);

        fpga3_hlt_dcb_1 = new QLabel(DCB1);
        fpga3_hlt_dcb_1->setObjectName(QString::fromUtf8("fpga3_hlt_dcb_1"));
        fpga3_hlt_dcb_1->setMaximumSize(QSize(46, 40));
        fpga3_hlt_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga3_hlt_dcb_1, 2, 5, 1, 1);

        fpga4_hlt_dcb_1 = new QLabel(DCB1);
        fpga4_hlt_dcb_1->setObjectName(QString::fromUtf8("fpga4_hlt_dcb_1"));
        fpga4_hlt_dcb_1->setMaximumSize(QSize(46, 40));
        fpga4_hlt_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga4_hlt_dcb_1, 2, 7, 1, 1);

        fpga5_hlt_dcb_1 = new QLabel(DCB1);
        fpga5_hlt_dcb_1->setObjectName(QString::fromUtf8("fpga5_hlt_dcb_1"));
        fpga5_hlt_dcb_1->setMaximumSize(QSize(46, 40));
        fpga5_hlt_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga5_hlt_dcb_1, 2, 9, 1, 1);

        label_119 = new QLabel(DCB1);
        label_119->setObjectName(QString::fromUtf8("label_119"));
        label_119->setFont(font);

        gridLayout_22->addWidget(label_119, 3, 0, 1, 1);

        fpga1_rdy_dcb_1 = new QLabel(DCB1);
        fpga1_rdy_dcb_1->setObjectName(QString::fromUtf8("fpga1_rdy_dcb_1"));
        fpga1_rdy_dcb_1->setMaximumSize(QSize(46, 40));
        fpga1_rdy_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga1_rdy_dcb_1, 3, 1, 1, 1);

        fpga2_rdy_dcb_1 = new QLabel(DCB1);
        fpga2_rdy_dcb_1->setObjectName(QString::fromUtf8("fpga2_rdy_dcb_1"));
        fpga2_rdy_dcb_1->setMaximumSize(QSize(46, 40));
        fpga2_rdy_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga2_rdy_dcb_1, 3, 3, 1, 1);

        fpga3_rdy_dcb_1 = new QLabel(DCB1);
        fpga3_rdy_dcb_1->setObjectName(QString::fromUtf8("fpga3_rdy_dcb_1"));
        fpga3_rdy_dcb_1->setMaximumSize(QSize(46, 40));
        fpga3_rdy_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga3_rdy_dcb_1, 3, 5, 1, 1);

        fpga4_rdy_dcb_1 = new QLabel(DCB1);
        fpga4_rdy_dcb_1->setObjectName(QString::fromUtf8("fpga4_rdy_dcb_1"));
        fpga4_rdy_dcb_1->setMaximumSize(QSize(46, 40));
        fpga4_rdy_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga4_rdy_dcb_1, 3, 7, 1, 1);

        fpga5_rdy_dcb_1 = new QLabel(DCB1);
        fpga5_rdy_dcb_1->setObjectName(QString::fromUtf8("fpga5_rdy_dcb_1"));
        fpga5_rdy_dcb_1->setMaximumSize(QSize(46, 40));
        fpga5_rdy_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga5_rdy_dcb_1, 3, 9, 1, 1);

        label_116 = new QLabel(DCB1);
        label_116->setObjectName(QString::fromUtf8("label_116"));
        label_116->setFont(font);

        gridLayout_22->addWidget(label_116, 4, 0, 1, 1);

        fpga1_d18_dcb_1 = new QLabel(DCB1);
        fpga1_d18_dcb_1->setObjectName(QString::fromUtf8("fpga1_d18_dcb_1"));
        fpga1_d18_dcb_1->setMaximumSize(QSize(46, 40));
        fpga1_d18_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga1_d18_dcb_1, 4, 1, 1, 1);

        fpga2_d18_dcb_1 = new QLabel(DCB1);
        fpga2_d18_dcb_1->setObjectName(QString::fromUtf8("fpga2_d18_dcb_1"));
        fpga2_d18_dcb_1->setMaximumSize(QSize(46, 40));
        fpga2_d18_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga2_d18_dcb_1, 4, 3, 1, 1);

        fpga3_d18_dcb_1 = new QLabel(DCB1);
        fpga3_d18_dcb_1->setObjectName(QString::fromUtf8("fpga3_d18_dcb_1"));
        fpga3_d18_dcb_1->setMaximumSize(QSize(46, 40));
        fpga3_d18_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga3_d18_dcb_1, 4, 5, 1, 1);

        fpga4_d18_dcb_1 = new QLabel(DCB1);
        fpga4_d18_dcb_1->setObjectName(QString::fromUtf8("fpga4_d18_dcb_1"));
        fpga4_d18_dcb_1->setMaximumSize(QSize(46, 40));
        fpga4_d18_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga4_d18_dcb_1, 4, 7, 1, 1);

        fpga5_d18_dcb_1 = new QLabel(DCB1);
        fpga5_d18_dcb_1->setObjectName(QString::fromUtf8("fpga5_d18_dcb_1"));
        fpga5_d18_dcb_1->setMaximumSize(QSize(46, 40));
        fpga5_d18_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga5_d18_dcb_1, 4, 9, 1, 1);

        label_127 = new QLabel(DCB1);
        label_127->setObjectName(QString::fromUtf8("label_127"));
        label_127->setFont(font);

        gridLayout_22->addWidget(label_127, 5, 0, 1, 1);

        fpga1_d25_dcb_1 = new QLabel(DCB1);
        fpga1_d25_dcb_1->setObjectName(QString::fromUtf8("fpga1_d25_dcb_1"));
        fpga1_d25_dcb_1->setMaximumSize(QSize(46, 40));
        fpga1_d25_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga1_d25_dcb_1, 5, 1, 1, 1);

        fpga2_d25_dcb_1 = new QLabel(DCB1);
        fpga2_d25_dcb_1->setObjectName(QString::fromUtf8("fpga2_d25_dcb_1"));
        fpga2_d25_dcb_1->setMaximumSize(QSize(46, 40));
        fpga2_d25_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga2_d25_dcb_1, 5, 3, 1, 1);

        fpga3_d25_dcb_1 = new QLabel(DCB1);
        fpga3_d25_dcb_1->setObjectName(QString::fromUtf8("fpga3_d25_dcb_1"));
        fpga3_d25_dcb_1->setMaximumSize(QSize(46, 40));
        fpga3_d25_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga3_d25_dcb_1, 5, 5, 1, 1);

        fpga4_d25_dcb_1 = new QLabel(DCB1);
        fpga4_d25_dcb_1->setObjectName(QString::fromUtf8("fpga4_d25_dcb_1"));
        fpga4_d25_dcb_1->setMaximumSize(QSize(46, 40));
        fpga4_d25_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga4_d25_dcb_1, 5, 7, 1, 1);

        fpga5_d25_dcb_1 = new QLabel(DCB1);
        fpga5_d25_dcb_1->setObjectName(QString::fromUtf8("fpga5_d25_dcb_1"));
        fpga5_d25_dcb_1->setMaximumSize(QSize(46, 40));
        fpga5_d25_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga5_d25_dcb_1, 5, 9, 1, 1);

        label_120 = new QLabel(DCB1);
        label_120->setObjectName(QString::fromUtf8("label_120"));
        label_120->setFont(font);

        gridLayout_22->addWidget(label_120, 6, 0, 1, 1);

        fpga1_d33_dcb_1 = new QLabel(DCB1);
        fpga1_d33_dcb_1->setObjectName(QString::fromUtf8("fpga1_d33_dcb_1"));
        fpga1_d33_dcb_1->setMaximumSize(QSize(46, 40));
        fpga1_d33_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga1_d33_dcb_1, 6, 1, 1, 1);

        fpga2_d33_dcb_1 = new QLabel(DCB1);
        fpga2_d33_dcb_1->setObjectName(QString::fromUtf8("fpga2_d33_dcb_1"));
        fpga2_d33_dcb_1->setMaximumSize(QSize(46, 40));
        fpga2_d33_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga2_d33_dcb_1, 6, 3, 1, 1);

        fpga3_d33_dcb_1 = new QLabel(DCB1);
        fpga3_d33_dcb_1->setObjectName(QString::fromUtf8("fpga3_d33_dcb_1"));
        fpga3_d33_dcb_1->setMaximumSize(QSize(46, 40));
        fpga3_d33_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga3_d33_dcb_1, 6, 5, 1, 1);

        fpga4_d33_dcb_1 = new QLabel(DCB1);
        fpga4_d33_dcb_1->setObjectName(QString::fromUtf8("fpga4_d33_dcb_1"));
        fpga4_d33_dcb_1->setMaximumSize(QSize(46, 40));
        fpga4_d33_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga4_d33_dcb_1, 6, 7, 1, 1);

        fpga5_d33_dcb_1 = new QLabel(DCB1);
        fpga5_d33_dcb_1->setObjectName(QString::fromUtf8("fpga5_d33_dcb_1"));
        fpga5_d33_dcb_1->setMaximumSize(QSize(46, 40));
        fpga5_d33_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga5_d33_dcb_1, 6, 9, 1, 1);

        label_123 = new QLabel(DCB1);
        label_123->setObjectName(QString::fromUtf8("label_123"));
        label_123->setFont(font);

        gridLayout_22->addWidget(label_123, 7, 0, 1, 1);

        fpga1_d5_dcb_1 = new QLabel(DCB1);
        fpga1_d5_dcb_1->setObjectName(QString::fromUtf8("fpga1_d5_dcb_1"));
        fpga1_d5_dcb_1->setMaximumSize(QSize(46, 40));
        fpga1_d5_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga1_d5_dcb_1, 7, 1, 1, 1);

        fpga2_d5_dcb_1 = new QLabel(DCB1);
        fpga2_d5_dcb_1->setObjectName(QString::fromUtf8("fpga2_d5_dcb_1"));
        fpga2_d5_dcb_1->setMaximumSize(QSize(46, 40));
        fpga2_d5_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga2_d5_dcb_1, 7, 3, 1, 1);

        fpga3_d5_dcb_1 = new QLabel(DCB1);
        fpga3_d5_dcb_1->setObjectName(QString::fromUtf8("fpga3_d5_dcb_1"));
        fpga3_d5_dcb_1->setMaximumSize(QSize(46, 40));
        fpga3_d5_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga3_d5_dcb_1, 7, 5, 1, 1);

        fpga4_d5_dcb_1 = new QLabel(DCB1);
        fpga4_d5_dcb_1->setObjectName(QString::fromUtf8("fpga4_d5_dcb_1"));
        fpga4_d5_dcb_1->setMaximumSize(QSize(46, 40));
        fpga4_d5_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga4_d5_dcb_1, 7, 7, 1, 1);

        fpga5_d5_dcb_1 = new QLabel(DCB1);
        fpga5_d5_dcb_1->setObjectName(QString::fromUtf8("fpga5_d5_dcb_1"));
        fpga5_d5_dcb_1->setMaximumSize(QSize(46, 40));
        fpga5_d5_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga5_d5_dcb_1, 7, 9, 1, 1);

        label_115 = new QLabel(DCB1);
        label_115->setObjectName(QString::fromUtf8("label_115"));
        label_115->setFont(font);

        gridLayout_22->addWidget(label_115, 8, 0, 1, 1);

        fpga1_a18_dcb_1 = new QLabel(DCB1);
        fpga1_a18_dcb_1->setObjectName(QString::fromUtf8("fpga1_a18_dcb_1"));
        fpga1_a18_dcb_1->setMaximumSize(QSize(46, 40));
        fpga1_a18_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga1_a18_dcb_1, 8, 1, 1, 1);

        fpga2_a18_dcb_1 = new QLabel(DCB1);
        fpga2_a18_dcb_1->setObjectName(QString::fromUtf8("fpga2_a18_dcb_1"));
        fpga2_a18_dcb_1->setMaximumSize(QSize(46, 40));
        fpga2_a18_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga2_a18_dcb_1, 8, 3, 1, 1);

        fpga3_a18_dcb_1 = new QLabel(DCB1);
        fpga3_a18_dcb_1->setObjectName(QString::fromUtf8("fpga3_a18_dcb_1"));
        fpga3_a18_dcb_1->setMaximumSize(QSize(46, 40));
        fpga3_a18_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga3_a18_dcb_1, 8, 5, 1, 1);

        fpga4_a18_dcb_1 = new QLabel(DCB1);
        fpga4_a18_dcb_1->setObjectName(QString::fromUtf8("fpga4_a18_dcb_1"));
        fpga4_a18_dcb_1->setMaximumSize(QSize(46, 40));
        fpga4_a18_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga4_a18_dcb_1, 8, 7, 1, 1);

        fpga5_a18_dcb_1 = new QLabel(DCB1);
        fpga5_a18_dcb_1->setObjectName(QString::fromUtf8("fpga5_a18_dcb_1"));
        fpga5_a18_dcb_1->setMaximumSize(QSize(46, 40));
        fpga5_a18_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga5_a18_dcb_1, 8, 9, 1, 1);

        label_122 = new QLabel(DCB1);
        label_122->setObjectName(QString::fromUtf8("label_122"));
        label_122->setFont(font);

        gridLayout_22->addWidget(label_122, 9, 0, 1, 1);

        fpga1_a33_dcb_1 = new QLabel(DCB1);
        fpga1_a33_dcb_1->setObjectName(QString::fromUtf8("fpga1_a33_dcb_1"));
        fpga1_a33_dcb_1->setMaximumSize(QSize(46, 40));
        fpga1_a33_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga1_a33_dcb_1, 9, 1, 1, 1);

        fpga2_a33_dcb_1 = new QLabel(DCB1);
        fpga2_a33_dcb_1->setObjectName(QString::fromUtf8("fpga2_a33_dcb_1"));
        fpga2_a33_dcb_1->setMaximumSize(QSize(46, 40));
        fpga2_a33_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga2_a33_dcb_1, 9, 3, 1, 1);

        fpga3_a33_dcb_1 = new QLabel(DCB1);
        fpga3_a33_dcb_1->setObjectName(QString::fromUtf8("fpga3_a33_dcb_1"));
        fpga3_a33_dcb_1->setMaximumSize(QSize(46, 40));
        fpga3_a33_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga3_a33_dcb_1, 9, 5, 1, 1);

        fpga4_a33_dcb_1 = new QLabel(DCB1);
        fpga4_a33_dcb_1->setObjectName(QString::fromUtf8("fpga4_a33_dcb_1"));
        fpga4_a33_dcb_1->setMaximumSize(QSize(46, 40));
        fpga4_a33_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga4_a33_dcb_1, 9, 7, 1, 1);

        fpga5_a33_dcb_1 = new QLabel(DCB1);
        fpga5_a33_dcb_1->setObjectName(QString::fromUtf8("fpga5_a33_dcb_1"));
        fpga5_a33_dcb_1->setMaximumSize(QSize(46, 40));
        fpga5_a33_dcb_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_22->addWidget(fpga5_a33_dcb_1, 9, 9, 1, 1);

        tab_dcb->addTab(DCB1, QString());
        DCB2 = new QWidget();
        DCB2->setObjectName(QString::fromUtf8("DCB2"));
        gridLayout_16 = new QGridLayout(DCB2);
        gridLayout_16->setObjectName(QString::fromUtf8("gridLayout_16"));
        label_34 = new QLabel(DCB2);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        label_34->setMaximumSize(QSize(300, 16777215));
        label_34->setFont(font);
        label_34->setAlignment(Qt::AlignCenter);

        gridLayout_16->addWidget(label_34, 0, 1, 1, 1);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_16->addItem(horizontalSpacer_14, 0, 2, 1, 1);

        label_39 = new QLabel(DCB2);
        label_39->setObjectName(QString::fromUtf8("label_39"));
        label_39->setFont(font);
        label_39->setAlignment(Qt::AlignCenter);

        gridLayout_16->addWidget(label_39, 0, 3, 1, 1);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_16->addItem(horizontalSpacer_12, 0, 4, 1, 1);

        label_40 = new QLabel(DCB2);
        label_40->setObjectName(QString::fromUtf8("label_40"));
        label_40->setFont(font);
        label_40->setAlignment(Qt::AlignCenter);

        gridLayout_16->addWidget(label_40, 0, 5, 1, 1);

        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_16->addItem(horizontalSpacer_17, 0, 6, 1, 1);

        label_16 = new QLabel(DCB2);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setFont(font);
        label_16->setAlignment(Qt::AlignCenter);

        gridLayout_16->addWidget(label_16, 0, 7, 1, 1);

        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_16->addItem(horizontalSpacer_15, 0, 8, 1, 1);

        label_8 = new QLabel(DCB2);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setFont(font);
        label_8->setAlignment(Qt::AlignCenter);

        gridLayout_16->addWidget(label_8, 0, 9, 1, 1);

        horizontalSpacer_16 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_16->addItem(horizontalSpacer_16, 0, 10, 1, 1);

        label_14 = new QLabel(DCB2);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setFont(font);

        gridLayout_16->addWidget(label_14, 1, 0, 1, 1);

        fpga1_con_dcb_2 = new QLabel(DCB2);
        fpga1_con_dcb_2->setObjectName(QString::fromUtf8("fpga1_con_dcb_2"));
        fpga1_con_dcb_2->setMaximumSize(QSize(46, 40));
        fpga1_con_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga1_con_dcb_2, 1, 1, 1, 1);

        fpga2_con_dcb_2 = new QLabel(DCB2);
        fpga2_con_dcb_2->setObjectName(QString::fromUtf8("fpga2_con_dcb_2"));
        fpga2_con_dcb_2->setMaximumSize(QSize(46, 40));
        fpga2_con_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga2_con_dcb_2, 1, 3, 1, 1);

        fpga3_con_dcb_2 = new QLabel(DCB2);
        fpga3_con_dcb_2->setObjectName(QString::fromUtf8("fpga3_con_dcb_2"));
        fpga3_con_dcb_2->setMaximumSize(QSize(46, 40));
        fpga3_con_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga3_con_dcb_2, 1, 5, 1, 1);

        fpga4_con_dcb_2 = new QLabel(DCB2);
        fpga4_con_dcb_2->setObjectName(QString::fromUtf8("fpga4_con_dcb_2"));
        fpga4_con_dcb_2->setMaximumSize(QSize(46, 40));
        fpga4_con_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga4_con_dcb_2, 1, 7, 1, 1);

        fpga5_con_dcb_2 = new QLabel(DCB2);
        fpga5_con_dcb_2->setObjectName(QString::fromUtf8("fpga5_con_dcb_2"));
        fpga5_con_dcb_2->setMaximumSize(QSize(46, 40));
        fpga5_con_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga5_con_dcb_2, 1, 9, 1, 1);

        label_43 = new QLabel(DCB2);
        label_43->setObjectName(QString::fromUtf8("label_43"));
        label_43->setFont(font);

        gridLayout_16->addWidget(label_43, 2, 0, 1, 1);

        fpga1_hlt_dcb_2 = new QLabel(DCB2);
        fpga1_hlt_dcb_2->setObjectName(QString::fromUtf8("fpga1_hlt_dcb_2"));
        fpga1_hlt_dcb_2->setMaximumSize(QSize(46, 40));
        fpga1_hlt_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga1_hlt_dcb_2, 2, 1, 1, 1);

        fpga2_hlt_dcb_2 = new QLabel(DCB2);
        fpga2_hlt_dcb_2->setObjectName(QString::fromUtf8("fpga2_hlt_dcb_2"));
        fpga2_hlt_dcb_2->setMaximumSize(QSize(46, 40));
        fpga2_hlt_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga2_hlt_dcb_2, 2, 3, 1, 1);

        fpga3_hlt_dcb_2 = new QLabel(DCB2);
        fpga3_hlt_dcb_2->setObjectName(QString::fromUtf8("fpga3_hlt_dcb_2"));
        fpga3_hlt_dcb_2->setMaximumSize(QSize(46, 40));
        fpga3_hlt_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga3_hlt_dcb_2, 2, 5, 1, 1);

        fpga4_hlt_dcb_2 = new QLabel(DCB2);
        fpga4_hlt_dcb_2->setObjectName(QString::fromUtf8("fpga4_hlt_dcb_2"));
        fpga4_hlt_dcb_2->setMaximumSize(QSize(46, 40));
        fpga4_hlt_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga4_hlt_dcb_2, 2, 7, 1, 1);

        fpga5_hlt_dcb_2 = new QLabel(DCB2);
        fpga5_hlt_dcb_2->setObjectName(QString::fromUtf8("fpga5_hlt_dcb_2"));
        fpga5_hlt_dcb_2->setMaximumSize(QSize(46, 40));
        fpga5_hlt_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga5_hlt_dcb_2, 2, 9, 1, 1);

        label_35 = new QLabel(DCB2);
        label_35->setObjectName(QString::fromUtf8("label_35"));
        label_35->setFont(font);

        gridLayout_16->addWidget(label_35, 3, 0, 1, 1);

        fpga1_rdy_dcb_2 = new QLabel(DCB2);
        fpga1_rdy_dcb_2->setObjectName(QString::fromUtf8("fpga1_rdy_dcb_2"));
        fpga1_rdy_dcb_2->setMaximumSize(QSize(46, 40));
        fpga1_rdy_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga1_rdy_dcb_2, 3, 1, 1, 1);

        fpga2_rdy_dcb_2 = new QLabel(DCB2);
        fpga2_rdy_dcb_2->setObjectName(QString::fromUtf8("fpga2_rdy_dcb_2"));
        fpga2_rdy_dcb_2->setMaximumSize(QSize(46, 40));
        fpga2_rdy_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga2_rdy_dcb_2, 3, 3, 1, 1);

        fpga3_rdy_dcb_2 = new QLabel(DCB2);
        fpga3_rdy_dcb_2->setObjectName(QString::fromUtf8("fpga3_rdy_dcb_2"));
        fpga3_rdy_dcb_2->setMaximumSize(QSize(46, 40));
        fpga3_rdy_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga3_rdy_dcb_2, 3, 5, 1, 1);

        fpga4_rdy_dcb_2 = new QLabel(DCB2);
        fpga4_rdy_dcb_2->setObjectName(QString::fromUtf8("fpga4_rdy_dcb_2"));
        fpga4_rdy_dcb_2->setMaximumSize(QSize(46, 40));
        fpga4_rdy_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga4_rdy_dcb_2, 3, 7, 1, 1);

        fpga5_rdy_dcb_2 = new QLabel(DCB2);
        fpga5_rdy_dcb_2->setObjectName(QString::fromUtf8("fpga5_rdy_dcb_2"));
        fpga5_rdy_dcb_2->setMaximumSize(QSize(46, 40));
        fpga5_rdy_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga5_rdy_dcb_2, 3, 9, 1, 1);

        label_33 = new QLabel(DCB2);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        label_33->setFont(font);

        gridLayout_16->addWidget(label_33, 4, 0, 1, 1);

        fpga1_d18_dcb_2 = new QLabel(DCB2);
        fpga1_d18_dcb_2->setObjectName(QString::fromUtf8("fpga1_d18_dcb_2"));
        fpga1_d18_dcb_2->setMaximumSize(QSize(46, 40));
        fpga1_d18_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga1_d18_dcb_2, 4, 1, 1, 1);

        fpga2_d18_dcb_2 = new QLabel(DCB2);
        fpga2_d18_dcb_2->setObjectName(QString::fromUtf8("fpga2_d18_dcb_2"));
        fpga2_d18_dcb_2->setMaximumSize(QSize(46, 40));
        fpga2_d18_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga2_d18_dcb_2, 4, 3, 1, 1);

        fpga3_d18_dcb_2 = new QLabel(DCB2);
        fpga3_d18_dcb_2->setObjectName(QString::fromUtf8("fpga3_d18_dcb_2"));
        fpga3_d18_dcb_2->setMaximumSize(QSize(46, 40));
        fpga3_d18_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga3_d18_dcb_2, 4, 5, 1, 1);

        fpga4_d18_dcb_2 = new QLabel(DCB2);
        fpga4_d18_dcb_2->setObjectName(QString::fromUtf8("fpga4_d18_dcb_2"));
        fpga4_d18_dcb_2->setMaximumSize(QSize(46, 40));
        fpga4_d18_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga4_d18_dcb_2, 4, 7, 1, 1);

        fpga5_d18_dcb_2 = new QLabel(DCB2);
        fpga5_d18_dcb_2->setObjectName(QString::fromUtf8("fpga5_d18_dcb_2"));
        fpga5_d18_dcb_2->setMaximumSize(QSize(46, 40));
        fpga5_d18_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga5_d18_dcb_2, 4, 9, 1, 1);

        label_41 = new QLabel(DCB2);
        label_41->setObjectName(QString::fromUtf8("label_41"));
        label_41->setFont(font);

        gridLayout_16->addWidget(label_41, 5, 0, 1, 1);

        fpga1_d25_dcb_2 = new QLabel(DCB2);
        fpga1_d25_dcb_2->setObjectName(QString::fromUtf8("fpga1_d25_dcb_2"));
        fpga1_d25_dcb_2->setMaximumSize(QSize(46, 40));
        fpga1_d25_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga1_d25_dcb_2, 5, 1, 1, 1);

        fpga2_d25_dcb_2 = new QLabel(DCB2);
        fpga2_d25_dcb_2->setObjectName(QString::fromUtf8("fpga2_d25_dcb_2"));
        fpga2_d25_dcb_2->setMaximumSize(QSize(46, 40));
        fpga2_d25_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga2_d25_dcb_2, 5, 3, 1, 1);

        fpga3_d25_dcb_2 = new QLabel(DCB2);
        fpga3_d25_dcb_2->setObjectName(QString::fromUtf8("fpga3_d25_dcb_2"));
        fpga3_d25_dcb_2->setMaximumSize(QSize(46, 40));
        fpga3_d25_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga3_d25_dcb_2, 5, 5, 1, 1);

        fpga4_d25_dcb_2 = new QLabel(DCB2);
        fpga4_d25_dcb_2->setObjectName(QString::fromUtf8("fpga4_d25_dcb_2"));
        fpga4_d25_dcb_2->setMaximumSize(QSize(46, 40));
        fpga4_d25_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga4_d25_dcb_2, 5, 7, 1, 1);

        fpga5_d25_dcb_2 = new QLabel(DCB2);
        fpga5_d25_dcb_2->setObjectName(QString::fromUtf8("fpga5_d25_dcb_2"));
        fpga5_d25_dcb_2->setMaximumSize(QSize(46, 40));
        fpga5_d25_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga5_d25_dcb_2, 5, 9, 1, 1);

        label_36 = new QLabel(DCB2);
        label_36->setObjectName(QString::fromUtf8("label_36"));
        label_36->setFont(font);

        gridLayout_16->addWidget(label_36, 6, 0, 1, 1);

        fpga1_d33_dcb_2 = new QLabel(DCB2);
        fpga1_d33_dcb_2->setObjectName(QString::fromUtf8("fpga1_d33_dcb_2"));
        fpga1_d33_dcb_2->setMaximumSize(QSize(46, 40));
        fpga1_d33_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga1_d33_dcb_2, 6, 1, 1, 1);

        fpga2_d33_dcb_2 = new QLabel(DCB2);
        fpga2_d33_dcb_2->setObjectName(QString::fromUtf8("fpga2_d33_dcb_2"));
        fpga2_d33_dcb_2->setMaximumSize(QSize(46, 40));
        fpga2_d33_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga2_d33_dcb_2, 6, 3, 1, 1);

        fpga3_d33_dcb_2 = new QLabel(DCB2);
        fpga3_d33_dcb_2->setObjectName(QString::fromUtf8("fpga3_d33_dcb_2"));
        fpga3_d33_dcb_2->setMaximumSize(QSize(46, 40));
        fpga3_d33_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga3_d33_dcb_2, 6, 5, 1, 1);

        fpga4_d33_dcb_2 = new QLabel(DCB2);
        fpga4_d33_dcb_2->setObjectName(QString::fromUtf8("fpga4_d33_dcb_2"));
        fpga4_d33_dcb_2->setMaximumSize(QSize(46, 40));
        fpga4_d33_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga4_d33_dcb_2, 6, 7, 1, 1);

        fpga5_d33_dcb_2 = new QLabel(DCB2);
        fpga5_d33_dcb_2->setObjectName(QString::fromUtf8("fpga5_d33_dcb_2"));
        fpga5_d33_dcb_2->setMaximumSize(QSize(46, 40));
        fpga5_d33_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga5_d33_dcb_2, 6, 9, 1, 1);

        label_38 = new QLabel(DCB2);
        label_38->setObjectName(QString::fromUtf8("label_38"));
        label_38->setFont(font);

        gridLayout_16->addWidget(label_38, 7, 0, 1, 1);

        fpga1_d5_dcb_2 = new QLabel(DCB2);
        fpga1_d5_dcb_2->setObjectName(QString::fromUtf8("fpga1_d5_dcb_2"));
        fpga1_d5_dcb_2->setMaximumSize(QSize(46, 40));
        fpga1_d5_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga1_d5_dcb_2, 7, 1, 1, 1);

        fpga2_d5_dcb_2 = new QLabel(DCB2);
        fpga2_d5_dcb_2->setObjectName(QString::fromUtf8("fpga2_d5_dcb_2"));
        fpga2_d5_dcb_2->setMaximumSize(QSize(46, 40));
        fpga2_d5_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga2_d5_dcb_2, 7, 3, 1, 1);

        fpga3_d5_dcb_2 = new QLabel(DCB2);
        fpga3_d5_dcb_2->setObjectName(QString::fromUtf8("fpga3_d5_dcb_2"));
        fpga3_d5_dcb_2->setMaximumSize(QSize(46, 40));
        fpga3_d5_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga3_d5_dcb_2, 7, 5, 1, 1);

        fpga4_d5_dcb_2 = new QLabel(DCB2);
        fpga4_d5_dcb_2->setObjectName(QString::fromUtf8("fpga4_d5_dcb_2"));
        fpga4_d5_dcb_2->setMaximumSize(QSize(46, 40));
        fpga4_d5_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga4_d5_dcb_2, 7, 7, 1, 1);

        fpga5_d5_dcb_2 = new QLabel(DCB2);
        fpga5_d5_dcb_2->setObjectName(QString::fromUtf8("fpga5_d5_dcb_2"));
        fpga5_d5_dcb_2->setMaximumSize(QSize(46, 40));
        fpga5_d5_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga5_d5_dcb_2, 7, 9, 1, 1);

        label_32 = new QLabel(DCB2);
        label_32->setObjectName(QString::fromUtf8("label_32"));
        label_32->setFont(font);

        gridLayout_16->addWidget(label_32, 8, 0, 1, 1);

        fpga1_a18_dcb_2 = new QLabel(DCB2);
        fpga1_a18_dcb_2->setObjectName(QString::fromUtf8("fpga1_a18_dcb_2"));
        fpga1_a18_dcb_2->setMaximumSize(QSize(46, 40));
        fpga1_a18_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga1_a18_dcb_2, 8, 1, 1, 1);

        fpga2_a18_dcb_2 = new QLabel(DCB2);
        fpga2_a18_dcb_2->setObjectName(QString::fromUtf8("fpga2_a18_dcb_2"));
        fpga2_a18_dcb_2->setMaximumSize(QSize(46, 40));
        fpga2_a18_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga2_a18_dcb_2, 8, 3, 1, 1);

        fpga3_a18_dcb_2 = new QLabel(DCB2);
        fpga3_a18_dcb_2->setObjectName(QString::fromUtf8("fpga3_a18_dcb_2"));
        fpga3_a18_dcb_2->setMaximumSize(QSize(46, 40));
        fpga3_a18_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga3_a18_dcb_2, 8, 5, 1, 1);

        fpga4_a18_dcb_2 = new QLabel(DCB2);
        fpga4_a18_dcb_2->setObjectName(QString::fromUtf8("fpga4_a18_dcb_2"));
        fpga4_a18_dcb_2->setMaximumSize(QSize(46, 40));
        fpga4_a18_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga4_a18_dcb_2, 8, 7, 1, 1);

        fpga5_a18_dcb_2 = new QLabel(DCB2);
        fpga5_a18_dcb_2->setObjectName(QString::fromUtf8("fpga5_a18_dcb_2"));
        fpga5_a18_dcb_2->setMaximumSize(QSize(46, 40));
        fpga5_a18_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga5_a18_dcb_2, 8, 9, 1, 1);

        label_37 = new QLabel(DCB2);
        label_37->setObjectName(QString::fromUtf8("label_37"));
        label_37->setFont(font);

        gridLayout_16->addWidget(label_37, 9, 0, 1, 1);

        fpga1_a33_dcb_2 = new QLabel(DCB2);
        fpga1_a33_dcb_2->setObjectName(QString::fromUtf8("fpga1_a33_dcb_2"));
        fpga1_a33_dcb_2->setMaximumSize(QSize(46, 40));
        fpga1_a33_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga1_a33_dcb_2, 9, 1, 1, 1);

        fpga2_a33_dcb_2 = new QLabel(DCB2);
        fpga2_a33_dcb_2->setObjectName(QString::fromUtf8("fpga2_a33_dcb_2"));
        fpga2_a33_dcb_2->setMaximumSize(QSize(46, 40));
        fpga2_a33_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga2_a33_dcb_2, 9, 3, 1, 1);

        fpga3_a33_dcb_2 = new QLabel(DCB2);
        fpga3_a33_dcb_2->setObjectName(QString::fromUtf8("fpga3_a33_dcb_2"));
        fpga3_a33_dcb_2->setMaximumSize(QSize(46, 40));
        fpga3_a33_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga3_a33_dcb_2, 9, 5, 1, 1);

        fpga4_a33_dcb_2 = new QLabel(DCB2);
        fpga4_a33_dcb_2->setObjectName(QString::fromUtf8("fpga4_a33_dcb_2"));
        fpga4_a33_dcb_2->setMaximumSize(QSize(46, 40));
        fpga4_a33_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga4_a33_dcb_2, 9, 7, 1, 1);

        fpga5_a33_dcb_2 = new QLabel(DCB2);
        fpga5_a33_dcb_2->setObjectName(QString::fromUtf8("fpga5_a33_dcb_2"));
        fpga5_a33_dcb_2->setMaximumSize(QSize(46, 40));
        fpga5_a33_dcb_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_16->addWidget(fpga5_a33_dcb_2, 9, 9, 1, 1);

        horizontalSpacer_18 = new QSpacerItem(129, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_16->addItem(horizontalSpacer_18, 0, 0, 1, 1);

        tab_dcb->addTab(DCB2, QString());
        DCB3 = new QWidget();
        DCB3->setObjectName(QString::fromUtf8("DCB3"));
        gridLayout_17 = new QGridLayout(DCB3);
        gridLayout_17->setObjectName(QString::fromUtf8("gridLayout_17"));
        horizontalSpacer_22 = new QSpacerItem(129, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_17->addItem(horizontalSpacer_22, 0, 0, 1, 1);

        label_51 = new QLabel(DCB3);
        label_51->setObjectName(QString::fromUtf8("label_51"));
        label_51->setMaximumSize(QSize(300, 16777215));
        label_51->setFont(font);
        label_51->setAlignment(Qt::AlignCenter);

        gridLayout_17->addWidget(label_51, 0, 1, 1, 1);

        horizontalSpacer_24 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_17->addItem(horizontalSpacer_24, 0, 2, 1, 1);

        label_50 = new QLabel(DCB3);
        label_50->setObjectName(QString::fromUtf8("label_50"));
        label_50->setFont(font);
        label_50->setAlignment(Qt::AlignCenter);

        gridLayout_17->addWidget(label_50, 0, 3, 1, 1);

        horizontalSpacer_21 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_17->addItem(horizontalSpacer_21, 0, 4, 1, 1);

        label_56 = new QLabel(DCB3);
        label_56->setObjectName(QString::fromUtf8("label_56"));
        label_56->setFont(font);
        label_56->setAlignment(Qt::AlignCenter);

        gridLayout_17->addWidget(label_56, 0, 5, 1, 1);

        horizontalSpacer_19 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_17->addItem(horizontalSpacer_19, 0, 6, 1, 1);

        label_57 = new QLabel(DCB3);
        label_57->setObjectName(QString::fromUtf8("label_57"));
        label_57->setFont(font);
        label_57->setAlignment(Qt::AlignCenter);

        gridLayout_17->addWidget(label_57, 0, 7, 1, 1);

        horizontalSpacer_23 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_17->addItem(horizontalSpacer_23, 0, 8, 1, 1);

        label_46 = new QLabel(DCB3);
        label_46->setObjectName(QString::fromUtf8("label_46"));
        label_46->setFont(font);
        label_46->setAlignment(Qt::AlignCenter);

        gridLayout_17->addWidget(label_46, 0, 9, 1, 1);

        horizontalSpacer_20 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_17->addItem(horizontalSpacer_20, 0, 10, 1, 1);

        label_48 = new QLabel(DCB3);
        label_48->setObjectName(QString::fromUtf8("label_48"));
        label_48->setFont(font);

        gridLayout_17->addWidget(label_48, 1, 0, 1, 1);

        fpga1_con_dcb_3 = new QLabel(DCB3);
        fpga1_con_dcb_3->setObjectName(QString::fromUtf8("fpga1_con_dcb_3"));
        fpga1_con_dcb_3->setMaximumSize(QSize(46, 40));
        fpga1_con_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga1_con_dcb_3, 1, 1, 1, 1);

        fpga2_con_dcb_3 = new QLabel(DCB3);
        fpga2_con_dcb_3->setObjectName(QString::fromUtf8("fpga2_con_dcb_3"));
        fpga2_con_dcb_3->setMaximumSize(QSize(46, 40));
        fpga2_con_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga2_con_dcb_3, 1, 3, 1, 1);

        fpga3_con_dcb_3 = new QLabel(DCB3);
        fpga3_con_dcb_3->setObjectName(QString::fromUtf8("fpga3_con_dcb_3"));
        fpga3_con_dcb_3->setMaximumSize(QSize(46, 40));
        fpga3_con_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga3_con_dcb_3, 1, 5, 1, 1);

        fpga4_con_dcb_3 = new QLabel(DCB3);
        fpga4_con_dcb_3->setObjectName(QString::fromUtf8("fpga4_con_dcb_3"));
        fpga4_con_dcb_3->setMaximumSize(QSize(46, 40));
        fpga4_con_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga4_con_dcb_3, 1, 7, 1, 1);

        fpga5_con_dcb_3 = new QLabel(DCB3);
        fpga5_con_dcb_3->setObjectName(QString::fromUtf8("fpga5_con_dcb_3"));
        fpga5_con_dcb_3->setMaximumSize(QSize(46, 40));
        fpga5_con_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga5_con_dcb_3, 1, 9, 1, 1);

        label_52 = new QLabel(DCB3);
        label_52->setObjectName(QString::fromUtf8("label_52"));
        label_52->setFont(font);

        gridLayout_17->addWidget(label_52, 2, 0, 1, 1);

        fpga1_hlt_dcb_3 = new QLabel(DCB3);
        fpga1_hlt_dcb_3->setObjectName(QString::fromUtf8("fpga1_hlt_dcb_3"));
        fpga1_hlt_dcb_3->setMaximumSize(QSize(46, 40));
        fpga1_hlt_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga1_hlt_dcb_3, 2, 1, 1, 1);

        fpga2_hlt_dcb_3 = new QLabel(DCB3);
        fpga2_hlt_dcb_3->setObjectName(QString::fromUtf8("fpga2_hlt_dcb_3"));
        fpga2_hlt_dcb_3->setMaximumSize(QSize(46, 40));
        fpga2_hlt_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga2_hlt_dcb_3, 2, 3, 1, 1);

        fpga3_hlt_dcb_3 = new QLabel(DCB3);
        fpga3_hlt_dcb_3->setObjectName(QString::fromUtf8("fpga3_hlt_dcb_3"));
        fpga3_hlt_dcb_3->setMaximumSize(QSize(46, 40));
        fpga3_hlt_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga3_hlt_dcb_3, 2, 5, 1, 1);

        fpga4_hlt_dcb_3 = new QLabel(DCB3);
        fpga4_hlt_dcb_3->setObjectName(QString::fromUtf8("fpga4_hlt_dcb_3"));
        fpga4_hlt_dcb_3->setMaximumSize(QSize(46, 40));
        fpga4_hlt_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga4_hlt_dcb_3, 2, 7, 1, 1);

        fpga5_hlt_dcb_3 = new QLabel(DCB3);
        fpga5_hlt_dcb_3->setObjectName(QString::fromUtf8("fpga5_hlt_dcb_3"));
        fpga5_hlt_dcb_3->setMaximumSize(QSize(46, 40));
        fpga5_hlt_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga5_hlt_dcb_3, 2, 9, 1, 1);

        label_47 = new QLabel(DCB3);
        label_47->setObjectName(QString::fromUtf8("label_47"));
        label_47->setFont(font);

        gridLayout_17->addWidget(label_47, 3, 0, 1, 1);

        fpga1_rdy_dcb_3 = new QLabel(DCB3);
        fpga1_rdy_dcb_3->setObjectName(QString::fromUtf8("fpga1_rdy_dcb_3"));
        fpga1_rdy_dcb_3->setMaximumSize(QSize(46, 40));
        fpga1_rdy_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga1_rdy_dcb_3, 3, 1, 1, 1);

        fpga2_rdy_dcb_3 = new QLabel(DCB3);
        fpga2_rdy_dcb_3->setObjectName(QString::fromUtf8("fpga2_rdy_dcb_3"));
        fpga2_rdy_dcb_3->setMaximumSize(QSize(46, 40));
        fpga2_rdy_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga2_rdy_dcb_3, 3, 3, 1, 1);

        fpga3_rdy_dcb_3 = new QLabel(DCB3);
        fpga3_rdy_dcb_3->setObjectName(QString::fromUtf8("fpga3_rdy_dcb_3"));
        fpga3_rdy_dcb_3->setMaximumSize(QSize(46, 40));
        fpga3_rdy_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga3_rdy_dcb_3, 3, 5, 1, 1);

        fpga4_rdy_dcb_3 = new QLabel(DCB3);
        fpga4_rdy_dcb_3->setObjectName(QString::fromUtf8("fpga4_rdy_dcb_3"));
        fpga4_rdy_dcb_3->setMaximumSize(QSize(46, 40));
        fpga4_rdy_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga4_rdy_dcb_3, 3, 7, 1, 1);

        fpga5_rdy_dcb_3 = new QLabel(DCB3);
        fpga5_rdy_dcb_3->setObjectName(QString::fromUtf8("fpga5_rdy_dcb_3"));
        fpga5_rdy_dcb_3->setMaximumSize(QSize(46, 40));
        fpga5_rdy_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga5_rdy_dcb_3, 3, 9, 1, 1);

        label_53 = new QLabel(DCB3);
        label_53->setObjectName(QString::fromUtf8("label_53"));
        label_53->setFont(font);

        gridLayout_17->addWidget(label_53, 4, 0, 1, 1);

        fpga1_d18_dcb_3 = new QLabel(DCB3);
        fpga1_d18_dcb_3->setObjectName(QString::fromUtf8("fpga1_d18_dcb_3"));
        fpga1_d18_dcb_3->setMaximumSize(QSize(46, 40));
        fpga1_d18_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga1_d18_dcb_3, 4, 1, 1, 1);

        fpga2_d18_dcb_3 = new QLabel(DCB3);
        fpga2_d18_dcb_3->setObjectName(QString::fromUtf8("fpga2_d18_dcb_3"));
        fpga2_d18_dcb_3->setMaximumSize(QSize(46, 40));
        fpga2_d18_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga2_d18_dcb_3, 4, 3, 1, 1);

        fpga3_d18_dcb_3 = new QLabel(DCB3);
        fpga3_d18_dcb_3->setObjectName(QString::fromUtf8("fpga3_d18_dcb_3"));
        fpga3_d18_dcb_3->setMaximumSize(QSize(46, 40));
        fpga3_d18_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga3_d18_dcb_3, 4, 5, 1, 1);

        fpga4_d18_dcb_3 = new QLabel(DCB3);
        fpga4_d18_dcb_3->setObjectName(QString::fromUtf8("fpga4_d18_dcb_3"));
        fpga4_d18_dcb_3->setMaximumSize(QSize(46, 40));
        fpga4_d18_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga4_d18_dcb_3, 4, 7, 1, 1);

        fpga5_d18_dcb_3 = new QLabel(DCB3);
        fpga5_d18_dcb_3->setObjectName(QString::fromUtf8("fpga5_d18_dcb_3"));
        fpga5_d18_dcb_3->setMaximumSize(QSize(46, 40));
        fpga5_d18_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga5_d18_dcb_3, 4, 9, 1, 1);

        label_55 = new QLabel(DCB3);
        label_55->setObjectName(QString::fromUtf8("label_55"));
        label_55->setFont(font);

        gridLayout_17->addWidget(label_55, 5, 0, 1, 1);

        fpga1_d25_dcb_3 = new QLabel(DCB3);
        fpga1_d25_dcb_3->setObjectName(QString::fromUtf8("fpga1_d25_dcb_3"));
        fpga1_d25_dcb_3->setMaximumSize(QSize(46, 40));
        fpga1_d25_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga1_d25_dcb_3, 5, 1, 1, 1);

        fpga2_d25_dcb_3 = new QLabel(DCB3);
        fpga2_d25_dcb_3->setObjectName(QString::fromUtf8("fpga2_d25_dcb_3"));
        fpga2_d25_dcb_3->setMaximumSize(QSize(46, 40));
        fpga2_d25_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga2_d25_dcb_3, 5, 3, 1, 1);

        fpga3_d25_dcb_3 = new QLabel(DCB3);
        fpga3_d25_dcb_3->setObjectName(QString::fromUtf8("fpga3_d25_dcb_3"));
        fpga3_d25_dcb_3->setMaximumSize(QSize(46, 40));
        fpga3_d25_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga3_d25_dcb_3, 5, 5, 1, 1);

        fpga4_d25_dcb_3 = new QLabel(DCB3);
        fpga4_d25_dcb_3->setObjectName(QString::fromUtf8("fpga4_d25_dcb_3"));
        fpga4_d25_dcb_3->setMaximumSize(QSize(46, 40));
        fpga4_d25_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga4_d25_dcb_3, 5, 7, 1, 1);

        fpga5_d25_dcb_3 = new QLabel(DCB3);
        fpga5_d25_dcb_3->setObjectName(QString::fromUtf8("fpga5_d25_dcb_3"));
        fpga5_d25_dcb_3->setMaximumSize(QSize(46, 40));
        fpga5_d25_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga5_d25_dcb_3, 5, 9, 1, 1);

        label_49 = new QLabel(DCB3);
        label_49->setObjectName(QString::fromUtf8("label_49"));
        label_49->setFont(font);

        gridLayout_17->addWidget(label_49, 6, 0, 1, 1);

        fpga1_d33_dcb_3 = new QLabel(DCB3);
        fpga1_d33_dcb_3->setObjectName(QString::fromUtf8("fpga1_d33_dcb_3"));
        fpga1_d33_dcb_3->setMaximumSize(QSize(46, 40));
        fpga1_d33_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga1_d33_dcb_3, 6, 1, 1, 1);

        fpga2_d33_dcb_3 = new QLabel(DCB3);
        fpga2_d33_dcb_3->setObjectName(QString::fromUtf8("fpga2_d33_dcb_3"));
        fpga2_d33_dcb_3->setMaximumSize(QSize(46, 40));
        fpga2_d33_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga2_d33_dcb_3, 6, 3, 1, 1);

        fpga3_d33_dcb_3 = new QLabel(DCB3);
        fpga3_d33_dcb_3->setObjectName(QString::fromUtf8("fpga3_d33_dcb_3"));
        fpga3_d33_dcb_3->setMaximumSize(QSize(46, 40));
        fpga3_d33_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga3_d33_dcb_3, 6, 5, 1, 1);

        fpga4_d33_dcb_3 = new QLabel(DCB3);
        fpga4_d33_dcb_3->setObjectName(QString::fromUtf8("fpga4_d33_dcb_3"));
        fpga4_d33_dcb_3->setMaximumSize(QSize(46, 40));
        fpga4_d33_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga4_d33_dcb_3, 6, 7, 1, 1);

        fpga5_d33_dcb_3 = new QLabel(DCB3);
        fpga5_d33_dcb_3->setObjectName(QString::fromUtf8("fpga5_d33_dcb_3"));
        fpga5_d33_dcb_3->setMaximumSize(QSize(46, 40));
        fpga5_d33_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga5_d33_dcb_3, 6, 9, 1, 1);

        label_54 = new QLabel(DCB3);
        label_54->setObjectName(QString::fromUtf8("label_54"));
        label_54->setFont(font);

        gridLayout_17->addWidget(label_54, 7, 0, 1, 1);

        fpga1_d5_dcb_3 = new QLabel(DCB3);
        fpga1_d5_dcb_3->setObjectName(QString::fromUtf8("fpga1_d5_dcb_3"));
        fpga1_d5_dcb_3->setMaximumSize(QSize(46, 40));
        fpga1_d5_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga1_d5_dcb_3, 7, 1, 1, 1);

        fpga2_d5_dcb_3 = new QLabel(DCB3);
        fpga2_d5_dcb_3->setObjectName(QString::fromUtf8("fpga2_d5_dcb_3"));
        fpga2_d5_dcb_3->setMaximumSize(QSize(46, 40));
        fpga2_d5_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga2_d5_dcb_3, 7, 3, 1, 1);

        fpga3_d5_dcb_3 = new QLabel(DCB3);
        fpga3_d5_dcb_3->setObjectName(QString::fromUtf8("fpga3_d5_dcb_3"));
        fpga3_d5_dcb_3->setMaximumSize(QSize(46, 40));
        fpga3_d5_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga3_d5_dcb_3, 7, 5, 1, 1);

        fpga4_d5_dcb_3 = new QLabel(DCB3);
        fpga4_d5_dcb_3->setObjectName(QString::fromUtf8("fpga4_d5_dcb_3"));
        fpga4_d5_dcb_3->setMaximumSize(QSize(46, 40));
        fpga4_d5_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga4_d5_dcb_3, 7, 7, 1, 1);

        fpga5_d5_dcb_3 = new QLabel(DCB3);
        fpga5_d5_dcb_3->setObjectName(QString::fromUtf8("fpga5_d5_dcb_3"));
        fpga5_d5_dcb_3->setMaximumSize(QSize(46, 40));
        fpga5_d5_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga5_d5_dcb_3, 7, 9, 1, 1);

        label_44 = new QLabel(DCB3);
        label_44->setObjectName(QString::fromUtf8("label_44"));
        label_44->setFont(font);

        gridLayout_17->addWidget(label_44, 8, 0, 1, 1);

        fpga1_a18_dcb_3 = new QLabel(DCB3);
        fpga1_a18_dcb_3->setObjectName(QString::fromUtf8("fpga1_a18_dcb_3"));
        fpga1_a18_dcb_3->setMaximumSize(QSize(46, 40));
        fpga1_a18_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga1_a18_dcb_3, 8, 1, 1, 1);

        fpga2_a18_dcb_3 = new QLabel(DCB3);
        fpga2_a18_dcb_3->setObjectName(QString::fromUtf8("fpga2_a18_dcb_3"));
        fpga2_a18_dcb_3->setMaximumSize(QSize(46, 40));
        fpga2_a18_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga2_a18_dcb_3, 8, 3, 1, 1);

        fpga3_a18_dcb_3 = new QLabel(DCB3);
        fpga3_a18_dcb_3->setObjectName(QString::fromUtf8("fpga3_a18_dcb_3"));
        fpga3_a18_dcb_3->setMaximumSize(QSize(46, 40));
        fpga3_a18_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga3_a18_dcb_3, 8, 5, 1, 1);

        fpga4_a18_dcb_3 = new QLabel(DCB3);
        fpga4_a18_dcb_3->setObjectName(QString::fromUtf8("fpga4_a18_dcb_3"));
        fpga4_a18_dcb_3->setMaximumSize(QSize(46, 40));
        fpga4_a18_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga4_a18_dcb_3, 8, 7, 1, 1);

        fpga5_a18_dcb_3 = new QLabel(DCB3);
        fpga5_a18_dcb_3->setObjectName(QString::fromUtf8("fpga5_a18_dcb_3"));
        fpga5_a18_dcb_3->setMaximumSize(QSize(46, 40));
        fpga5_a18_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga5_a18_dcb_3, 8, 9, 1, 1);

        label_45 = new QLabel(DCB3);
        label_45->setObjectName(QString::fromUtf8("label_45"));
        label_45->setFont(font);

        gridLayout_17->addWidget(label_45, 9, 0, 1, 1);

        fpga1_a33_dcb_3 = new QLabel(DCB3);
        fpga1_a33_dcb_3->setObjectName(QString::fromUtf8("fpga1_a33_dcb_3"));
        fpga1_a33_dcb_3->setMaximumSize(QSize(46, 40));
        fpga1_a33_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga1_a33_dcb_3, 9, 1, 1, 1);

        fpga2_a33_dcb_3 = new QLabel(DCB3);
        fpga2_a33_dcb_3->setObjectName(QString::fromUtf8("fpga2_a33_dcb_3"));
        fpga2_a33_dcb_3->setMaximumSize(QSize(46, 40));
        fpga2_a33_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga2_a33_dcb_3, 9, 3, 1, 1);

        fpga3_a33_dcb_3 = new QLabel(DCB3);
        fpga3_a33_dcb_3->setObjectName(QString::fromUtf8("fpga3_a33_dcb_3"));
        fpga3_a33_dcb_3->setMaximumSize(QSize(46, 40));
        fpga3_a33_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga3_a33_dcb_3, 9, 5, 1, 1);

        fpga4_a33_dcb_3 = new QLabel(DCB3);
        fpga4_a33_dcb_3->setObjectName(QString::fromUtf8("fpga4_a33_dcb_3"));
        fpga4_a33_dcb_3->setMaximumSize(QSize(46, 40));
        fpga4_a33_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga4_a33_dcb_3, 9, 7, 1, 1);

        fpga5_a33_dcb_3 = new QLabel(DCB3);
        fpga5_a33_dcb_3->setObjectName(QString::fromUtf8("fpga5_a33_dcb_3"));
        fpga5_a33_dcb_3->setMaximumSize(QSize(46, 40));
        fpga5_a33_dcb_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_17->addWidget(fpga5_a33_dcb_3, 9, 9, 1, 1);

        tab_dcb->addTab(DCB3, QString());
        DCB4 = new QWidget();
        DCB4->setObjectName(QString::fromUtf8("DCB4"));
        gridLayout_18 = new QGridLayout(DCB4);
        gridLayout_18->setObjectName(QString::fromUtf8("gridLayout_18"));
        horizontalSpacer_29 = new QSpacerItem(129, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_18->addItem(horizontalSpacer_29, 0, 0, 1, 1);

        label_68 = new QLabel(DCB4);
        label_68->setObjectName(QString::fromUtf8("label_68"));
        label_68->setMaximumSize(QSize(300, 16777215));
        label_68->setFont(font);
        label_68->setAlignment(Qt::AlignCenter);

        gridLayout_18->addWidget(label_68, 0, 1, 1, 1);

        horizontalSpacer_25 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_18->addItem(horizontalSpacer_25, 0, 2, 1, 1);

        label_70 = new QLabel(DCB4);
        label_70->setObjectName(QString::fromUtf8("label_70"));
        label_70->setFont(font);
        label_70->setAlignment(Qt::AlignCenter);

        gridLayout_18->addWidget(label_70, 0, 3, 1, 1);

        horizontalSpacer_27 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_18->addItem(horizontalSpacer_27, 0, 4, 1, 1);

        label_63 = new QLabel(DCB4);
        label_63->setObjectName(QString::fromUtf8("label_63"));
        label_63->setFont(font);
        label_63->setAlignment(Qt::AlignCenter);

        gridLayout_18->addWidget(label_63, 0, 5, 1, 1);

        horizontalSpacer_28 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_18->addItem(horizontalSpacer_28, 0, 6, 1, 1);

        label_67 = new QLabel(DCB4);
        label_67->setObjectName(QString::fromUtf8("label_67"));
        label_67->setFont(font);
        label_67->setAlignment(Qt::AlignCenter);

        gridLayout_18->addWidget(label_67, 0, 7, 1, 1);

        horizontalSpacer_30 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_18->addItem(horizontalSpacer_30, 0, 8, 1, 1);

        label_61 = new QLabel(DCB4);
        label_61->setObjectName(QString::fromUtf8("label_61"));
        label_61->setFont(font);
        label_61->setAlignment(Qt::AlignCenter);

        gridLayout_18->addWidget(label_61, 0, 9, 1, 1);

        horizontalSpacer_26 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_18->addItem(horizontalSpacer_26, 0, 10, 1, 1);

        label_59 = new QLabel(DCB4);
        label_59->setObjectName(QString::fromUtf8("label_59"));
        label_59->setFont(font);

        gridLayout_18->addWidget(label_59, 1, 0, 1, 1);

        fpga1_con_dcb_4 = new QLabel(DCB4);
        fpga1_con_dcb_4->setObjectName(QString::fromUtf8("fpga1_con_dcb_4"));
        fpga1_con_dcb_4->setMaximumSize(QSize(46, 40));
        fpga1_con_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga1_con_dcb_4, 1, 1, 1, 1);

        fpga2_con_dcb_4 = new QLabel(DCB4);
        fpga2_con_dcb_4->setObjectName(QString::fromUtf8("fpga2_con_dcb_4"));
        fpga2_con_dcb_4->setMaximumSize(QSize(46, 40));
        fpga2_con_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga2_con_dcb_4, 1, 3, 1, 1);

        fpga3_con_dcb_4 = new QLabel(DCB4);
        fpga3_con_dcb_4->setObjectName(QString::fromUtf8("fpga3_con_dcb_4"));
        fpga3_con_dcb_4->setMaximumSize(QSize(46, 40));
        fpga3_con_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga3_con_dcb_4, 1, 5, 1, 1);

        fpga4_con_dcb_4 = new QLabel(DCB4);
        fpga4_con_dcb_4->setObjectName(QString::fromUtf8("fpga4_con_dcb_4"));
        fpga4_con_dcb_4->setMaximumSize(QSize(46, 40));
        fpga4_con_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga4_con_dcb_4, 1, 7, 1, 1);

        fpga5_con_dcb_4 = new QLabel(DCB4);
        fpga5_con_dcb_4->setObjectName(QString::fromUtf8("fpga5_con_dcb_4"));
        fpga5_con_dcb_4->setMaximumSize(QSize(46, 40));
        fpga5_con_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga5_con_dcb_4, 1, 9, 1, 1);

        label_58 = new QLabel(DCB4);
        label_58->setObjectName(QString::fromUtf8("label_58"));
        label_58->setFont(font);

        gridLayout_18->addWidget(label_58, 2, 0, 1, 1);

        fpga1_hlt_dcb_4 = new QLabel(DCB4);
        fpga1_hlt_dcb_4->setObjectName(QString::fromUtf8("fpga1_hlt_dcb_4"));
        fpga1_hlt_dcb_4->setMaximumSize(QSize(46, 40));
        fpga1_hlt_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga1_hlt_dcb_4, 2, 1, 1, 1);

        fpga2_hlt_dcb_4 = new QLabel(DCB4);
        fpga2_hlt_dcb_4->setObjectName(QString::fromUtf8("fpga2_hlt_dcb_4"));
        fpga2_hlt_dcb_4->setMaximumSize(QSize(46, 40));
        fpga2_hlt_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga2_hlt_dcb_4, 2, 3, 1, 1);

        fpga3_hlt_dcb_4 = new QLabel(DCB4);
        fpga3_hlt_dcb_4->setObjectName(QString::fromUtf8("fpga3_hlt_dcb_4"));
        fpga3_hlt_dcb_4->setMaximumSize(QSize(46, 40));
        fpga3_hlt_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga3_hlt_dcb_4, 2, 5, 1, 1);

        fpga4_hlt_dcb_4 = new QLabel(DCB4);
        fpga4_hlt_dcb_4->setObjectName(QString::fromUtf8("fpga4_hlt_dcb_4"));
        fpga4_hlt_dcb_4->setMaximumSize(QSize(46, 40));
        fpga4_hlt_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga4_hlt_dcb_4, 2, 7, 1, 1);

        fpga5_hlt_dcb_4 = new QLabel(DCB4);
        fpga5_hlt_dcb_4->setObjectName(QString::fromUtf8("fpga5_hlt_dcb_4"));
        fpga5_hlt_dcb_4->setMaximumSize(QSize(46, 40));
        fpga5_hlt_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga5_hlt_dcb_4, 2, 9, 1, 1);

        label_66 = new QLabel(DCB4);
        label_66->setObjectName(QString::fromUtf8("label_66"));
        label_66->setFont(font);

        gridLayout_18->addWidget(label_66, 3, 0, 1, 1);

        fpga1_rdy_dcb_4 = new QLabel(DCB4);
        fpga1_rdy_dcb_4->setObjectName(QString::fromUtf8("fpga1_rdy_dcb_4"));
        fpga1_rdy_dcb_4->setMaximumSize(QSize(46, 40));
        fpga1_rdy_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga1_rdy_dcb_4, 3, 1, 1, 1);

        fpga2_rdy_dcb_4 = new QLabel(DCB4);
        fpga2_rdy_dcb_4->setObjectName(QString::fromUtf8("fpga2_rdy_dcb_4"));
        fpga2_rdy_dcb_4->setMaximumSize(QSize(46, 40));
        fpga2_rdy_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga2_rdy_dcb_4, 3, 3, 1, 1);

        fpga3_rdy_dcb_4 = new QLabel(DCB4);
        fpga3_rdy_dcb_4->setObjectName(QString::fromUtf8("fpga3_rdy_dcb_4"));
        fpga3_rdy_dcb_4->setMaximumSize(QSize(46, 40));
        fpga3_rdy_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga3_rdy_dcb_4, 3, 5, 1, 1);

        fpga4_rdy_dcb_4 = new QLabel(DCB4);
        fpga4_rdy_dcb_4->setObjectName(QString::fromUtf8("fpga4_rdy_dcb_4"));
        fpga4_rdy_dcb_4->setMaximumSize(QSize(46, 40));
        fpga4_rdy_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga4_rdy_dcb_4, 3, 7, 1, 1);

        fpga5_rdy_dcb_4 = new QLabel(DCB4);
        fpga5_rdy_dcb_4->setObjectName(QString::fromUtf8("fpga5_rdy_dcb_4"));
        fpga5_rdy_dcb_4->setMaximumSize(QSize(46, 40));
        fpga5_rdy_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga5_rdy_dcb_4, 3, 9, 1, 1);

        label_64 = new QLabel(DCB4);
        label_64->setObjectName(QString::fromUtf8("label_64"));
        label_64->setFont(font);

        gridLayout_18->addWidget(label_64, 4, 0, 1, 1);

        fpga1_d18_dcb_4 = new QLabel(DCB4);
        fpga1_d18_dcb_4->setObjectName(QString::fromUtf8("fpga1_d18_dcb_4"));
        fpga1_d18_dcb_4->setMaximumSize(QSize(46, 40));
        fpga1_d18_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga1_d18_dcb_4, 4, 1, 1, 1);

        fpga2_d18_dcb_4 = new QLabel(DCB4);
        fpga2_d18_dcb_4->setObjectName(QString::fromUtf8("fpga2_d18_dcb_4"));
        fpga2_d18_dcb_4->setMaximumSize(QSize(46, 40));
        fpga2_d18_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga2_d18_dcb_4, 4, 3, 1, 1);

        fpga3_d18_dcb_4 = new QLabel(DCB4);
        fpga3_d18_dcb_4->setObjectName(QString::fromUtf8("fpga3_d18_dcb_4"));
        fpga3_d18_dcb_4->setMaximumSize(QSize(46, 40));
        fpga3_d18_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga3_d18_dcb_4, 4, 5, 1, 1);

        fpga4_d18_dcb_4 = new QLabel(DCB4);
        fpga4_d18_dcb_4->setObjectName(QString::fromUtf8("fpga4_d18_dcb_4"));
        fpga4_d18_dcb_4->setMaximumSize(QSize(46, 40));
        fpga4_d18_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga4_d18_dcb_4, 4, 7, 1, 1);

        fpga5_d18_dcb_4 = new QLabel(DCB4);
        fpga5_d18_dcb_4->setObjectName(QString::fromUtf8("fpga5_d18_dcb_4"));
        fpga5_d18_dcb_4->setMaximumSize(QSize(46, 40));
        fpga5_d18_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga5_d18_dcb_4, 4, 9, 1, 1);

        label_71 = new QLabel(DCB4);
        label_71->setObjectName(QString::fromUtf8("label_71"));
        label_71->setFont(font);

        gridLayout_18->addWidget(label_71, 5, 0, 1, 1);

        fpga1_d25_dcb_4 = new QLabel(DCB4);
        fpga1_d25_dcb_4->setObjectName(QString::fromUtf8("fpga1_d25_dcb_4"));
        fpga1_d25_dcb_4->setMaximumSize(QSize(46, 40));
        fpga1_d25_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga1_d25_dcb_4, 5, 1, 1, 1);

        fpga2_d25_dcb_4 = new QLabel(DCB4);
        fpga2_d25_dcb_4->setObjectName(QString::fromUtf8("fpga2_d25_dcb_4"));
        fpga2_d25_dcb_4->setMaximumSize(QSize(46, 40));
        fpga2_d25_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga2_d25_dcb_4, 5, 3, 1, 1);

        fpga3_d25_dcb_4 = new QLabel(DCB4);
        fpga3_d25_dcb_4->setObjectName(QString::fromUtf8("fpga3_d25_dcb_4"));
        fpga3_d25_dcb_4->setMaximumSize(QSize(46, 40));
        fpga3_d25_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga3_d25_dcb_4, 5, 5, 1, 1);

        fpga4_d25_dcb_4 = new QLabel(DCB4);
        fpga4_d25_dcb_4->setObjectName(QString::fromUtf8("fpga4_d25_dcb_4"));
        fpga4_d25_dcb_4->setMaximumSize(QSize(46, 40));
        fpga4_d25_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga4_d25_dcb_4, 5, 7, 1, 1);

        fpga5_d25_dcb_4 = new QLabel(DCB4);
        fpga5_d25_dcb_4->setObjectName(QString::fromUtf8("fpga5_d25_dcb_4"));
        fpga5_d25_dcb_4->setMaximumSize(QSize(46, 40));
        fpga5_d25_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga5_d25_dcb_4, 5, 9, 1, 1);

        label_62 = new QLabel(DCB4);
        label_62->setObjectName(QString::fromUtf8("label_62"));
        label_62->setFont(font);

        gridLayout_18->addWidget(label_62, 6, 0, 1, 1);

        fpga1_d33_dcb_4 = new QLabel(DCB4);
        fpga1_d33_dcb_4->setObjectName(QString::fromUtf8("fpga1_d33_dcb_4"));
        fpga1_d33_dcb_4->setMaximumSize(QSize(46, 40));
        fpga1_d33_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga1_d33_dcb_4, 6, 1, 1, 1);

        fpga2_d33_dcb_4 = new QLabel(DCB4);
        fpga2_d33_dcb_4->setObjectName(QString::fromUtf8("fpga2_d33_dcb_4"));
        fpga2_d33_dcb_4->setMaximumSize(QSize(46, 40));
        fpga2_d33_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga2_d33_dcb_4, 6, 3, 1, 1);

        fpga3_d33_dcb_4 = new QLabel(DCB4);
        fpga3_d33_dcb_4->setObjectName(QString::fromUtf8("fpga3_d33_dcb_4"));
        fpga3_d33_dcb_4->setMaximumSize(QSize(46, 40));
        fpga3_d33_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga3_d33_dcb_4, 6, 5, 1, 1);

        fpga4_d33_dcb_4 = new QLabel(DCB4);
        fpga4_d33_dcb_4->setObjectName(QString::fromUtf8("fpga4_d33_dcb_4"));
        fpga4_d33_dcb_4->setMaximumSize(QSize(46, 40));
        fpga4_d33_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga4_d33_dcb_4, 6, 7, 1, 1);

        fpga5_d33_dcb_4 = new QLabel(DCB4);
        fpga5_d33_dcb_4->setObjectName(QString::fromUtf8("fpga5_d33_dcb_4"));
        fpga5_d33_dcb_4->setMaximumSize(QSize(46, 40));
        fpga5_d33_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga5_d33_dcb_4, 6, 9, 1, 1);

        label_65 = new QLabel(DCB4);
        label_65->setObjectName(QString::fromUtf8("label_65"));
        label_65->setFont(font);

        gridLayout_18->addWidget(label_65, 7, 0, 1, 1);

        fpga1_d5_dcb_4 = new QLabel(DCB4);
        fpga1_d5_dcb_4->setObjectName(QString::fromUtf8("fpga1_d5_dcb_4"));
        fpga1_d5_dcb_4->setMaximumSize(QSize(46, 40));
        fpga1_d5_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga1_d5_dcb_4, 7, 1, 1, 1);

        fpga2_d5_dcb_4 = new QLabel(DCB4);
        fpga2_d5_dcb_4->setObjectName(QString::fromUtf8("fpga2_d5_dcb_4"));
        fpga2_d5_dcb_4->setMaximumSize(QSize(46, 40));
        fpga2_d5_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga2_d5_dcb_4, 7, 3, 1, 1);

        fpga3_d5_dcb_4 = new QLabel(DCB4);
        fpga3_d5_dcb_4->setObjectName(QString::fromUtf8("fpga3_d5_dcb_4"));
        fpga3_d5_dcb_4->setMaximumSize(QSize(46, 40));
        fpga3_d5_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga3_d5_dcb_4, 7, 5, 1, 1);

        fpga4_d5_dcb_4 = new QLabel(DCB4);
        fpga4_d5_dcb_4->setObjectName(QString::fromUtf8("fpga4_d5_dcb_4"));
        fpga4_d5_dcb_4->setMaximumSize(QSize(46, 40));
        fpga4_d5_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga4_d5_dcb_4, 7, 7, 1, 1);

        fpga5_d5_dcb_4 = new QLabel(DCB4);
        fpga5_d5_dcb_4->setObjectName(QString::fromUtf8("fpga5_d5_dcb_4"));
        fpga5_d5_dcb_4->setMaximumSize(QSize(46, 40));
        fpga5_d5_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga5_d5_dcb_4, 7, 9, 1, 1);

        label_69 = new QLabel(DCB4);
        label_69->setObjectName(QString::fromUtf8("label_69"));
        label_69->setFont(font);

        gridLayout_18->addWidget(label_69, 8, 0, 1, 1);

        fpga1_a18_dcb_4 = new QLabel(DCB4);
        fpga1_a18_dcb_4->setObjectName(QString::fromUtf8("fpga1_a18_dcb_4"));
        fpga1_a18_dcb_4->setMaximumSize(QSize(46, 40));
        fpga1_a18_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga1_a18_dcb_4, 8, 1, 1, 1);

        fpga2_a18_dcb_4 = new QLabel(DCB4);
        fpga2_a18_dcb_4->setObjectName(QString::fromUtf8("fpga2_a18_dcb_4"));
        fpga2_a18_dcb_4->setMaximumSize(QSize(46, 40));
        fpga2_a18_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga2_a18_dcb_4, 8, 3, 1, 1);

        fpga3_a18_dcb_4 = new QLabel(DCB4);
        fpga3_a18_dcb_4->setObjectName(QString::fromUtf8("fpga3_a18_dcb_4"));
        fpga3_a18_dcb_4->setMaximumSize(QSize(46, 40));
        fpga3_a18_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga3_a18_dcb_4, 8, 5, 1, 1);

        fpga4_a18_dcb_4 = new QLabel(DCB4);
        fpga4_a18_dcb_4->setObjectName(QString::fromUtf8("fpga4_a18_dcb_4"));
        fpga4_a18_dcb_4->setMaximumSize(QSize(46, 40));
        fpga4_a18_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga4_a18_dcb_4, 8, 7, 1, 1);

        fpga5_a18_dcb_4 = new QLabel(DCB4);
        fpga5_a18_dcb_4->setObjectName(QString::fromUtf8("fpga5_a18_dcb_4"));
        fpga5_a18_dcb_4->setMaximumSize(QSize(46, 40));
        fpga5_a18_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga5_a18_dcb_4, 8, 9, 1, 1);

        label_60 = new QLabel(DCB4);
        label_60->setObjectName(QString::fromUtf8("label_60"));
        label_60->setFont(font);

        gridLayout_18->addWidget(label_60, 9, 0, 1, 1);

        fpga1_a33_dcb_4 = new QLabel(DCB4);
        fpga1_a33_dcb_4->setObjectName(QString::fromUtf8("fpga1_a33_dcb_4"));
        fpga1_a33_dcb_4->setMaximumSize(QSize(46, 40));
        fpga1_a33_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga1_a33_dcb_4, 9, 1, 1, 1);

        fpga2_a33_dcb_4 = new QLabel(DCB4);
        fpga2_a33_dcb_4->setObjectName(QString::fromUtf8("fpga2_a33_dcb_4"));
        fpga2_a33_dcb_4->setMaximumSize(QSize(46, 40));
        fpga2_a33_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga2_a33_dcb_4, 9, 3, 1, 1);

        fpga3_a33_dcb_4 = new QLabel(DCB4);
        fpga3_a33_dcb_4->setObjectName(QString::fromUtf8("fpga3_a33_dcb_4"));
        fpga3_a33_dcb_4->setMaximumSize(QSize(46, 40));
        fpga3_a33_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga3_a33_dcb_4, 9, 5, 1, 1);

        fpga4_a33_dcb_4 = new QLabel(DCB4);
        fpga4_a33_dcb_4->setObjectName(QString::fromUtf8("fpga4_a33_dcb_4"));
        fpga4_a33_dcb_4->setMaximumSize(QSize(46, 40));
        fpga4_a33_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga4_a33_dcb_4, 9, 7, 1, 1);

        fpga5_a33_dcb_4 = new QLabel(DCB4);
        fpga5_a33_dcb_4->setObjectName(QString::fromUtf8("fpga5_a33_dcb_4"));
        fpga5_a33_dcb_4->setMaximumSize(QSize(46, 40));
        fpga5_a33_dcb_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_18->addWidget(fpga5_a33_dcb_4, 9, 9, 1, 1);

        tab_dcb->addTab(DCB4, QString());
        DCB5 = new QWidget();
        DCB5->setObjectName(QString::fromUtf8("DCB5"));
        gridLayout_19 = new QGridLayout(DCB5);
        gridLayout_19->setObjectName(QString::fromUtf8("gridLayout_19"));
        horizontalSpacer_32 = new QSpacerItem(129, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_19->addItem(horizontalSpacer_32, 0, 0, 1, 1);

        label_74 = new QLabel(DCB5);
        label_74->setObjectName(QString::fromUtf8("label_74"));
        label_74->setMaximumSize(QSize(300, 16777215));
        label_74->setFont(font);
        label_74->setAlignment(Qt::AlignCenter);

        gridLayout_19->addWidget(label_74, 0, 1, 1, 1);

        horizontalSpacer_31 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_19->addItem(horizontalSpacer_31, 0, 2, 1, 1);

        label_85 = new QLabel(DCB5);
        label_85->setObjectName(QString::fromUtf8("label_85"));
        label_85->setFont(font);
        label_85->setAlignment(Qt::AlignCenter);

        gridLayout_19->addWidget(label_85, 0, 3, 1, 1);

        horizontalSpacer_34 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_19->addItem(horizontalSpacer_34, 0, 4, 1, 1);

        label_82 = new QLabel(DCB5);
        label_82->setObjectName(QString::fromUtf8("label_82"));
        label_82->setFont(font);
        label_82->setAlignment(Qt::AlignCenter);

        gridLayout_19->addWidget(label_82, 0, 5, 1, 1);

        horizontalSpacer_33 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_19->addItem(horizontalSpacer_33, 0, 6, 1, 1);

        label_75 = new QLabel(DCB5);
        label_75->setObjectName(QString::fromUtf8("label_75"));
        label_75->setFont(font);
        label_75->setAlignment(Qt::AlignCenter);

        gridLayout_19->addWidget(label_75, 0, 7, 1, 1);

        horizontalSpacer_35 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_19->addItem(horizontalSpacer_35, 0, 8, 1, 1);

        label_77 = new QLabel(DCB5);
        label_77->setObjectName(QString::fromUtf8("label_77"));
        label_77->setFont(font);
        label_77->setAlignment(Qt::AlignCenter);

        gridLayout_19->addWidget(label_77, 0, 9, 1, 1);

        horizontalSpacer_36 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_19->addItem(horizontalSpacer_36, 0, 10, 1, 1);

        label_73 = new QLabel(DCB5);
        label_73->setObjectName(QString::fromUtf8("label_73"));
        label_73->setFont(font);

        gridLayout_19->addWidget(label_73, 1, 0, 1, 1);

        fpga1_con_dcb_5 = new QLabel(DCB5);
        fpga1_con_dcb_5->setObjectName(QString::fromUtf8("fpga1_con_dcb_5"));
        fpga1_con_dcb_5->setMaximumSize(QSize(46, 40));
        fpga1_con_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga1_con_dcb_5, 1, 1, 1, 1);

        fpga2_con_dcb_5 = new QLabel(DCB5);
        fpga2_con_dcb_5->setObjectName(QString::fromUtf8("fpga2_con_dcb_5"));
        fpga2_con_dcb_5->setMaximumSize(QSize(46, 40));
        fpga2_con_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga2_con_dcb_5, 1, 3, 1, 1);

        fpga3_con_dcb_5 = new QLabel(DCB5);
        fpga3_con_dcb_5->setObjectName(QString::fromUtf8("fpga3_con_dcb_5"));
        fpga3_con_dcb_5->setMaximumSize(QSize(46, 40));
        fpga3_con_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga3_con_dcb_5, 1, 5, 1, 1);

        fpga4_con_dcb_5 = new QLabel(DCB5);
        fpga4_con_dcb_5->setObjectName(QString::fromUtf8("fpga4_con_dcb_5"));
        fpga4_con_dcb_5->setMaximumSize(QSize(46, 40));
        fpga4_con_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga4_con_dcb_5, 1, 7, 1, 1);

        fpga5_con_dcb_5 = new QLabel(DCB5);
        fpga5_con_dcb_5->setObjectName(QString::fromUtf8("fpga5_con_dcb_5"));
        fpga5_con_dcb_5->setMaximumSize(QSize(46, 40));
        fpga5_con_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga5_con_dcb_5, 1, 9, 1, 1);

        label_84 = new QLabel(DCB5);
        label_84->setObjectName(QString::fromUtf8("label_84"));
        label_84->setFont(font);

        gridLayout_19->addWidget(label_84, 2, 0, 1, 1);

        fpga1_hlt_dcb_5 = new QLabel(DCB5);
        fpga1_hlt_dcb_5->setObjectName(QString::fromUtf8("fpga1_hlt_dcb_5"));
        fpga1_hlt_dcb_5->setMaximumSize(QSize(46, 40));
        fpga1_hlt_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga1_hlt_dcb_5, 2, 1, 1, 1);

        fpga2_hlt_dcb_5 = new QLabel(DCB5);
        fpga2_hlt_dcb_5->setObjectName(QString::fromUtf8("fpga2_hlt_dcb_5"));
        fpga2_hlt_dcb_5->setMaximumSize(QSize(46, 40));
        fpga2_hlt_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga2_hlt_dcb_5, 2, 3, 1, 1);

        fpga3_hlt_dcb_5 = new QLabel(DCB5);
        fpga3_hlt_dcb_5->setObjectName(QString::fromUtf8("fpga3_hlt_dcb_5"));
        fpga3_hlt_dcb_5->setMaximumSize(QSize(46, 40));
        fpga3_hlt_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga3_hlt_dcb_5, 2, 5, 1, 1);

        fpga4_hlt_dcb_5 = new QLabel(DCB5);
        fpga4_hlt_dcb_5->setObjectName(QString::fromUtf8("fpga4_hlt_dcb_5"));
        fpga4_hlt_dcb_5->setMaximumSize(QSize(46, 40));
        fpga4_hlt_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga4_hlt_dcb_5, 2, 7, 1, 1);

        fpga5_hlt_dcb_5 = new QLabel(DCB5);
        fpga5_hlt_dcb_5->setObjectName(QString::fromUtf8("fpga5_hlt_dcb_5"));
        fpga5_hlt_dcb_5->setMaximumSize(QSize(46, 40));
        fpga5_hlt_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga5_hlt_dcb_5, 2, 9, 1, 1);

        label_80 = new QLabel(DCB5);
        label_80->setObjectName(QString::fromUtf8("label_80"));
        label_80->setFont(font);

        gridLayout_19->addWidget(label_80, 3, 0, 1, 1);

        fpga1_rdy_dcb_5 = new QLabel(DCB5);
        fpga1_rdy_dcb_5->setObjectName(QString::fromUtf8("fpga1_rdy_dcb_5"));
        fpga1_rdy_dcb_5->setMaximumSize(QSize(46, 40));
        fpga1_rdy_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga1_rdy_dcb_5, 3, 1, 1, 1);

        fpga2_rdy_dcb_5 = new QLabel(DCB5);
        fpga2_rdy_dcb_5->setObjectName(QString::fromUtf8("fpga2_rdy_dcb_5"));
        fpga2_rdy_dcb_5->setMaximumSize(QSize(46, 40));
        fpga2_rdy_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga2_rdy_dcb_5, 3, 3, 1, 1);

        fpga3_rdy_dcb_5 = new QLabel(DCB5);
        fpga3_rdy_dcb_5->setObjectName(QString::fromUtf8("fpga3_rdy_dcb_5"));
        fpga3_rdy_dcb_5->setMaximumSize(QSize(46, 40));
        fpga3_rdy_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga3_rdy_dcb_5, 3, 5, 1, 1);

        fpga4_rdy_dcb_5 = new QLabel(DCB5);
        fpga4_rdy_dcb_5->setObjectName(QString::fromUtf8("fpga4_rdy_dcb_5"));
        fpga4_rdy_dcb_5->setMaximumSize(QSize(46, 40));
        fpga4_rdy_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga4_rdy_dcb_5, 3, 7, 1, 1);

        fpga5_rdy_dcb_5 = new QLabel(DCB5);
        fpga5_rdy_dcb_5->setObjectName(QString::fromUtf8("fpga5_rdy_dcb_5"));
        fpga5_rdy_dcb_5->setMaximumSize(QSize(46, 40));
        fpga5_rdy_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga5_rdy_dcb_5, 3, 9, 1, 1);

        label_78 = new QLabel(DCB5);
        label_78->setObjectName(QString::fromUtf8("label_78"));
        label_78->setFont(font);

        gridLayout_19->addWidget(label_78, 4, 0, 1, 1);

        fpga1_d18_dcb_5 = new QLabel(DCB5);
        fpga1_d18_dcb_5->setObjectName(QString::fromUtf8("fpga1_d18_dcb_5"));
        fpga1_d18_dcb_5->setMaximumSize(QSize(46, 40));
        fpga1_d18_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga1_d18_dcb_5, 4, 1, 1, 1);

        fpga2_d18_dcb_5 = new QLabel(DCB5);
        fpga2_d18_dcb_5->setObjectName(QString::fromUtf8("fpga2_d18_dcb_5"));
        fpga2_d18_dcb_5->setMaximumSize(QSize(46, 40));
        fpga2_d18_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga2_d18_dcb_5, 4, 3, 1, 1);

        fpga3_d18_dcb_5 = new QLabel(DCB5);
        fpga3_d18_dcb_5->setObjectName(QString::fromUtf8("fpga3_d18_dcb_5"));
        fpga3_d18_dcb_5->setMaximumSize(QSize(46, 40));
        fpga3_d18_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga3_d18_dcb_5, 4, 5, 1, 1);

        fpga4_d18_dcb_5 = new QLabel(DCB5);
        fpga4_d18_dcb_5->setObjectName(QString::fromUtf8("fpga4_d18_dcb_5"));
        fpga4_d18_dcb_5->setMaximumSize(QSize(46, 40));
        fpga4_d18_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga4_d18_dcb_5, 4, 7, 1, 1);

        fpga5_d18_dcb_5 = new QLabel(DCB5);
        fpga5_d18_dcb_5->setObjectName(QString::fromUtf8("fpga5_d18_dcb_5"));
        fpga5_d18_dcb_5->setMaximumSize(QSize(46, 40));
        fpga5_d18_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga5_d18_dcb_5, 4, 9, 1, 1);

        label_81 = new QLabel(DCB5);
        label_81->setObjectName(QString::fromUtf8("label_81"));
        label_81->setFont(font);

        gridLayout_19->addWidget(label_81, 5, 0, 1, 1);

        fpga1_d25_dcb_5 = new QLabel(DCB5);
        fpga1_d25_dcb_5->setObjectName(QString::fromUtf8("fpga1_d25_dcb_5"));
        fpga1_d25_dcb_5->setMaximumSize(QSize(46, 40));
        fpga1_d25_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga1_d25_dcb_5, 5, 1, 1, 1);

        fpga2_d25_dcb_5 = new QLabel(DCB5);
        fpga2_d25_dcb_5->setObjectName(QString::fromUtf8("fpga2_d25_dcb_5"));
        fpga2_d25_dcb_5->setMaximumSize(QSize(46, 40));
        fpga2_d25_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga2_d25_dcb_5, 5, 3, 1, 1);

        fpga3_d25_dcb_5 = new QLabel(DCB5);
        fpga3_d25_dcb_5->setObjectName(QString::fromUtf8("fpga3_d25_dcb_5"));
        fpga3_d25_dcb_5->setMaximumSize(QSize(46, 40));
        fpga3_d25_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga3_d25_dcb_5, 5, 5, 1, 1);

        fpga4_d25_dcb_5 = new QLabel(DCB5);
        fpga4_d25_dcb_5->setObjectName(QString::fromUtf8("fpga4_d25_dcb_5"));
        fpga4_d25_dcb_5->setMaximumSize(QSize(46, 40));
        fpga4_d25_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga4_d25_dcb_5, 5, 7, 1, 1);

        fpga5_d25_dcb_5 = new QLabel(DCB5);
        fpga5_d25_dcb_5->setObjectName(QString::fromUtf8("fpga5_d25_dcb_5"));
        fpga5_d25_dcb_5->setMaximumSize(QSize(46, 40));
        fpga5_d25_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga5_d25_dcb_5, 5, 9, 1, 1);

        label_72 = new QLabel(DCB5);
        label_72->setObjectName(QString::fromUtf8("label_72"));
        label_72->setFont(font);

        gridLayout_19->addWidget(label_72, 6, 0, 1, 1);

        fpga1_d33_dcb_5 = new QLabel(DCB5);
        fpga1_d33_dcb_5->setObjectName(QString::fromUtf8("fpga1_d33_dcb_5"));
        fpga1_d33_dcb_5->setMaximumSize(QSize(46, 40));
        fpga1_d33_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga1_d33_dcb_5, 6, 1, 1, 1);

        fpga2_d33_dcb_5 = new QLabel(DCB5);
        fpga2_d33_dcb_5->setObjectName(QString::fromUtf8("fpga2_d33_dcb_5"));
        fpga2_d33_dcb_5->setMaximumSize(QSize(46, 40));
        fpga2_d33_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga2_d33_dcb_5, 6, 3, 1, 1);

        fpga3_d33_dcb_5 = new QLabel(DCB5);
        fpga3_d33_dcb_5->setObjectName(QString::fromUtf8("fpga3_d33_dcb_5"));
        fpga3_d33_dcb_5->setMaximumSize(QSize(46, 40));
        fpga3_d33_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga3_d33_dcb_5, 6, 5, 1, 1);

        fpga4_d33_dcb_5 = new QLabel(DCB5);
        fpga4_d33_dcb_5->setObjectName(QString::fromUtf8("fpga4_d33_dcb_5"));
        fpga4_d33_dcb_5->setMaximumSize(QSize(46, 40));
        fpga4_d33_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga4_d33_dcb_5, 6, 7, 1, 1);

        fpga5_d33_dcb_5 = new QLabel(DCB5);
        fpga5_d33_dcb_5->setObjectName(QString::fromUtf8("fpga5_d33_dcb_5"));
        fpga5_d33_dcb_5->setMaximumSize(QSize(46, 40));
        fpga5_d33_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga5_d33_dcb_5, 6, 9, 1, 1);

        label_79 = new QLabel(DCB5);
        label_79->setObjectName(QString::fromUtf8("label_79"));
        label_79->setFont(font);

        gridLayout_19->addWidget(label_79, 7, 0, 1, 1);

        fpga1_d5_dcb_5 = new QLabel(DCB5);
        fpga1_d5_dcb_5->setObjectName(QString::fromUtf8("fpga1_d5_dcb_5"));
        fpga1_d5_dcb_5->setMaximumSize(QSize(46, 40));
        fpga1_d5_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga1_d5_dcb_5, 7, 1, 1, 1);

        fpga2_d5_dcb_5 = new QLabel(DCB5);
        fpga2_d5_dcb_5->setObjectName(QString::fromUtf8("fpga2_d5_dcb_5"));
        fpga2_d5_dcb_5->setMaximumSize(QSize(46, 40));
        fpga2_d5_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga2_d5_dcb_5, 7, 3, 1, 1);

        fpga3_d5_dcb_5 = new QLabel(DCB5);
        fpga3_d5_dcb_5->setObjectName(QString::fromUtf8("fpga3_d5_dcb_5"));
        fpga3_d5_dcb_5->setMaximumSize(QSize(46, 40));
        fpga3_d5_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga3_d5_dcb_5, 7, 5, 1, 1);

        fpga4_d5_dcb_5 = new QLabel(DCB5);
        fpga4_d5_dcb_5->setObjectName(QString::fromUtf8("fpga4_d5_dcb_5"));
        fpga4_d5_dcb_5->setMaximumSize(QSize(46, 40));
        fpga4_d5_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga4_d5_dcb_5, 7, 7, 1, 1);

        fpga5_d5_dcb_5 = new QLabel(DCB5);
        fpga5_d5_dcb_5->setObjectName(QString::fromUtf8("fpga5_d5_dcb_5"));
        fpga5_d5_dcb_5->setMaximumSize(QSize(46, 40));
        fpga5_d5_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga5_d5_dcb_5, 7, 9, 1, 1);

        label_83 = new QLabel(DCB5);
        label_83->setObjectName(QString::fromUtf8("label_83"));
        label_83->setFont(font);

        gridLayout_19->addWidget(label_83, 8, 0, 1, 1);

        fpga1_a18_dcb_5 = new QLabel(DCB5);
        fpga1_a18_dcb_5->setObjectName(QString::fromUtf8("fpga1_a18_dcb_5"));
        fpga1_a18_dcb_5->setMaximumSize(QSize(46, 40));
        fpga1_a18_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga1_a18_dcb_5, 8, 1, 1, 1);

        fpga2_a18_dcb_5 = new QLabel(DCB5);
        fpga2_a18_dcb_5->setObjectName(QString::fromUtf8("fpga2_a18_dcb_5"));
        fpga2_a18_dcb_5->setMaximumSize(QSize(46, 40));
        fpga2_a18_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga2_a18_dcb_5, 8, 3, 1, 1);

        fpga3_a18_dcb_5 = new QLabel(DCB5);
        fpga3_a18_dcb_5->setObjectName(QString::fromUtf8("fpga3_a18_dcb_5"));
        fpga3_a18_dcb_5->setMaximumSize(QSize(46, 40));
        fpga3_a18_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga3_a18_dcb_5, 8, 5, 1, 1);

        fpga4_a18_dcb_5 = new QLabel(DCB5);
        fpga4_a18_dcb_5->setObjectName(QString::fromUtf8("fpga4_a18_dcb_5"));
        fpga4_a18_dcb_5->setMaximumSize(QSize(46, 40));
        fpga4_a18_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga4_a18_dcb_5, 8, 7, 1, 1);

        fpga5_a18_dcb_5 = new QLabel(DCB5);
        fpga5_a18_dcb_5->setObjectName(QString::fromUtf8("fpga5_a18_dcb_5"));
        fpga5_a18_dcb_5->setMaximumSize(QSize(46, 40));
        fpga5_a18_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga5_a18_dcb_5, 8, 9, 1, 1);

        label_76 = new QLabel(DCB5);
        label_76->setObjectName(QString::fromUtf8("label_76"));
        label_76->setFont(font);

        gridLayout_19->addWidget(label_76, 9, 0, 1, 1);

        fpga1_a33_dcb_5 = new QLabel(DCB5);
        fpga1_a33_dcb_5->setObjectName(QString::fromUtf8("fpga1_a33_dcb_5"));
        fpga1_a33_dcb_5->setMaximumSize(QSize(46, 40));
        fpga1_a33_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga1_a33_dcb_5, 9, 1, 1, 1);

        fpga2_a33_dcb_5 = new QLabel(DCB5);
        fpga2_a33_dcb_5->setObjectName(QString::fromUtf8("fpga2_a33_dcb_5"));
        fpga2_a33_dcb_5->setMaximumSize(QSize(46, 40));
        fpga2_a33_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga2_a33_dcb_5, 9, 3, 1, 1);

        fpga3_a33_dcb_5 = new QLabel(DCB5);
        fpga3_a33_dcb_5->setObjectName(QString::fromUtf8("fpga3_a33_dcb_5"));
        fpga3_a33_dcb_5->setMaximumSize(QSize(46, 40));
        fpga3_a33_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga3_a33_dcb_5, 9, 5, 1, 1);

        fpga4_a33_dcb_5 = new QLabel(DCB5);
        fpga4_a33_dcb_5->setObjectName(QString::fromUtf8("fpga4_a33_dcb_5"));
        fpga4_a33_dcb_5->setMaximumSize(QSize(46, 40));
        fpga4_a33_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga4_a33_dcb_5, 9, 7, 1, 1);

        fpga5_a33_dcb_5 = new QLabel(DCB5);
        fpga5_a33_dcb_5->setObjectName(QString::fromUtf8("fpga5_a33_dcb_5"));
        fpga5_a33_dcb_5->setMaximumSize(QSize(46, 40));
        fpga5_a33_dcb_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(fpga5_a33_dcb_5, 9, 9, 1, 1);

        tab_dcb->addTab(DCB5, QString());
        DCB6 = new QWidget();
        DCB6->setObjectName(QString::fromUtf8("DCB6"));
        gridLayout_20 = new QGridLayout(DCB6);
        gridLayout_20->setObjectName(QString::fromUtf8("gridLayout_20"));
        horizontalSpacer_39 = new QSpacerItem(129, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_20->addItem(horizontalSpacer_39, 0, 0, 1, 1);

        label_97 = new QLabel(DCB6);
        label_97->setObjectName(QString::fromUtf8("label_97"));
        label_97->setMaximumSize(QSize(300, 16777215));
        label_97->setFont(font);
        label_97->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_97, 0, 1, 1, 1);

        horizontalSpacer_37 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_20->addItem(horizontalSpacer_37, 0, 2, 1, 1);

        label_98 = new QLabel(DCB6);
        label_98->setObjectName(QString::fromUtf8("label_98"));
        label_98->setFont(font);
        label_98->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_98, 0, 3, 1, 1);

        horizontalSpacer_40 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_20->addItem(horizontalSpacer_40, 0, 4, 1, 1);

        label_93 = new QLabel(DCB6);
        label_93->setObjectName(QString::fromUtf8("label_93"));
        label_93->setFont(font);
        label_93->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_93, 0, 5, 1, 1);

        horizontalSpacer_38 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_20->addItem(horizontalSpacer_38, 0, 6, 1, 1);

        label_86 = new QLabel(DCB6);
        label_86->setObjectName(QString::fromUtf8("label_86"));
        label_86->setFont(font);
        label_86->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_86, 0, 7, 1, 1);

        horizontalSpacer_41 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_20->addItem(horizontalSpacer_41, 0, 8, 1, 1);

        label_90 = new QLabel(DCB6);
        label_90->setObjectName(QString::fromUtf8("label_90"));
        label_90->setFont(font);
        label_90->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_90, 0, 9, 1, 1);

        horizontalSpacer_42 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_20->addItem(horizontalSpacer_42, 0, 10, 1, 1);

        label_91 = new QLabel(DCB6);
        label_91->setObjectName(QString::fromUtf8("label_91"));
        label_91->setFont(font);

        gridLayout_20->addWidget(label_91, 1, 0, 1, 1);

        fpga1_con_dcb_6 = new QLabel(DCB6);
        fpga1_con_dcb_6->setObjectName(QString::fromUtf8("fpga1_con_dcb_6"));
        fpga1_con_dcb_6->setMaximumSize(QSize(46, 40));
        fpga1_con_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga1_con_dcb_6, 1, 1, 1, 1);

        fpga2_con_dcb_6 = new QLabel(DCB6);
        fpga2_con_dcb_6->setObjectName(QString::fromUtf8("fpga2_con_dcb_6"));
        fpga2_con_dcb_6->setMaximumSize(QSize(46, 40));
        fpga2_con_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga2_con_dcb_6, 1, 3, 1, 1);

        fpga3_con_dcb_6 = new QLabel(DCB6);
        fpga3_con_dcb_6->setObjectName(QString::fromUtf8("fpga3_con_dcb_6"));
        fpga3_con_dcb_6->setMaximumSize(QSize(46, 40));
        fpga3_con_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga3_con_dcb_6, 1, 5, 1, 1);

        fpga4_con_dcb_6 = new QLabel(DCB6);
        fpga4_con_dcb_6->setObjectName(QString::fromUtf8("fpga4_con_dcb_6"));
        fpga4_con_dcb_6->setMaximumSize(QSize(46, 40));
        fpga4_con_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga4_con_dcb_6, 1, 7, 1, 1);

        fpga5_con_dcb_6 = new QLabel(DCB6);
        fpga5_con_dcb_6->setObjectName(QString::fromUtf8("fpga5_con_dcb_6"));
        fpga5_con_dcb_6->setMaximumSize(QSize(46, 40));
        fpga5_con_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga5_con_dcb_6, 1, 9, 1, 1);

        label_89 = new QLabel(DCB6);
        label_89->setObjectName(QString::fromUtf8("label_89"));
        label_89->setFont(font);

        gridLayout_20->addWidget(label_89, 2, 0, 1, 1);

        fpga1_hlt_dcb_6 = new QLabel(DCB6);
        fpga1_hlt_dcb_6->setObjectName(QString::fromUtf8("fpga1_hlt_dcb_6"));
        fpga1_hlt_dcb_6->setMaximumSize(QSize(46, 40));
        fpga1_hlt_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga1_hlt_dcb_6, 2, 1, 1, 1);

        fpga2_hlt_dcb_6 = new QLabel(DCB6);
        fpga2_hlt_dcb_6->setObjectName(QString::fromUtf8("fpga2_hlt_dcb_6"));
        fpga2_hlt_dcb_6->setMaximumSize(QSize(46, 40));
        fpga2_hlt_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga2_hlt_dcb_6, 2, 3, 1, 1);

        fpga3_hlt_dcb_6 = new QLabel(DCB6);
        fpga3_hlt_dcb_6->setObjectName(QString::fromUtf8("fpga3_hlt_dcb_6"));
        fpga3_hlt_dcb_6->setMaximumSize(QSize(46, 40));
        fpga3_hlt_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga3_hlt_dcb_6, 2, 5, 1, 1);

        fpga4_hlt_dcb_6 = new QLabel(DCB6);
        fpga4_hlt_dcb_6->setObjectName(QString::fromUtf8("fpga4_hlt_dcb_6"));
        fpga4_hlt_dcb_6->setMaximumSize(QSize(46, 40));
        fpga4_hlt_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga4_hlt_dcb_6, 2, 7, 1, 1);

        fpga5_hlt_dcb_6 = new QLabel(DCB6);
        fpga5_hlt_dcb_6->setObjectName(QString::fromUtf8("fpga5_hlt_dcb_6"));
        fpga5_hlt_dcb_6->setMaximumSize(QSize(46, 40));
        fpga5_hlt_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga5_hlt_dcb_6, 2, 9, 1, 1);

        label_92 = new QLabel(DCB6);
        label_92->setObjectName(QString::fromUtf8("label_92"));
        label_92->setFont(font);

        gridLayout_20->addWidget(label_92, 3, 0, 1, 1);

        fpga1_rdy_dcb_6 = new QLabel(DCB6);
        fpga1_rdy_dcb_6->setObjectName(QString::fromUtf8("fpga1_rdy_dcb_6"));
        fpga1_rdy_dcb_6->setMaximumSize(QSize(46, 40));
        fpga1_rdy_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga1_rdy_dcb_6, 3, 1, 1, 1);

        fpga2_rdy_dcb_6 = new QLabel(DCB6);
        fpga2_rdy_dcb_6->setObjectName(QString::fromUtf8("fpga2_rdy_dcb_6"));
        fpga2_rdy_dcb_6->setMaximumSize(QSize(46, 40));
        fpga2_rdy_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga2_rdy_dcb_6, 3, 3, 1, 1);

        fpga3_rdy_dcb_6 = new QLabel(DCB6);
        fpga3_rdy_dcb_6->setObjectName(QString::fromUtf8("fpga3_rdy_dcb_6"));
        fpga3_rdy_dcb_6->setMaximumSize(QSize(46, 40));
        fpga3_rdy_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga3_rdy_dcb_6, 3, 5, 1, 1);

        fpga4_rdy_dcb_6 = new QLabel(DCB6);
        fpga4_rdy_dcb_6->setObjectName(QString::fromUtf8("fpga4_rdy_dcb_6"));
        fpga4_rdy_dcb_6->setMaximumSize(QSize(46, 40));
        fpga4_rdy_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga4_rdy_dcb_6, 3, 7, 1, 1);

        fpga5_rdy_dcb_6 = new QLabel(DCB6);
        fpga5_rdy_dcb_6->setObjectName(QString::fromUtf8("fpga5_rdy_dcb_6"));
        fpga5_rdy_dcb_6->setMaximumSize(QSize(46, 40));
        fpga5_rdy_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga5_rdy_dcb_6, 3, 9, 1, 1);

        label_88 = new QLabel(DCB6);
        label_88->setObjectName(QString::fromUtf8("label_88"));
        label_88->setFont(font);

        gridLayout_20->addWidget(label_88, 4, 0, 1, 1);

        fpga1_d18_dcb_6 = new QLabel(DCB6);
        fpga1_d18_dcb_6->setObjectName(QString::fromUtf8("fpga1_d18_dcb_6"));
        fpga1_d18_dcb_6->setMaximumSize(QSize(46, 40));
        fpga1_d18_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga1_d18_dcb_6, 4, 1, 1, 1);

        fpga2_d18_dcb_6 = new QLabel(DCB6);
        fpga2_d18_dcb_6->setObjectName(QString::fromUtf8("fpga2_d18_dcb_6"));
        fpga2_d18_dcb_6->setMaximumSize(QSize(46, 40));
        fpga2_d18_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga2_d18_dcb_6, 4, 3, 1, 1);

        fpga3_d18_dcb_6 = new QLabel(DCB6);
        fpga3_d18_dcb_6->setObjectName(QString::fromUtf8("fpga3_d18_dcb_6"));
        fpga3_d18_dcb_6->setMaximumSize(QSize(46, 40));
        fpga3_d18_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga3_d18_dcb_6, 4, 5, 1, 1);

        fpga4_d18_dcb_6 = new QLabel(DCB6);
        fpga4_d18_dcb_6->setObjectName(QString::fromUtf8("fpga4_d18_dcb_6"));
        fpga4_d18_dcb_6->setMaximumSize(QSize(46, 40));
        fpga4_d18_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga4_d18_dcb_6, 4, 7, 1, 1);

        fpga5_d18_dcb_6 = new QLabel(DCB6);
        fpga5_d18_dcb_6->setObjectName(QString::fromUtf8("fpga5_d18_dcb_6"));
        fpga5_d18_dcb_6->setMaximumSize(QSize(46, 40));
        fpga5_d18_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga5_d18_dcb_6, 4, 9, 1, 1);

        label_94 = new QLabel(DCB6);
        label_94->setObjectName(QString::fromUtf8("label_94"));
        label_94->setFont(font);

        gridLayout_20->addWidget(label_94, 5, 0, 1, 1);

        fpga1_d25_dcb_6 = new QLabel(DCB6);
        fpga1_d25_dcb_6->setObjectName(QString::fromUtf8("fpga1_d25_dcb_6"));
        fpga1_d25_dcb_6->setMaximumSize(QSize(46, 40));
        fpga1_d25_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga1_d25_dcb_6, 5, 1, 1, 1);

        fpga2_d25_dcb_6 = new QLabel(DCB6);
        fpga2_d25_dcb_6->setObjectName(QString::fromUtf8("fpga2_d25_dcb_6"));
        fpga2_d25_dcb_6->setMaximumSize(QSize(46, 40));
        fpga2_d25_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga2_d25_dcb_6, 5, 3, 1, 1);

        fpga3_d25_dcb_6 = new QLabel(DCB6);
        fpga3_d25_dcb_6->setObjectName(QString::fromUtf8("fpga3_d25_dcb_6"));
        fpga3_d25_dcb_6->setMaximumSize(QSize(46, 40));
        fpga3_d25_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga3_d25_dcb_6, 5, 5, 1, 1);

        fpga4_d25_dcb_6 = new QLabel(DCB6);
        fpga4_d25_dcb_6->setObjectName(QString::fromUtf8("fpga4_d25_dcb_6"));
        fpga4_d25_dcb_6->setMaximumSize(QSize(46, 40));
        fpga4_d25_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga4_d25_dcb_6, 5, 7, 1, 1);

        fpga5_d25_dcb_6 = new QLabel(DCB6);
        fpga5_d25_dcb_6->setObjectName(QString::fromUtf8("fpga5_d25_dcb_6"));
        fpga5_d25_dcb_6->setMaximumSize(QSize(46, 40));
        fpga5_d25_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga5_d25_dcb_6, 5, 9, 1, 1);

        label_96 = new QLabel(DCB6);
        label_96->setObjectName(QString::fromUtf8("label_96"));
        label_96->setFont(font);

        gridLayout_20->addWidget(label_96, 6, 0, 1, 1);

        fpga1_d33_dcb_6 = new QLabel(DCB6);
        fpga1_d33_dcb_6->setObjectName(QString::fromUtf8("fpga1_d33_dcb_6"));
        fpga1_d33_dcb_6->setMaximumSize(QSize(46, 40));
        fpga1_d33_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga1_d33_dcb_6, 6, 1, 1, 1);

        fpga2_d33_dcb_6 = new QLabel(DCB6);
        fpga2_d33_dcb_6->setObjectName(QString::fromUtf8("fpga2_d33_dcb_6"));
        fpga2_d33_dcb_6->setMaximumSize(QSize(46, 40));
        fpga2_d33_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga2_d33_dcb_6, 6, 3, 1, 1);

        fpga3_d33_dcb_6 = new QLabel(DCB6);
        fpga3_d33_dcb_6->setObjectName(QString::fromUtf8("fpga3_d33_dcb_6"));
        fpga3_d33_dcb_6->setMaximumSize(QSize(46, 40));
        fpga3_d33_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga3_d33_dcb_6, 6, 5, 1, 1);

        fpga4_d33_dcb_6 = new QLabel(DCB6);
        fpga4_d33_dcb_6->setObjectName(QString::fromUtf8("fpga4_d33_dcb_6"));
        fpga4_d33_dcb_6->setMaximumSize(QSize(46, 40));
        fpga4_d33_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga4_d33_dcb_6, 6, 7, 1, 1);

        fpga5_d33_dcb_6 = new QLabel(DCB6);
        fpga5_d33_dcb_6->setObjectName(QString::fromUtf8("fpga5_d33_dcb_6"));
        fpga5_d33_dcb_6->setMaximumSize(QSize(46, 40));
        fpga5_d33_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga5_d33_dcb_6, 6, 9, 1, 1);

        label_95 = new QLabel(DCB6);
        label_95->setObjectName(QString::fromUtf8("label_95"));
        label_95->setFont(font);

        gridLayout_20->addWidget(label_95, 7, 0, 1, 1);

        fpga1_d5_dcb_6 = new QLabel(DCB6);
        fpga1_d5_dcb_6->setObjectName(QString::fromUtf8("fpga1_d5_dcb_6"));
        fpga1_d5_dcb_6->setMaximumSize(QSize(46, 40));
        fpga1_d5_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga1_d5_dcb_6, 7, 1, 1, 1);

        fpga2_d5_dcb_6 = new QLabel(DCB6);
        fpga2_d5_dcb_6->setObjectName(QString::fromUtf8("fpga2_d5_dcb_6"));
        fpga2_d5_dcb_6->setMaximumSize(QSize(46, 40));
        fpga2_d5_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga2_d5_dcb_6, 7, 3, 1, 1);

        fpga3_d5_dcb_6 = new QLabel(DCB6);
        fpga3_d5_dcb_6->setObjectName(QString::fromUtf8("fpga3_d5_dcb_6"));
        fpga3_d5_dcb_6->setMaximumSize(QSize(46, 40));
        fpga3_d5_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga3_d5_dcb_6, 7, 5, 1, 1);

        fpga4_d5_dcb_6 = new QLabel(DCB6);
        fpga4_d5_dcb_6->setObjectName(QString::fromUtf8("fpga4_d5_dcb_6"));
        fpga4_d5_dcb_6->setMaximumSize(QSize(46, 40));
        fpga4_d5_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga4_d5_dcb_6, 7, 7, 1, 1);

        fpga5_d5_dcb_6 = new QLabel(DCB6);
        fpga5_d5_dcb_6->setObjectName(QString::fromUtf8("fpga5_d5_dcb_6"));
        fpga5_d5_dcb_6->setMaximumSize(QSize(46, 40));
        fpga5_d5_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga5_d5_dcb_6, 7, 9, 1, 1);

        label_99 = new QLabel(DCB6);
        label_99->setObjectName(QString::fromUtf8("label_99"));
        label_99->setFont(font);

        gridLayout_20->addWidget(label_99, 8, 0, 1, 1);

        fpga1_a18_dcb_6 = new QLabel(DCB6);
        fpga1_a18_dcb_6->setObjectName(QString::fromUtf8("fpga1_a18_dcb_6"));
        fpga1_a18_dcb_6->setMaximumSize(QSize(46, 40));
        fpga1_a18_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga1_a18_dcb_6, 8, 1, 1, 1);

        fpga2_a18_dcb_6 = new QLabel(DCB6);
        fpga2_a18_dcb_6->setObjectName(QString::fromUtf8("fpga2_a18_dcb_6"));
        fpga2_a18_dcb_6->setMaximumSize(QSize(46, 40));
        fpga2_a18_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga2_a18_dcb_6, 8, 3, 1, 1);

        fpga3_a18_dcb_6 = new QLabel(DCB6);
        fpga3_a18_dcb_6->setObjectName(QString::fromUtf8("fpga3_a18_dcb_6"));
        fpga3_a18_dcb_6->setMaximumSize(QSize(46, 40));
        fpga3_a18_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga3_a18_dcb_6, 8, 5, 1, 1);

        fpga4_a18_dcb_6 = new QLabel(DCB6);
        fpga4_a18_dcb_6->setObjectName(QString::fromUtf8("fpga4_a18_dcb_6"));
        fpga4_a18_dcb_6->setMaximumSize(QSize(46, 40));
        fpga4_a18_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga4_a18_dcb_6, 8, 7, 1, 1);

        fpga5_a18_dcb_6 = new QLabel(DCB6);
        fpga5_a18_dcb_6->setObjectName(QString::fromUtf8("fpga5_a18_dcb_6"));
        fpga5_a18_dcb_6->setMaximumSize(QSize(46, 40));
        fpga5_a18_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga5_a18_dcb_6, 8, 9, 1, 1);

        label_87 = new QLabel(DCB6);
        label_87->setObjectName(QString::fromUtf8("label_87"));
        label_87->setFont(font);

        gridLayout_20->addWidget(label_87, 9, 0, 1, 1);

        fpga1_a33_dcb_6 = new QLabel(DCB6);
        fpga1_a33_dcb_6->setObjectName(QString::fromUtf8("fpga1_a33_dcb_6"));
        fpga1_a33_dcb_6->setMaximumSize(QSize(46, 40));
        fpga1_a33_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga1_a33_dcb_6, 9, 1, 1, 1);

        fpga2_a33_dcb_6 = new QLabel(DCB6);
        fpga2_a33_dcb_6->setObjectName(QString::fromUtf8("fpga2_a33_dcb_6"));
        fpga2_a33_dcb_6->setMaximumSize(QSize(46, 40));
        fpga2_a33_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga2_a33_dcb_6, 9, 3, 1, 1);

        fpga3_a33_dcb_6 = new QLabel(DCB6);
        fpga3_a33_dcb_6->setObjectName(QString::fromUtf8("fpga3_a33_dcb_6"));
        fpga3_a33_dcb_6->setMaximumSize(QSize(46, 40));
        fpga3_a33_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga3_a33_dcb_6, 9, 5, 1, 1);

        fpga4_a33_dcb_6 = new QLabel(DCB6);
        fpga4_a33_dcb_6->setObjectName(QString::fromUtf8("fpga4_a33_dcb_6"));
        fpga4_a33_dcb_6->setMaximumSize(QSize(46, 40));
        fpga4_a33_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga4_a33_dcb_6, 9, 7, 1, 1);

        fpga5_a33_dcb_6 = new QLabel(DCB6);
        fpga5_a33_dcb_6->setObjectName(QString::fromUtf8("fpga5_a33_dcb_6"));
        fpga5_a33_dcb_6->setMaximumSize(QSize(46, 40));
        fpga5_a33_dcb_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(fpga5_a33_dcb_6, 9, 9, 1, 1);

        tab_dcb->addTab(DCB6, QString());
        DCB7 = new QWidget();
        DCB7->setObjectName(QString::fromUtf8("DCB7"));
        gridLayout_21 = new QGridLayout(DCB7);
        gridLayout_21->setObjectName(QString::fromUtf8("gridLayout_21"));
        horizontalSpacer_43 = new QSpacerItem(129, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_43, 0, 0, 1, 1);

        label_106 = new QLabel(DCB7);
        label_106->setObjectName(QString::fromUtf8("label_106"));
        label_106->setMaximumSize(QSize(300, 16777215));
        label_106->setFont(font);
        label_106->setAlignment(Qt::AlignCenter);

        gridLayout_21->addWidget(label_106, 0, 1, 1, 1);

        horizontalSpacer_46 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_46, 0, 2, 1, 1);

        label_111 = new QLabel(DCB7);
        label_111->setObjectName(QString::fromUtf8("label_111"));
        label_111->setFont(font);
        label_111->setAlignment(Qt::AlignCenter);

        gridLayout_21->addWidget(label_111, 0, 3, 1, 1);

        horizontalSpacer_45 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_45, 0, 4, 1, 1);

        label_107 = new QLabel(DCB7);
        label_107->setObjectName(QString::fromUtf8("label_107"));
        label_107->setFont(font);
        label_107->setAlignment(Qt::AlignCenter);

        gridLayout_21->addWidget(label_107, 0, 5, 1, 1);

        horizontalSpacer_48 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_48, 0, 6, 1, 1);

        label_103 = new QLabel(DCB7);
        label_103->setObjectName(QString::fromUtf8("label_103"));
        label_103->setFont(font);
        label_103->setAlignment(Qt::AlignCenter);

        gridLayout_21->addWidget(label_103, 0, 7, 1, 1);

        horizontalSpacer_44 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_44, 0, 8, 1, 1);

        label_102 = new QLabel(DCB7);
        label_102->setObjectName(QString::fromUtf8("label_102"));
        label_102->setFont(font);
        label_102->setAlignment(Qt::AlignCenter);

        gridLayout_21->addWidget(label_102, 0, 9, 1, 1);

        horizontalSpacer_47 = new QSpacerItem(40, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_47, 0, 10, 1, 1);

        label_100 = new QLabel(DCB7);
        label_100->setObjectName(QString::fromUtf8("label_100"));
        label_100->setFont(font);

        gridLayout_21->addWidget(label_100, 1, 0, 1, 1);

        fpga1_con_dcb_7 = new QLabel(DCB7);
        fpga1_con_dcb_7->setObjectName(QString::fromUtf8("fpga1_con_dcb_7"));
        fpga1_con_dcb_7->setMaximumSize(QSize(46, 40));
        fpga1_con_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga1_con_dcb_7, 1, 1, 1, 1);

        fpga2_con_dcb_7 = new QLabel(DCB7);
        fpga2_con_dcb_7->setObjectName(QString::fromUtf8("fpga2_con_dcb_7"));
        fpga2_con_dcb_7->setMaximumSize(QSize(46, 40));
        fpga2_con_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga2_con_dcb_7, 1, 3, 1, 1);

        fpga3_con_dcb_7 = new QLabel(DCB7);
        fpga3_con_dcb_7->setObjectName(QString::fromUtf8("fpga3_con_dcb_7"));
        fpga3_con_dcb_7->setMaximumSize(QSize(46, 40));
        fpga3_con_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga3_con_dcb_7, 1, 5, 1, 1);

        fpga4_con_dcb_7 = new QLabel(DCB7);
        fpga4_con_dcb_7->setObjectName(QString::fromUtf8("fpga4_con_dcb_7"));
        fpga4_con_dcb_7->setMaximumSize(QSize(46, 40));
        fpga4_con_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga4_con_dcb_7, 1, 7, 1, 1);

        fpga5_con_dcb_7 = new QLabel(DCB7);
        fpga5_con_dcb_7->setObjectName(QString::fromUtf8("fpga5_con_dcb_7"));
        fpga5_con_dcb_7->setMaximumSize(QSize(46, 40));
        fpga5_con_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga5_con_dcb_7, 1, 9, 1, 1);

        label_108 = new QLabel(DCB7);
        label_108->setObjectName(QString::fromUtf8("label_108"));
        label_108->setFont(font);

        gridLayout_21->addWidget(label_108, 2, 0, 1, 1);

        fpga1_hlt_dcb_7 = new QLabel(DCB7);
        fpga1_hlt_dcb_7->setObjectName(QString::fromUtf8("fpga1_hlt_dcb_7"));
        fpga1_hlt_dcb_7->setMaximumSize(QSize(46, 40));
        fpga1_hlt_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga1_hlt_dcb_7, 2, 1, 1, 1);

        fpga2_hlt_dcb_7 = new QLabel(DCB7);
        fpga2_hlt_dcb_7->setObjectName(QString::fromUtf8("fpga2_hlt_dcb_7"));
        fpga2_hlt_dcb_7->setMaximumSize(QSize(46, 40));
        fpga2_hlt_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga2_hlt_dcb_7, 2, 3, 1, 1);

        fpga3_hlt_dcb_7 = new QLabel(DCB7);
        fpga3_hlt_dcb_7->setObjectName(QString::fromUtf8("fpga3_hlt_dcb_7"));
        fpga3_hlt_dcb_7->setMaximumSize(QSize(46, 40));
        fpga3_hlt_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga3_hlt_dcb_7, 2, 5, 1, 1);

        fpga4_hlt_dcb_7 = new QLabel(DCB7);
        fpga4_hlt_dcb_7->setObjectName(QString::fromUtf8("fpga4_hlt_dcb_7"));
        fpga4_hlt_dcb_7->setMaximumSize(QSize(46, 40));
        fpga4_hlt_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga4_hlt_dcb_7, 2, 7, 1, 1);

        fpga5_hlt_dcb_7 = new QLabel(DCB7);
        fpga5_hlt_dcb_7->setObjectName(QString::fromUtf8("fpga5_hlt_dcb_7"));
        fpga5_hlt_dcb_7->setMaximumSize(QSize(46, 40));
        fpga5_hlt_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga5_hlt_dcb_7, 2, 9, 1, 1);

        label_110 = new QLabel(DCB7);
        label_110->setObjectName(QString::fromUtf8("label_110"));
        label_110->setFont(font);

        gridLayout_21->addWidget(label_110, 3, 0, 1, 1);

        fpga1_rdy_dcb_7 = new QLabel(DCB7);
        fpga1_rdy_dcb_7->setObjectName(QString::fromUtf8("fpga1_rdy_dcb_7"));
        fpga1_rdy_dcb_7->setMaximumSize(QSize(46, 40));
        fpga1_rdy_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga1_rdy_dcb_7, 3, 1, 1, 1);

        fpga2_rdy_dcb_7 = new QLabel(DCB7);
        fpga2_rdy_dcb_7->setObjectName(QString::fromUtf8("fpga2_rdy_dcb_7"));
        fpga2_rdy_dcb_7->setMaximumSize(QSize(46, 40));
        fpga2_rdy_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga2_rdy_dcb_7, 3, 3, 1, 1);

        fpga3_rdy_dcb_7 = new QLabel(DCB7);
        fpga3_rdy_dcb_7->setObjectName(QString::fromUtf8("fpga3_rdy_dcb_7"));
        fpga3_rdy_dcb_7->setMaximumSize(QSize(46, 40));
        fpga3_rdy_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga3_rdy_dcb_7, 3, 5, 1, 1);

        fpga4_rdy_dcb_7 = new QLabel(DCB7);
        fpga4_rdy_dcb_7->setObjectName(QString::fromUtf8("fpga4_rdy_dcb_7"));
        fpga4_rdy_dcb_7->setMaximumSize(QSize(46, 40));
        fpga4_rdy_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga4_rdy_dcb_7, 3, 7, 1, 1);

        fpga5_rdy_dcb_7 = new QLabel(DCB7);
        fpga5_rdy_dcb_7->setObjectName(QString::fromUtf8("fpga5_rdy_dcb_7"));
        fpga5_rdy_dcb_7->setMaximumSize(QSize(46, 40));
        fpga5_rdy_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga5_rdy_dcb_7, 3, 9, 1, 1);

        label_113 = new QLabel(DCB7);
        label_113->setObjectName(QString::fromUtf8("label_113"));
        label_113->setFont(font);

        gridLayout_21->addWidget(label_113, 4, 0, 1, 1);

        fpga1_d18_dcb_7 = new QLabel(DCB7);
        fpga1_d18_dcb_7->setObjectName(QString::fromUtf8("fpga1_d18_dcb_7"));
        fpga1_d18_dcb_7->setMaximumSize(QSize(46, 40));
        fpga1_d18_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga1_d18_dcb_7, 4, 1, 1, 1);

        fpga2_d18_dcb_7 = new QLabel(DCB7);
        fpga2_d18_dcb_7->setObjectName(QString::fromUtf8("fpga2_d18_dcb_7"));
        fpga2_d18_dcb_7->setMaximumSize(QSize(46, 40));
        fpga2_d18_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga2_d18_dcb_7, 4, 3, 1, 1);

        fpga3_d18_dcb_7 = new QLabel(DCB7);
        fpga3_d18_dcb_7->setObjectName(QString::fromUtf8("fpga3_d18_dcb_7"));
        fpga3_d18_dcb_7->setMaximumSize(QSize(46, 40));
        fpga3_d18_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga3_d18_dcb_7, 4, 5, 1, 1);

        fpga4_d18_dcb_7 = new QLabel(DCB7);
        fpga4_d18_dcb_7->setObjectName(QString::fromUtf8("fpga4_d18_dcb_7"));
        fpga4_d18_dcb_7->setMaximumSize(QSize(46, 40));
        fpga4_d18_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga4_d18_dcb_7, 4, 7, 1, 1);

        fpga5_d18_dcb_7 = new QLabel(DCB7);
        fpga5_d18_dcb_7->setObjectName(QString::fromUtf8("fpga5_d18_dcb_7"));
        fpga5_d18_dcb_7->setMaximumSize(QSize(46, 40));
        fpga5_d18_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga5_d18_dcb_7, 4, 9, 1, 1);

        label_109 = new QLabel(DCB7);
        label_109->setObjectName(QString::fromUtf8("label_109"));
        label_109->setFont(font);

        gridLayout_21->addWidget(label_109, 5, 0, 1, 1);

        fpga1_d25_dcb_7 = new QLabel(DCB7);
        fpga1_d25_dcb_7->setObjectName(QString::fromUtf8("fpga1_d25_dcb_7"));
        fpga1_d25_dcb_7->setMaximumSize(QSize(46, 40));
        fpga1_d25_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga1_d25_dcb_7, 5, 1, 1, 1);

        fpga2_d25_dcb_7 = new QLabel(DCB7);
        fpga2_d25_dcb_7->setObjectName(QString::fromUtf8("fpga2_d25_dcb_7"));
        fpga2_d25_dcb_7->setMaximumSize(QSize(46, 40));
        fpga2_d25_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga2_d25_dcb_7, 5, 3, 1, 1);

        fpga3_d25_dcb_7 = new QLabel(DCB7);
        fpga3_d25_dcb_7->setObjectName(QString::fromUtf8("fpga3_d25_dcb_7"));
        fpga3_d25_dcb_7->setMaximumSize(QSize(46, 40));
        fpga3_d25_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga3_d25_dcb_7, 5, 5, 1, 1);

        fpga4_d25_dcb_7 = new QLabel(DCB7);
        fpga4_d25_dcb_7->setObjectName(QString::fromUtf8("fpga4_d25_dcb_7"));
        fpga4_d25_dcb_7->setMaximumSize(QSize(46, 40));
        fpga4_d25_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga4_d25_dcb_7, 5, 7, 1, 1);

        fpga5_d25_dcb_7 = new QLabel(DCB7);
        fpga5_d25_dcb_7->setObjectName(QString::fromUtf8("fpga5_d25_dcb_7"));
        fpga5_d25_dcb_7->setMaximumSize(QSize(46, 40));
        fpga5_d25_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga5_d25_dcb_7, 5, 9, 1, 1);

        label_112 = new QLabel(DCB7);
        label_112->setObjectName(QString::fromUtf8("label_112"));
        label_112->setFont(font);

        gridLayout_21->addWidget(label_112, 6, 0, 1, 1);

        fpga1_d33_dcb_7 = new QLabel(DCB7);
        fpga1_d33_dcb_7->setObjectName(QString::fromUtf8("fpga1_d33_dcb_7"));
        fpga1_d33_dcb_7->setMaximumSize(QSize(46, 40));
        fpga1_d33_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga1_d33_dcb_7, 6, 1, 1, 1);

        fpga2_d33_dcb_7 = new QLabel(DCB7);
        fpga2_d33_dcb_7->setObjectName(QString::fromUtf8("fpga2_d33_dcb_7"));
        fpga2_d33_dcb_7->setMaximumSize(QSize(46, 40));
        fpga2_d33_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga2_d33_dcb_7, 6, 3, 1, 1);

        fpga3_d33_dcb_7 = new QLabel(DCB7);
        fpga3_d33_dcb_7->setObjectName(QString::fromUtf8("fpga3_d33_dcb_7"));
        fpga3_d33_dcb_7->setMaximumSize(QSize(46, 40));
        fpga3_d33_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga3_d33_dcb_7, 6, 5, 1, 1);

        fpga4_d33_dcb_7 = new QLabel(DCB7);
        fpga4_d33_dcb_7->setObjectName(QString::fromUtf8("fpga4_d33_dcb_7"));
        fpga4_d33_dcb_7->setMaximumSize(QSize(46, 40));
        fpga4_d33_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga4_d33_dcb_7, 6, 7, 1, 1);

        fpga5_d33_dcb_7 = new QLabel(DCB7);
        fpga5_d33_dcb_7->setObjectName(QString::fromUtf8("fpga5_d33_dcb_7"));
        fpga5_d33_dcb_7->setMaximumSize(QSize(46, 40));
        fpga5_d33_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga5_d33_dcb_7, 6, 9, 1, 1);

        label_104 = new QLabel(DCB7);
        label_104->setObjectName(QString::fromUtf8("label_104"));
        label_104->setFont(font);

        gridLayout_21->addWidget(label_104, 7, 0, 1, 1);

        fpga1_d5_dcb_7 = new QLabel(DCB7);
        fpga1_d5_dcb_7->setObjectName(QString::fromUtf8("fpga1_d5_dcb_7"));
        fpga1_d5_dcb_7->setMaximumSize(QSize(46, 40));
        fpga1_d5_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga1_d5_dcb_7, 7, 1, 1, 1);

        fpga2_d5_dcb_7 = new QLabel(DCB7);
        fpga2_d5_dcb_7->setObjectName(QString::fromUtf8("fpga2_d5_dcb_7"));
        fpga2_d5_dcb_7->setMaximumSize(QSize(46, 40));
        fpga2_d5_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga2_d5_dcb_7, 7, 3, 1, 1);

        fpga3_d5_dcb_7 = new QLabel(DCB7);
        fpga3_d5_dcb_7->setObjectName(QString::fromUtf8("fpga3_d5_dcb_7"));
        fpga3_d5_dcb_7->setMaximumSize(QSize(46, 40));
        fpga3_d5_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga3_d5_dcb_7, 7, 5, 1, 1);

        fpga4_d5_dcb_7 = new QLabel(DCB7);
        fpga4_d5_dcb_7->setObjectName(QString::fromUtf8("fpga4_d5_dcb_7"));
        fpga4_d5_dcb_7->setMaximumSize(QSize(46, 40));
        fpga4_d5_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga4_d5_dcb_7, 7, 7, 1, 1);

        fpga5_d5_dcb_7 = new QLabel(DCB7);
        fpga5_d5_dcb_7->setObjectName(QString::fromUtf8("fpga5_d5_dcb_7"));
        fpga5_d5_dcb_7->setMaximumSize(QSize(46, 40));
        fpga5_d5_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga5_d5_dcb_7, 7, 9, 1, 1);

        label_105 = new QLabel(DCB7);
        label_105->setObjectName(QString::fromUtf8("label_105"));
        label_105->setFont(font);

        gridLayout_21->addWidget(label_105, 8, 0, 1, 1);

        fpga1_a18_dcb_7 = new QLabel(DCB7);
        fpga1_a18_dcb_7->setObjectName(QString::fromUtf8("fpga1_a18_dcb_7"));
        fpga1_a18_dcb_7->setMaximumSize(QSize(46, 40));
        fpga1_a18_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga1_a18_dcb_7, 8, 1, 1, 1);

        fpga2_a18_dcb_7 = new QLabel(DCB7);
        fpga2_a18_dcb_7->setObjectName(QString::fromUtf8("fpga2_a18_dcb_7"));
        fpga2_a18_dcb_7->setMaximumSize(QSize(46, 40));
        fpga2_a18_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga2_a18_dcb_7, 8, 3, 1, 1);

        fpga3_a18_dcb_7 = new QLabel(DCB7);
        fpga3_a18_dcb_7->setObjectName(QString::fromUtf8("fpga3_a18_dcb_7"));
        fpga3_a18_dcb_7->setMaximumSize(QSize(46, 40));
        fpga3_a18_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga3_a18_dcb_7, 8, 5, 1, 1);

        fpga4_a18_dcb_7 = new QLabel(DCB7);
        fpga4_a18_dcb_7->setObjectName(QString::fromUtf8("fpga4_a18_dcb_7"));
        fpga4_a18_dcb_7->setMaximumSize(QSize(46, 40));
        fpga4_a18_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga4_a18_dcb_7, 8, 7, 1, 1);

        fpga5_a18_dcb_7 = new QLabel(DCB7);
        fpga5_a18_dcb_7->setObjectName(QString::fromUtf8("fpga5_a18_dcb_7"));
        fpga5_a18_dcb_7->setMaximumSize(QSize(46, 40));
        fpga5_a18_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga5_a18_dcb_7, 8, 9, 1, 1);

        label_101 = new QLabel(DCB7);
        label_101->setObjectName(QString::fromUtf8("label_101"));
        label_101->setFont(font);

        gridLayout_21->addWidget(label_101, 9, 0, 1, 1);

        fpga1_a33_dcb_7 = new QLabel(DCB7);
        fpga1_a33_dcb_7->setObjectName(QString::fromUtf8("fpga1_a33_dcb_7"));
        fpga1_a33_dcb_7->setMaximumSize(QSize(46, 40));
        fpga1_a33_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga1_a33_dcb_7, 9, 1, 1, 1);

        fpga2_a33_dcb_7 = new QLabel(DCB7);
        fpga2_a33_dcb_7->setObjectName(QString::fromUtf8("fpga2_a33_dcb_7"));
        fpga2_a33_dcb_7->setMaximumSize(QSize(46, 40));
        fpga2_a33_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga2_a33_dcb_7, 9, 3, 1, 1);

        fpga3_a33_dcb_7 = new QLabel(DCB7);
        fpga3_a33_dcb_7->setObjectName(QString::fromUtf8("fpga3_a33_dcb_7"));
        fpga3_a33_dcb_7->setMaximumSize(QSize(46, 40));
        fpga3_a33_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga3_a33_dcb_7, 9, 5, 1, 1);

        fpga4_a33_dcb_7 = new QLabel(DCB7);
        fpga4_a33_dcb_7->setObjectName(QString::fromUtf8("fpga4_a33_dcb_7"));
        fpga4_a33_dcb_7->setMaximumSize(QSize(46, 40));
        fpga4_a33_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga4_a33_dcb_7, 9, 7, 1, 1);

        fpga5_a33_dcb_7 = new QLabel(DCB7);
        fpga5_a33_dcb_7->setObjectName(QString::fromUtf8("fpga5_a33_dcb_7"));
        fpga5_a33_dcb_7->setMaximumSize(QSize(46, 40));
        fpga5_a33_dcb_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 10px;\n"
"margin-left: 13px;\n"
"margin-right: 13px;\n"
"margin-bottom: 10px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_21->addWidget(fpga5_a33_dcb_7, 9, 9, 1, 1);

        tab_dcb->addTab(DCB7, QString());

        gridLayout->addWidget(tab_dcb, 0, 0, 1, 1);


        retranslateUi(dialog_dcb);

        tab_dcb->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(dialog_dcb);
    } // setupUi

    void retranslateUi(QDialog *dialog_dcb)
    {
        dialog_dcb->setWindowTitle(QApplication::translate("dialog_dcb", "DCB", 0, QApplication::UnicodeUTF8));
        label_118->setText(QApplication::translate("dialog_dcb", "FPGA 1", 0, QApplication::UnicodeUTF8));
        label_125->setText(QApplication::translate("dialog_dcb", "FPGA 2", 0, QApplication::UnicodeUTF8));
        label_126->setText(QApplication::translate("dialog_dcb", "FPGA 3", 0, QApplication::UnicodeUTF8));
        label_117->setText(QApplication::translate("dialog_dcb", "FPGA 4", 0, QApplication::UnicodeUTF8));
        label_124->setText(QApplication::translate("dialog_dcb", "FPGA 5", 0, QApplication::UnicodeUTF8));
        label_114->setText(QApplication::translate("dialog_dcb", "Connected", 0, QApplication::UnicodeUTF8));
        fpga1_con_dcb_1->setText(QString());
        fpga2_con_dcb_1->setText(QString());
        fpga3_con_dcb_1->setText(QString());
        fpga4_con_dcb_1->setText(QString());
        fpga5_con_dcb_1->setText(QString());
        label_121->setText(QApplication::translate("dialog_dcb", "Healthy", 0, QApplication::UnicodeUTF8));
        fpga1_hlt_dcb_1->setText(QString());
        fpga2_hlt_dcb_1->setText(QString());
        fpga3_hlt_dcb_1->setText(QString());
        fpga4_hlt_dcb_1->setText(QString());
        fpga5_hlt_dcb_1->setText(QString());
        label_119->setText(QApplication::translate("dialog_dcb", "Ready", 0, QApplication::UnicodeUTF8));
        fpga1_rdy_dcb_1->setText(QString());
        fpga2_rdy_dcb_1->setText(QString());
        fpga3_rdy_dcb_1->setText(QString());
        fpga4_rdy_dcb_1->setText(QString());
        fpga5_rdy_dcb_1->setText(QString());
        label_116->setText(QApplication::translate("dialog_dcb", "Digital 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_d18_dcb_1->setText(QString());
        fpga2_d18_dcb_1->setText(QString());
        fpga3_d18_dcb_1->setText(QString());
        fpga4_d18_dcb_1->setText(QString());
        fpga5_d18_dcb_1->setText(QString());
        label_127->setText(QApplication::translate("dialog_dcb", "Digital 2.5V", 0, QApplication::UnicodeUTF8));
        fpga1_d25_dcb_1->setText(QString());
        fpga2_d25_dcb_1->setText(QString());
        fpga3_d25_dcb_1->setText(QString());
        fpga4_d25_dcb_1->setText(QString());
        fpga5_d25_dcb_1->setText(QString());
        label_120->setText(QApplication::translate("dialog_dcb", "Digital 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_d33_dcb_1->setText(QString());
        fpga2_d33_dcb_1->setText(QString());
        fpga3_d33_dcb_1->setText(QString());
        fpga4_d33_dcb_1->setText(QString());
        fpga5_d33_dcb_1->setText(QString());
        label_123->setText(QApplication::translate("dialog_dcb", "Digital 5.0V", 0, QApplication::UnicodeUTF8));
        fpga1_d5_dcb_1->setText(QString());
        fpga2_d5_dcb_1->setText(QString());
        fpga3_d5_dcb_1->setText(QString());
        fpga4_d5_dcb_1->setText(QString());
        fpga5_d5_dcb_1->setText(QString());
        label_115->setText(QApplication::translate("dialog_dcb", "Analog 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_a18_dcb_1->setText(QString());
        fpga2_a18_dcb_1->setText(QString());
        fpga3_a18_dcb_1->setText(QString());
        fpga4_a18_dcb_1->setText(QString());
        fpga5_a18_dcb_1->setText(QString());
        label_122->setText(QApplication::translate("dialog_dcb", "Analog 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_a33_dcb_1->setText(QString());
        fpga2_a33_dcb_1->setText(QString());
        fpga3_a33_dcb_1->setText(QString());
        fpga4_a33_dcb_1->setText(QString());
        fpga5_a33_dcb_1->setText(QString());
        tab_dcb->setTabText(tab_dcb->indexOf(DCB1), QApplication::translate("dialog_dcb", "DCB 1", 0, QApplication::UnicodeUTF8));
        label_34->setText(QApplication::translate("dialog_dcb", "FPGA 1", 0, QApplication::UnicodeUTF8));
        label_39->setText(QApplication::translate("dialog_dcb", "FPGA 2", 0, QApplication::UnicodeUTF8));
        label_40->setText(QApplication::translate("dialog_dcb", "FPGA 3", 0, QApplication::UnicodeUTF8));
        label_16->setText(QApplication::translate("dialog_dcb", "FPGA 4", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("dialog_dcb", "FPGA 5", 0, QApplication::UnicodeUTF8));
        label_14->setText(QApplication::translate("dialog_dcb", "Connected", 0, QApplication::UnicodeUTF8));
        fpga1_con_dcb_2->setText(QString());
        fpga2_con_dcb_2->setText(QString());
        fpga3_con_dcb_2->setText(QString());
        fpga4_con_dcb_2->setText(QString());
        fpga5_con_dcb_2->setText(QString());
        label_43->setText(QApplication::translate("dialog_dcb", "Healthy", 0, QApplication::UnicodeUTF8));
        fpga1_hlt_dcb_2->setText(QString());
        fpga2_hlt_dcb_2->setText(QString());
        fpga3_hlt_dcb_2->setText(QString());
        fpga4_hlt_dcb_2->setText(QString());
        fpga5_hlt_dcb_2->setText(QString());
        label_35->setText(QApplication::translate("dialog_dcb", "Ready", 0, QApplication::UnicodeUTF8));
        fpga1_rdy_dcb_2->setText(QString());
        fpga2_rdy_dcb_2->setText(QString());
        fpga3_rdy_dcb_2->setText(QString());
        fpga4_rdy_dcb_2->setText(QString());
        fpga5_rdy_dcb_2->setText(QString());
        label_33->setText(QApplication::translate("dialog_dcb", "Digital 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_d18_dcb_2->setText(QString());
        fpga2_d18_dcb_2->setText(QString());
        fpga3_d18_dcb_2->setText(QString());
        fpga4_d18_dcb_2->setText(QString());
        fpga5_d18_dcb_2->setText(QString());
        label_41->setText(QApplication::translate("dialog_dcb", "Digital 2.5V", 0, QApplication::UnicodeUTF8));
        fpga1_d25_dcb_2->setText(QString());
        fpga2_d25_dcb_2->setText(QString());
        fpga3_d25_dcb_2->setText(QString());
        fpga4_d25_dcb_2->setText(QString());
        fpga5_d25_dcb_2->setText(QString());
        label_36->setText(QApplication::translate("dialog_dcb", "Digital 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_d33_dcb_2->setText(QString());
        fpga2_d33_dcb_2->setText(QString());
        fpga3_d33_dcb_2->setText(QString());
        fpga4_d33_dcb_2->setText(QString());
        fpga5_d33_dcb_2->setText(QString());
        label_38->setText(QApplication::translate("dialog_dcb", "Digital 5.0V", 0, QApplication::UnicodeUTF8));
        fpga1_d5_dcb_2->setText(QString());
        fpga2_d5_dcb_2->setText(QString());
        fpga3_d5_dcb_2->setText(QString());
        fpga4_d5_dcb_2->setText(QString());
        fpga5_d5_dcb_2->setText(QString());
        label_32->setText(QApplication::translate("dialog_dcb", "Analog 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_a18_dcb_2->setText(QString());
        fpga2_a18_dcb_2->setText(QString());
        fpga3_a18_dcb_2->setText(QString());
        fpga4_a18_dcb_2->setText(QString());
        fpga5_a18_dcb_2->setText(QString());
        label_37->setText(QApplication::translate("dialog_dcb", "Analog 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_a33_dcb_2->setText(QString());
        fpga2_a33_dcb_2->setText(QString());
        fpga3_a33_dcb_2->setText(QString());
        fpga4_a33_dcb_2->setText(QString());
        fpga5_a33_dcb_2->setText(QString());
        tab_dcb->setTabText(tab_dcb->indexOf(DCB2), QApplication::translate("dialog_dcb", "DCB 2", 0, QApplication::UnicodeUTF8));
        label_51->setText(QApplication::translate("dialog_dcb", "FPGA 1", 0, QApplication::UnicodeUTF8));
        label_50->setText(QApplication::translate("dialog_dcb", "FPGA 2", 0, QApplication::UnicodeUTF8));
        label_56->setText(QApplication::translate("dialog_dcb", "FPGA 3", 0, QApplication::UnicodeUTF8));
        label_57->setText(QApplication::translate("dialog_dcb", "FPGA 4", 0, QApplication::UnicodeUTF8));
        label_46->setText(QApplication::translate("dialog_dcb", "FPGA 5", 0, QApplication::UnicodeUTF8));
        label_48->setText(QApplication::translate("dialog_dcb", "Connected", 0, QApplication::UnicodeUTF8));
        fpga1_con_dcb_3->setText(QString());
        fpga2_con_dcb_3->setText(QString());
        fpga3_con_dcb_3->setText(QString());
        fpga4_con_dcb_3->setText(QString());
        fpga5_con_dcb_3->setText(QString());
        label_52->setText(QApplication::translate("dialog_dcb", "Healthy", 0, QApplication::UnicodeUTF8));
        fpga1_hlt_dcb_3->setText(QString());
        fpga2_hlt_dcb_3->setText(QString());
        fpga3_hlt_dcb_3->setText(QString());
        fpga4_hlt_dcb_3->setText(QString());
        fpga5_hlt_dcb_3->setText(QString());
        label_47->setText(QApplication::translate("dialog_dcb", "Ready", 0, QApplication::UnicodeUTF8));
        fpga1_rdy_dcb_3->setText(QString());
        fpga2_rdy_dcb_3->setText(QString());
        fpga3_rdy_dcb_3->setText(QString());
        fpga4_rdy_dcb_3->setText(QString());
        fpga5_rdy_dcb_3->setText(QString());
        label_53->setText(QApplication::translate("dialog_dcb", "Digital 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_d18_dcb_3->setText(QString());
        fpga2_d18_dcb_3->setText(QString());
        fpga3_d18_dcb_3->setText(QString());
        fpga4_d18_dcb_3->setText(QString());
        fpga5_d18_dcb_3->setText(QString());
        label_55->setText(QApplication::translate("dialog_dcb", "Digital 2.5V", 0, QApplication::UnicodeUTF8));
        fpga1_d25_dcb_3->setText(QString());
        fpga2_d25_dcb_3->setText(QString());
        fpga3_d25_dcb_3->setText(QString());
        fpga4_d25_dcb_3->setText(QString());
        fpga5_d25_dcb_3->setText(QString());
        label_49->setText(QApplication::translate("dialog_dcb", "Digital 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_d33_dcb_3->setText(QString());
        fpga2_d33_dcb_3->setText(QString());
        fpga3_d33_dcb_3->setText(QString());
        fpga4_d33_dcb_3->setText(QString());
        fpga5_d33_dcb_3->setText(QString());
        label_54->setText(QApplication::translate("dialog_dcb", "Digital 5.0V", 0, QApplication::UnicodeUTF8));
        fpga1_d5_dcb_3->setText(QString());
        fpga2_d5_dcb_3->setText(QString());
        fpga3_d5_dcb_3->setText(QString());
        fpga4_d5_dcb_3->setText(QString());
        fpga5_d5_dcb_3->setText(QString());
        label_44->setText(QApplication::translate("dialog_dcb", "Analog 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_a18_dcb_3->setText(QString());
        fpga2_a18_dcb_3->setText(QString());
        fpga3_a18_dcb_3->setText(QString());
        fpga4_a18_dcb_3->setText(QString());
        fpga5_a18_dcb_3->setText(QString());
        label_45->setText(QApplication::translate("dialog_dcb", "Analog 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_a33_dcb_3->setText(QString());
        fpga2_a33_dcb_3->setText(QString());
        fpga3_a33_dcb_3->setText(QString());
        fpga4_a33_dcb_3->setText(QString());
        fpga5_a33_dcb_3->setText(QString());
        tab_dcb->setTabText(tab_dcb->indexOf(DCB3), QApplication::translate("dialog_dcb", "DCB 3", 0, QApplication::UnicodeUTF8));
        label_68->setText(QApplication::translate("dialog_dcb", "FPGA 1", 0, QApplication::UnicodeUTF8));
        label_70->setText(QApplication::translate("dialog_dcb", "FPGA 2", 0, QApplication::UnicodeUTF8));
        label_63->setText(QApplication::translate("dialog_dcb", "FPGA 3", 0, QApplication::UnicodeUTF8));
        label_67->setText(QApplication::translate("dialog_dcb", "FPGA 4", 0, QApplication::UnicodeUTF8));
        label_61->setText(QApplication::translate("dialog_dcb", "FPGA 5", 0, QApplication::UnicodeUTF8));
        label_59->setText(QApplication::translate("dialog_dcb", "Connected", 0, QApplication::UnicodeUTF8));
        fpga1_con_dcb_4->setText(QString());
        fpga2_con_dcb_4->setText(QString());
        fpga3_con_dcb_4->setText(QString());
        fpga4_con_dcb_4->setText(QString());
        fpga5_con_dcb_4->setText(QString());
        label_58->setText(QApplication::translate("dialog_dcb", "Healthy", 0, QApplication::UnicodeUTF8));
        fpga1_hlt_dcb_4->setText(QString());
        fpga2_hlt_dcb_4->setText(QString());
        fpga3_hlt_dcb_4->setText(QString());
        fpga4_hlt_dcb_4->setText(QString());
        fpga5_hlt_dcb_4->setText(QString());
        label_66->setText(QApplication::translate("dialog_dcb", "Ready", 0, QApplication::UnicodeUTF8));
        fpga1_rdy_dcb_4->setText(QString());
        fpga2_rdy_dcb_4->setText(QString());
        fpga3_rdy_dcb_4->setText(QString());
        fpga4_rdy_dcb_4->setText(QString());
        fpga5_rdy_dcb_4->setText(QString());
        label_64->setText(QApplication::translate("dialog_dcb", "Digital 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_d18_dcb_4->setText(QString());
        fpga2_d18_dcb_4->setText(QString());
        fpga3_d18_dcb_4->setText(QString());
        fpga4_d18_dcb_4->setText(QString());
        fpga5_d18_dcb_4->setText(QString());
        label_71->setText(QApplication::translate("dialog_dcb", "Digital 2.5V", 0, QApplication::UnicodeUTF8));
        fpga1_d25_dcb_4->setText(QString());
        fpga2_d25_dcb_4->setText(QString());
        fpga3_d25_dcb_4->setText(QString());
        fpga4_d25_dcb_4->setText(QString());
        fpga5_d25_dcb_4->setText(QString());
        label_62->setText(QApplication::translate("dialog_dcb", "Digital 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_d33_dcb_4->setText(QString());
        fpga2_d33_dcb_4->setText(QString());
        fpga3_d33_dcb_4->setText(QString());
        fpga4_d33_dcb_4->setText(QString());
        fpga5_d33_dcb_4->setText(QString());
        label_65->setText(QApplication::translate("dialog_dcb", "Digital 5.0V", 0, QApplication::UnicodeUTF8));
        fpga1_d5_dcb_4->setText(QString());
        fpga2_d5_dcb_4->setText(QString());
        fpga3_d5_dcb_4->setText(QString());
        fpga4_d5_dcb_4->setText(QString());
        fpga5_d5_dcb_4->setText(QString());
        label_69->setText(QApplication::translate("dialog_dcb", "Analog 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_a18_dcb_4->setText(QString());
        fpga2_a18_dcb_4->setText(QString());
        fpga3_a18_dcb_4->setText(QString());
        fpga4_a18_dcb_4->setText(QString());
        fpga5_a18_dcb_4->setText(QString());
        label_60->setText(QApplication::translate("dialog_dcb", "Analog 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_a33_dcb_4->setText(QString());
        fpga2_a33_dcb_4->setText(QString());
        fpga3_a33_dcb_4->setText(QString());
        fpga4_a33_dcb_4->setText(QString());
        fpga5_a33_dcb_4->setText(QString());
        tab_dcb->setTabText(tab_dcb->indexOf(DCB4), QApplication::translate("dialog_dcb", "DCB 4", 0, QApplication::UnicodeUTF8));
        label_74->setText(QApplication::translate("dialog_dcb", "FPGA 1", 0, QApplication::UnicodeUTF8));
        label_85->setText(QApplication::translate("dialog_dcb", "FPGA 2", 0, QApplication::UnicodeUTF8));
        label_82->setText(QApplication::translate("dialog_dcb", "FPGA 3", 0, QApplication::UnicodeUTF8));
        label_75->setText(QApplication::translate("dialog_dcb", "FPGA 4", 0, QApplication::UnicodeUTF8));
        label_77->setText(QApplication::translate("dialog_dcb", "FPGA 5", 0, QApplication::UnicodeUTF8));
        label_73->setText(QApplication::translate("dialog_dcb", "Connected", 0, QApplication::UnicodeUTF8));
        fpga1_con_dcb_5->setText(QString());
        fpga2_con_dcb_5->setText(QString());
        fpga3_con_dcb_5->setText(QString());
        fpga4_con_dcb_5->setText(QString());
        fpga5_con_dcb_5->setText(QString());
        label_84->setText(QApplication::translate("dialog_dcb", "Healthy", 0, QApplication::UnicodeUTF8));
        fpga1_hlt_dcb_5->setText(QString());
        fpga2_hlt_dcb_5->setText(QString());
        fpga3_hlt_dcb_5->setText(QString());
        fpga4_hlt_dcb_5->setText(QString());
        fpga5_hlt_dcb_5->setText(QString());
        label_80->setText(QApplication::translate("dialog_dcb", "Ready", 0, QApplication::UnicodeUTF8));
        fpga1_rdy_dcb_5->setText(QString());
        fpga2_rdy_dcb_5->setText(QString());
        fpga3_rdy_dcb_5->setText(QString());
        fpga4_rdy_dcb_5->setText(QString());
        fpga5_rdy_dcb_5->setText(QString());
        label_78->setText(QApplication::translate("dialog_dcb", "Digital 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_d18_dcb_5->setText(QString());
        fpga2_d18_dcb_5->setText(QString());
        fpga3_d18_dcb_5->setText(QString());
        fpga4_d18_dcb_5->setText(QString());
        fpga5_d18_dcb_5->setText(QString());
        label_81->setText(QApplication::translate("dialog_dcb", "Digital 2.5V", 0, QApplication::UnicodeUTF8));
        fpga1_d25_dcb_5->setText(QString());
        fpga2_d25_dcb_5->setText(QString());
        fpga3_d25_dcb_5->setText(QString());
        fpga4_d25_dcb_5->setText(QString());
        fpga5_d25_dcb_5->setText(QString());
        label_72->setText(QApplication::translate("dialog_dcb", "Digital 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_d33_dcb_5->setText(QString());
        fpga2_d33_dcb_5->setText(QString());
        fpga3_d33_dcb_5->setText(QString());
        fpga4_d33_dcb_5->setText(QString());
        fpga5_d33_dcb_5->setText(QString());
        label_79->setText(QApplication::translate("dialog_dcb", "Digital 5.0V", 0, QApplication::UnicodeUTF8));
        fpga1_d5_dcb_5->setText(QString());
        fpga2_d5_dcb_5->setText(QString());
        fpga3_d5_dcb_5->setText(QString());
        fpga4_d5_dcb_5->setText(QString());
        fpga5_d5_dcb_5->setText(QString());
        label_83->setText(QApplication::translate("dialog_dcb", "Analog 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_a18_dcb_5->setText(QString());
        fpga2_a18_dcb_5->setText(QString());
        fpga3_a18_dcb_5->setText(QString());
        fpga4_a18_dcb_5->setText(QString());
        fpga5_a18_dcb_5->setText(QString());
        label_76->setText(QApplication::translate("dialog_dcb", "Analog 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_a33_dcb_5->setText(QString());
        fpga2_a33_dcb_5->setText(QString());
        fpga3_a33_dcb_5->setText(QString());
        fpga4_a33_dcb_5->setText(QString());
        fpga5_a33_dcb_5->setText(QString());
        tab_dcb->setTabText(tab_dcb->indexOf(DCB5), QApplication::translate("dialog_dcb", "DCB 5", 0, QApplication::UnicodeUTF8));
        label_97->setText(QApplication::translate("dialog_dcb", "FPGA 1", 0, QApplication::UnicodeUTF8));
        label_98->setText(QApplication::translate("dialog_dcb", "FPGA 2", 0, QApplication::UnicodeUTF8));
        label_93->setText(QApplication::translate("dialog_dcb", "FPGA 3", 0, QApplication::UnicodeUTF8));
        label_86->setText(QApplication::translate("dialog_dcb", "FPGA 4", 0, QApplication::UnicodeUTF8));
        label_90->setText(QApplication::translate("dialog_dcb", "FPGA 5", 0, QApplication::UnicodeUTF8));
        label_91->setText(QApplication::translate("dialog_dcb", "Connected", 0, QApplication::UnicodeUTF8));
        fpga1_con_dcb_6->setText(QString());
        fpga2_con_dcb_6->setText(QString());
        fpga3_con_dcb_6->setText(QString());
        fpga4_con_dcb_6->setText(QString());
        fpga5_con_dcb_6->setText(QString());
        label_89->setText(QApplication::translate("dialog_dcb", "Healthy", 0, QApplication::UnicodeUTF8));
        fpga1_hlt_dcb_6->setText(QString());
        fpga2_hlt_dcb_6->setText(QString());
        fpga3_hlt_dcb_6->setText(QString());
        fpga4_hlt_dcb_6->setText(QString());
        fpga5_hlt_dcb_6->setText(QString());
        label_92->setText(QApplication::translate("dialog_dcb", "Ready", 0, QApplication::UnicodeUTF8));
        fpga1_rdy_dcb_6->setText(QString());
        fpga2_rdy_dcb_6->setText(QString());
        fpga3_rdy_dcb_6->setText(QString());
        fpga4_rdy_dcb_6->setText(QString());
        fpga5_rdy_dcb_6->setText(QString());
        label_88->setText(QApplication::translate("dialog_dcb", "Digital 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_d18_dcb_6->setText(QString());
        fpga2_d18_dcb_6->setText(QString());
        fpga3_d18_dcb_6->setText(QString());
        fpga4_d18_dcb_6->setText(QString());
        fpga5_d18_dcb_6->setText(QString());
        label_94->setText(QApplication::translate("dialog_dcb", "Digital 2.5V", 0, QApplication::UnicodeUTF8));
        fpga1_d25_dcb_6->setText(QString());
        fpga2_d25_dcb_6->setText(QString());
        fpga3_d25_dcb_6->setText(QString());
        fpga4_d25_dcb_6->setText(QString());
        fpga5_d25_dcb_6->setText(QString());
        label_96->setText(QApplication::translate("dialog_dcb", "Digital 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_d33_dcb_6->setText(QString());
        fpga2_d33_dcb_6->setText(QString());
        fpga3_d33_dcb_6->setText(QString());
        fpga4_d33_dcb_6->setText(QString());
        fpga5_d33_dcb_6->setText(QString());
        label_95->setText(QApplication::translate("dialog_dcb", "Digital 5.0V", 0, QApplication::UnicodeUTF8));
        fpga1_d5_dcb_6->setText(QString());
        fpga2_d5_dcb_6->setText(QString());
        fpga3_d5_dcb_6->setText(QString());
        fpga4_d5_dcb_6->setText(QString());
        fpga5_d5_dcb_6->setText(QString());
        label_99->setText(QApplication::translate("dialog_dcb", "Analog 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_a18_dcb_6->setText(QString());
        fpga2_a18_dcb_6->setText(QString());
        fpga3_a18_dcb_6->setText(QString());
        fpga4_a18_dcb_6->setText(QString());
        fpga5_a18_dcb_6->setText(QString());
        label_87->setText(QApplication::translate("dialog_dcb", "Analog 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_a33_dcb_6->setText(QString());
        fpga2_a33_dcb_6->setText(QString());
        fpga3_a33_dcb_6->setText(QString());
        fpga4_a33_dcb_6->setText(QString());
        fpga5_a33_dcb_6->setText(QString());
        tab_dcb->setTabText(tab_dcb->indexOf(DCB6), QApplication::translate("dialog_dcb", "DCB 6", 0, QApplication::UnicodeUTF8));
        label_106->setText(QApplication::translate("dialog_dcb", "FPGA 1", 0, QApplication::UnicodeUTF8));
        label_111->setText(QApplication::translate("dialog_dcb", "FPGA 2", 0, QApplication::UnicodeUTF8));
        label_107->setText(QApplication::translate("dialog_dcb", "FPGA 3", 0, QApplication::UnicodeUTF8));
        label_103->setText(QApplication::translate("dialog_dcb", "FPGA 4", 0, QApplication::UnicodeUTF8));
        label_102->setText(QApplication::translate("dialog_dcb", "FPGA 5", 0, QApplication::UnicodeUTF8));
        label_100->setText(QApplication::translate("dialog_dcb", "Connected", 0, QApplication::UnicodeUTF8));
        fpga1_con_dcb_7->setText(QString());
        fpga2_con_dcb_7->setText(QString());
        fpga3_con_dcb_7->setText(QString());
        fpga4_con_dcb_7->setText(QString());
        fpga5_con_dcb_7->setText(QString());
        label_108->setText(QApplication::translate("dialog_dcb", "Healthy", 0, QApplication::UnicodeUTF8));
        fpga1_hlt_dcb_7->setText(QString());
        fpga2_hlt_dcb_7->setText(QString());
        fpga3_hlt_dcb_7->setText(QString());
        fpga4_hlt_dcb_7->setText(QString());
        fpga5_hlt_dcb_7->setText(QString());
        label_110->setText(QApplication::translate("dialog_dcb", "Ready", 0, QApplication::UnicodeUTF8));
        fpga1_rdy_dcb_7->setText(QString());
        fpga2_rdy_dcb_7->setText(QString());
        fpga3_rdy_dcb_7->setText(QString());
        fpga4_rdy_dcb_7->setText(QString());
        fpga5_rdy_dcb_7->setText(QString());
        label_113->setText(QApplication::translate("dialog_dcb", "Digital 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_d18_dcb_7->setText(QString());
        fpga2_d18_dcb_7->setText(QString());
        fpga3_d18_dcb_7->setText(QString());
        fpga4_d18_dcb_7->setText(QString());
        fpga5_d18_dcb_7->setText(QString());
        label_109->setText(QApplication::translate("dialog_dcb", "Digital 2.5V", 0, QApplication::UnicodeUTF8));
        fpga1_d25_dcb_7->setText(QString());
        fpga2_d25_dcb_7->setText(QString());
        fpga3_d25_dcb_7->setText(QString());
        fpga4_d25_dcb_7->setText(QString());
        fpga5_d25_dcb_7->setText(QString());
        label_112->setText(QApplication::translate("dialog_dcb", "Digital 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_d33_dcb_7->setText(QString());
        fpga2_d33_dcb_7->setText(QString());
        fpga3_d33_dcb_7->setText(QString());
        fpga4_d33_dcb_7->setText(QString());
        fpga5_d33_dcb_7->setText(QString());
        label_104->setText(QApplication::translate("dialog_dcb", "Digital 5.0V", 0, QApplication::UnicodeUTF8));
        fpga1_d5_dcb_7->setText(QString());
        fpga2_d5_dcb_7->setText(QString());
        fpga3_d5_dcb_7->setText(QString());
        fpga4_d5_dcb_7->setText(QString());
        fpga5_d5_dcb_7->setText(QString());
        label_105->setText(QApplication::translate("dialog_dcb", "Analog 1.8V", 0, QApplication::UnicodeUTF8));
        fpga1_a18_dcb_7->setText(QString());
        fpga2_a18_dcb_7->setText(QString());
        fpga3_a18_dcb_7->setText(QString());
        fpga4_a18_dcb_7->setText(QString());
        fpga5_a18_dcb_7->setText(QString());
        label_101->setText(QApplication::translate("dialog_dcb", "Analog 3.3V", 0, QApplication::UnicodeUTF8));
        fpga1_a33_dcb_7->setText(QString());
        fpga2_a33_dcb_7->setText(QString());
        fpga3_a33_dcb_7->setText(QString());
        fpga4_a33_dcb_7->setText(QString());
        fpga5_a33_dcb_7->setText(QString());
        tab_dcb->setTabText(tab_dcb->indexOf(DCB7), QApplication::translate("dialog_dcb", "DCB 7", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class dialog_dcb: public Ui_dialog_dcb {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_DCB_H
