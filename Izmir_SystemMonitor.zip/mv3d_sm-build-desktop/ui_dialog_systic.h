/********************************************************************************
** Form generated from reading UI file 'dialog_systic.ui'
**
** Created: Mon Aug 10 11:27:57 2020
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_SYSTIC_H
#define UI_DIALOG_SYSTIC_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QSpacerItem>
#include <QtGui/QTabWidget>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_dialog_systic
{
public:
    QGridLayout *gridLayout;
    QGroupBox *groupBox_6;
    QGridLayout *gridLayout_21;
    QLabel *interlock_6;
    QLabel *interlock_3;
    QLabel *interlock_2;
    QSpacerItem *horizontalSpacer_51;
    QSpacerItem *horizontalSpacer_52;
    QSpacerItem *horizontalSpacer_53;
    QLabel *interlock_5;
    QSpacerItem *horizontalSpacer_54;
    QSpacerItem *horizontalSpacer_55;
    QSpacerItem *horizontalSpacer_57;
    QSpacerItem *horizontalSpacer_58;
    QLabel *interlock_1;
    QLabel *interlock_4;
    QSpacerItem *horizontalSpacer_59;
    QSpacerItem *horizontalSpacer_60;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout_18;
    QLabel *systic_highBlock;
    QLabel *systic_highBlock_2;
    QLabel *systic_highBlock_3;
    QLabel *systic_highBlock_4;
    QLabel *systic_highBlock_5;
    QLabel *systic_highBlock_6;
    QLabel *systic_highBlock_7;
    QLabel *systic_highBlock_8;
    QLabel *systic_highBlock_9;
    QLabel *systic_highBlock_10;
    QLabel *systic_highBlock_11;
    QLabel *systic_highBlock_12;
    QLabel *systic_highBlock_13;
    QLabel *systic_highBlock_14;
    QLabel *systic_highBlock_15;
    QLabel *systic_highBlock_16;
    QLabel *systic_lowBlock;
    QLabel *systic_lowBlock_2;
    QLabel *systic_lowBlock_3;
    QLabel *systic_lowBlock_4;
    QLabel *systic_lowBlock_5;
    QLabel *systic_lowBlock_6;
    QLabel *systic_lowBlock_7;
    QLabel *systic_lowBlock_8;
    QLabel *systic_lowBlock_9;
    QLabel *systic_lowBlock_10;
    QLabel *systic_lowBlock_11;
    QLabel *systic_lowBlock_12;
    QLabel *systic_lowBlock_13;
    QLabel *systic_lowBlock_14;
    QLabel *systic_lowBlock_15;
    QLabel *systic_lowBlock_16;
    QGroupBox *groupBox_7;
    QGridLayout *gridLayout_27;
    QLabel *estop_8;
    QSpacerItem *horizontalSpacer_41;
    QLabel *estop_1;
    QSpacerItem *horizontalSpacer_42;
    QLabel *estop_5;
    QSpacerItem *horizontalSpacer_43;
    QLabel *estop_7;
    QSpacerItem *horizontalSpacer_44;
    QLabel *estop_2;
    QLabel *estop_3;
    QSpacerItem *horizontalSpacer_45;
    QSpacerItem *horizontalSpacer_46;
    QSpacerItem *horizontalSpacer_47;
    QSpacerItem *horizontalSpacer_48;
    QSpacerItem *horizontalSpacer_49;
    QLabel *estop_4;
    QLabel *estop_6;
    QSpacerItem *horizontalSpacer_50;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_22;
    QLabel *actv_dcb6;
    QLabel *label_157;
    QLabel *actv_dcb3;
    QLabel *label_158;
    QLabel *label_159;
    QLabel *health_dcb4;
    QLabel *label_160;
    QLabel *con_dcb3;
    QLabel *con_dcb7;
    QLabel *label_161;
    QLabel *label_162;
    QLabel *ready_dcb5;
    QLabel *actv_dcb7;
    QLabel *con_dcb6;
    QLabel *actv_dcb1;
    QLabel *con_dcb2;
    QLabel *label_163;
    QLabel *actv_dcb4;
    QLabel *ready_dcb4;
    QLabel *ready_dcb2;
    QLabel *con_dcb5;
    QLabel *label_164;
    QLabel *con_dcb4;
    QLabel *actv_dcb5;
    QLabel *health_dcb1;
    QLabel *health_dcb7;
    QLabel *health_dcb2;
    QLabel *health_dcb3;
    QLabel *con_dcb1;
    QLabel *ready_dcb3;
    QLabel *ready_dcb1;
    QLabel *health_dcb6;
    QLabel *ready_dcb7;
    QLabel *label_165;
    QLabel *label_166;
    QLabel *actv_dcb2;
    QLabel *ready_dcb6;
    QLabel *health_dcb5;
    QLabel *label_167;
    QSpacerItem *verticalSpacer_7;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_20;
    QLabel *con_hvps2;
    QLabel *label_150;
    QLabel *hlt_hvps2;
    QLabel *hlt_hvps1;
    QLabel *label_151;
    QLabel *label_152;
    QLabel *actv_hvps1;
    QLabel *hlt_hvps3;
    QLabel *rdy_hvps2;
    QLabel *con_hvps1;
    QSpacerItem *verticalSpacer_6;
    QLabel *label_153;
    QLabel *label_154;
    QLabel *label_155;
    QLabel *actv_hvps3;
    QLabel *con_hvps3;
    QLabel *rdy_hvps3;
    QLabel *rdy_hvps1;
    QLabel *actv_hvps2;
    QLabel *label_156;
    QWidget *widget_2;
    QGridLayout *gridLayout_16;
    QLabel *systic_temp_value;
    QLabel *label_temp_5;
    QGroupBox *groupBox_5;
    QGridLayout *gridLayout_19;
    QLabel *systic_ent_ph;
    QLabel *systic_ent_ph2;
    QWidget *widget;
    QGridLayout *gridLayout_17;
    QLabel *label_temp_6;
    QLabel *sdb_temp_value;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout_2;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout_3;
    QLabel *label;
    QLabel *ups1_input_freq;
    QLabel *label_3;
    QLabel *ups1_input_vol;
    QGroupBox *groupBox_8;
    QGridLayout *gridLayout_5;
    QLabel *label_7;
    QLabel *ups1_status;
    QLabel *label_9;
    QLabel *ups1_temp;
    QLabel *label_11;
    QLabel *ups1_load;
    QLabel *label_13;
    QLabel *ups1_charge;
    QGroupBox *groupBox_9;
    QGridLayout *gridLayout_4;
    QLabel *label_5;
    QLabel *ups1_output_vol;
    QLabel *label_15;
    QLabel *ups1_model;
    QWidget *tab_2;
    QGridLayout *gridLayout_9;
    QLabel *label_16;
    QLabel *ups2_model;
    QGroupBox *groupBox_11;
    QGridLayout *gridLayout_7;
    QLabel *label_2;
    QLabel *ups2_input_freq;
    QLabel *label_4;
    QLabel *ups2_input_vol;
    QGroupBox *groupBox_10;
    QGridLayout *gridLayout_6;
    QLabel *label_8;
    QLabel *ups2_status;
    QLabel *label_10;
    QLabel *ups2_temp;
    QLabel *label_12;
    QLabel *ups2_load;
    QLabel *label_14;
    QLabel *ups2_charge;
    QGroupBox *groupBox_12;
    QGridLayout *gridLayout_8;
    QLabel *label_6;
    QLabel *ups2_output_vol;

    void setupUi(QDialog *dialog_systic)
    {
        if (dialog_systic->objectName().isEmpty())
            dialog_systic->setObjectName(QString::fromUtf8("dialog_systic"));
        dialog_systic->resize(470, 863);
        dialog_systic->setMinimumSize(QSize(470, 863));
        dialog_systic->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        gridLayout = new QGridLayout(dialog_systic);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        groupBox_6 = new QGroupBox(dialog_systic);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        groupBox_6->setMaximumSize(QSize(16777215, 75));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        groupBox_6->setFont(font);
        gridLayout_21 = new QGridLayout(groupBox_6);
        gridLayout_21->setObjectName(QString::fromUtf8("gridLayout_21"));
        interlock_6 = new QLabel(groupBox_6);
        interlock_6->setObjectName(QString::fromUtf8("interlock_6"));
        interlock_6->setMinimumSize(QSize(20, 26));
        interlock_6->setMaximumSize(QSize(20, 26));
        interlock_6->setFont(font);
        interlock_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        interlock_6->setAlignment(Qt::AlignCenter);

        gridLayout_21->addWidget(interlock_6, 0, 10, 1, 1);

        interlock_3 = new QLabel(groupBox_6);
        interlock_3->setObjectName(QString::fromUtf8("interlock_3"));
        interlock_3->setMinimumSize(QSize(20, 26));
        interlock_3->setMaximumSize(QSize(20, 26));
        interlock_3->setFont(font);
        interlock_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        interlock_3->setAlignment(Qt::AlignCenter);

        gridLayout_21->addWidget(interlock_3, 0, 4, 1, 1);

        interlock_2 = new QLabel(groupBox_6);
        interlock_2->setObjectName(QString::fromUtf8("interlock_2"));
        interlock_2->setMinimumSize(QSize(20, 26));
        interlock_2->setMaximumSize(QSize(20, 26));
        interlock_2->setFont(font);
        interlock_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        interlock_2->setAlignment(Qt::AlignCenter);

        gridLayout_21->addWidget(interlock_2, 0, 2, 1, 1);

        horizontalSpacer_51 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_51, 0, 14, 1, 1);

        horizontalSpacer_52 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_52, 0, 13, 1, 1);

        horizontalSpacer_53 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_53, 0, 9, 1, 1);

        interlock_5 = new QLabel(groupBox_6);
        interlock_5->setObjectName(QString::fromUtf8("interlock_5"));
        interlock_5->setMinimumSize(QSize(20, 26));
        interlock_5->setMaximumSize(QSize(20, 26));
        interlock_5->setFont(font);
        interlock_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        interlock_5->setAlignment(Qt::AlignCenter);

        gridLayout_21->addWidget(interlock_5, 0, 8, 1, 1);

        horizontalSpacer_54 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_54, 0, 1, 1, 1);

        horizontalSpacer_55 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_55, 0, 11, 1, 1);

        horizontalSpacer_57 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_57, 0, 3, 1, 1);

        horizontalSpacer_58 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_58, 0, 7, 1, 1);

        interlock_1 = new QLabel(groupBox_6);
        interlock_1->setObjectName(QString::fromUtf8("interlock_1"));
        interlock_1->setMinimumSize(QSize(20, 26));
        interlock_1->setMaximumSize(QSize(20, 26));
        interlock_1->setFont(font);
        interlock_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        interlock_1->setAlignment(Qt::AlignCenter);

        gridLayout_21->addWidget(interlock_1, 0, 0, 1, 1);

        interlock_4 = new QLabel(groupBox_6);
        interlock_4->setObjectName(QString::fromUtf8("interlock_4"));
        interlock_4->setMinimumSize(QSize(20, 26));
        interlock_4->setMaximumSize(QSize(20, 26));
        interlock_4->setFont(font);
        interlock_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        interlock_4->setAlignment(Qt::AlignCenter);

        gridLayout_21->addWidget(interlock_4, 0, 6, 1, 1);

        horizontalSpacer_59 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_59, 0, 5, 1, 1);

        horizontalSpacer_60 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_60, 0, 12, 1, 1);


        gridLayout->addWidget(groupBox_6, 0, 0, 1, 3);

        groupBox_4 = new QGroupBox(dialog_systic);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setMinimumSize(QSize(40, 0));
        groupBox_4->setMaximumSize(QSize(40, 16777215));
        QFont font1;
        font1.setBold(false);
        font1.setWeight(50);
        groupBox_4->setFont(font1);
        groupBox_4->setAlignment(Qt::AlignCenter);
        gridLayout_18 = new QGridLayout(groupBox_4);
        gridLayout_18->setObjectName(QString::fromUtf8("gridLayout_18"));
        gridLayout_18->setContentsMargins(-1, 20, -1, -1);
        systic_highBlock = new QLabel(groupBox_4);
        systic_highBlock->setObjectName(QString::fromUtf8("systic_highBlock"));
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(systic_highBlock->sizePolicy().hasHeightForWidth());
        systic_highBlock->setSizePolicy(sizePolicy);
        systic_highBlock->setMinimumSize(QSize(15, 12));
        systic_highBlock->setMaximumSize(QSize(10, 16));
        systic_highBlock->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock, 0, 0, 1, 1);

        systic_highBlock_2 = new QLabel(groupBox_4);
        systic_highBlock_2->setObjectName(QString::fromUtf8("systic_highBlock_2"));
        sizePolicy.setHeightForWidth(systic_highBlock_2->sizePolicy().hasHeightForWidth());
        systic_highBlock_2->setSizePolicy(sizePolicy);
        systic_highBlock_2->setMinimumSize(QSize(15, 12));
        systic_highBlock_2->setMaximumSize(QSize(10, 16));
        systic_highBlock_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_2, 1, 0, 1, 1);

        systic_highBlock_3 = new QLabel(groupBox_4);
        systic_highBlock_3->setObjectName(QString::fromUtf8("systic_highBlock_3"));
        sizePolicy.setHeightForWidth(systic_highBlock_3->sizePolicy().hasHeightForWidth());
        systic_highBlock_3->setSizePolicy(sizePolicy);
        systic_highBlock_3->setMinimumSize(QSize(15, 12));
        systic_highBlock_3->setMaximumSize(QSize(10, 16));
        systic_highBlock_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_3, 2, 0, 1, 1);

        systic_highBlock_4 = new QLabel(groupBox_4);
        systic_highBlock_4->setObjectName(QString::fromUtf8("systic_highBlock_4"));
        sizePolicy.setHeightForWidth(systic_highBlock_4->sizePolicy().hasHeightForWidth());
        systic_highBlock_4->setSizePolicy(sizePolicy);
        systic_highBlock_4->setMinimumSize(QSize(15, 12));
        systic_highBlock_4->setMaximumSize(QSize(10, 16));
        systic_highBlock_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_4, 3, 0, 1, 1);

        systic_highBlock_5 = new QLabel(groupBox_4);
        systic_highBlock_5->setObjectName(QString::fromUtf8("systic_highBlock_5"));
        sizePolicy.setHeightForWidth(systic_highBlock_5->sizePolicy().hasHeightForWidth());
        systic_highBlock_5->setSizePolicy(sizePolicy);
        systic_highBlock_5->setMinimumSize(QSize(15, 12));
        systic_highBlock_5->setMaximumSize(QSize(10, 16));
        systic_highBlock_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_5, 4, 0, 1, 1);

        systic_highBlock_6 = new QLabel(groupBox_4);
        systic_highBlock_6->setObjectName(QString::fromUtf8("systic_highBlock_6"));
        sizePolicy.setHeightForWidth(systic_highBlock_6->sizePolicy().hasHeightForWidth());
        systic_highBlock_6->setSizePolicy(sizePolicy);
        systic_highBlock_6->setMinimumSize(QSize(15, 12));
        systic_highBlock_6->setMaximumSize(QSize(10, 16));
        systic_highBlock_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_6, 5, 0, 1, 1);

        systic_highBlock_7 = new QLabel(groupBox_4);
        systic_highBlock_7->setObjectName(QString::fromUtf8("systic_highBlock_7"));
        sizePolicy.setHeightForWidth(systic_highBlock_7->sizePolicy().hasHeightForWidth());
        systic_highBlock_7->setSizePolicy(sizePolicy);
        systic_highBlock_7->setMinimumSize(QSize(15, 12));
        systic_highBlock_7->setMaximumSize(QSize(10, 16));
        systic_highBlock_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_7, 6, 0, 1, 1);

        systic_highBlock_8 = new QLabel(groupBox_4);
        systic_highBlock_8->setObjectName(QString::fromUtf8("systic_highBlock_8"));
        sizePolicy.setHeightForWidth(systic_highBlock_8->sizePolicy().hasHeightForWidth());
        systic_highBlock_8->setSizePolicy(sizePolicy);
        systic_highBlock_8->setMinimumSize(QSize(15, 12));
        systic_highBlock_8->setMaximumSize(QSize(10, 16));
        systic_highBlock_8->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_8, 7, 0, 1, 1);

        systic_highBlock_9 = new QLabel(groupBox_4);
        systic_highBlock_9->setObjectName(QString::fromUtf8("systic_highBlock_9"));
        sizePolicy.setHeightForWidth(systic_highBlock_9->sizePolicy().hasHeightForWidth());
        systic_highBlock_9->setSizePolicy(sizePolicy);
        systic_highBlock_9->setMinimumSize(QSize(15, 12));
        systic_highBlock_9->setMaximumSize(QSize(10, 16));
        systic_highBlock_9->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_9, 8, 0, 1, 1);

        systic_highBlock_10 = new QLabel(groupBox_4);
        systic_highBlock_10->setObjectName(QString::fromUtf8("systic_highBlock_10"));
        sizePolicy.setHeightForWidth(systic_highBlock_10->sizePolicy().hasHeightForWidth());
        systic_highBlock_10->setSizePolicy(sizePolicy);
        systic_highBlock_10->setMinimumSize(QSize(15, 12));
        systic_highBlock_10->setMaximumSize(QSize(10, 16));
        systic_highBlock_10->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_10, 9, 0, 1, 1);

        systic_highBlock_11 = new QLabel(groupBox_4);
        systic_highBlock_11->setObjectName(QString::fromUtf8("systic_highBlock_11"));
        sizePolicy.setHeightForWidth(systic_highBlock_11->sizePolicy().hasHeightForWidth());
        systic_highBlock_11->setSizePolicy(sizePolicy);
        systic_highBlock_11->setMinimumSize(QSize(15, 12));
        systic_highBlock_11->setMaximumSize(QSize(10, 16));
        systic_highBlock_11->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_11, 10, 0, 1, 1);

        systic_highBlock_12 = new QLabel(groupBox_4);
        systic_highBlock_12->setObjectName(QString::fromUtf8("systic_highBlock_12"));
        sizePolicy.setHeightForWidth(systic_highBlock_12->sizePolicy().hasHeightForWidth());
        systic_highBlock_12->setSizePolicy(sizePolicy);
        systic_highBlock_12->setMinimumSize(QSize(15, 12));
        systic_highBlock_12->setMaximumSize(QSize(10, 16));
        systic_highBlock_12->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_12, 11, 0, 1, 1);

        systic_highBlock_13 = new QLabel(groupBox_4);
        systic_highBlock_13->setObjectName(QString::fromUtf8("systic_highBlock_13"));
        sizePolicy.setHeightForWidth(systic_highBlock_13->sizePolicy().hasHeightForWidth());
        systic_highBlock_13->setSizePolicy(sizePolicy);
        systic_highBlock_13->setMinimumSize(QSize(15, 12));
        systic_highBlock_13->setMaximumSize(QSize(10, 16));
        systic_highBlock_13->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_13, 12, 0, 1, 1);

        systic_highBlock_14 = new QLabel(groupBox_4);
        systic_highBlock_14->setObjectName(QString::fromUtf8("systic_highBlock_14"));
        sizePolicy.setHeightForWidth(systic_highBlock_14->sizePolicy().hasHeightForWidth());
        systic_highBlock_14->setSizePolicy(sizePolicy);
        systic_highBlock_14->setMinimumSize(QSize(15, 12));
        systic_highBlock_14->setMaximumSize(QSize(10, 16));
        systic_highBlock_14->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_14, 13, 0, 1, 1);

        systic_highBlock_15 = new QLabel(groupBox_4);
        systic_highBlock_15->setObjectName(QString::fromUtf8("systic_highBlock_15"));
        sizePolicy.setHeightForWidth(systic_highBlock_15->sizePolicy().hasHeightForWidth());
        systic_highBlock_15->setSizePolicy(sizePolicy);
        systic_highBlock_15->setMinimumSize(QSize(15, 12));
        systic_highBlock_15->setMaximumSize(QSize(10, 16));
        systic_highBlock_15->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_15, 14, 0, 1, 1);

        systic_highBlock_16 = new QLabel(groupBox_4);
        systic_highBlock_16->setObjectName(QString::fromUtf8("systic_highBlock_16"));
        sizePolicy.setHeightForWidth(systic_highBlock_16->sizePolicy().hasHeightForWidth());
        systic_highBlock_16->setSizePolicy(sizePolicy);
        systic_highBlock_16->setMinimumSize(QSize(15, 12));
        systic_highBlock_16->setMaximumSize(QSize(10, 16));
        systic_highBlock_16->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_highBlock_16, 15, 0, 1, 1);

        systic_lowBlock = new QLabel(groupBox_4);
        systic_lowBlock->setObjectName(QString::fromUtf8("systic_lowBlock"));
        sizePolicy.setHeightForWidth(systic_lowBlock->sizePolicy().hasHeightForWidth());
        systic_lowBlock->setSizePolicy(sizePolicy);
        systic_lowBlock->setMinimumSize(QSize(15, 12));
        systic_lowBlock->setMaximumSize(QSize(10, 16));
        systic_lowBlock->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock, 16, 0, 1, 1);

        systic_lowBlock_2 = new QLabel(groupBox_4);
        systic_lowBlock_2->setObjectName(QString::fromUtf8("systic_lowBlock_2"));
        sizePolicy.setHeightForWidth(systic_lowBlock_2->sizePolicy().hasHeightForWidth());
        systic_lowBlock_2->setSizePolicy(sizePolicy);
        systic_lowBlock_2->setMinimumSize(QSize(15, 12));
        systic_lowBlock_2->setMaximumSize(QSize(10, 16));
        systic_lowBlock_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_2, 17, 0, 1, 1);

        systic_lowBlock_3 = new QLabel(groupBox_4);
        systic_lowBlock_3->setObjectName(QString::fromUtf8("systic_lowBlock_3"));
        sizePolicy.setHeightForWidth(systic_lowBlock_3->sizePolicy().hasHeightForWidth());
        systic_lowBlock_3->setSizePolicy(sizePolicy);
        systic_lowBlock_3->setMinimumSize(QSize(15, 12));
        systic_lowBlock_3->setMaximumSize(QSize(10, 16));
        systic_lowBlock_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_3, 18, 0, 1, 1);

        systic_lowBlock_4 = new QLabel(groupBox_4);
        systic_lowBlock_4->setObjectName(QString::fromUtf8("systic_lowBlock_4"));
        sizePolicy.setHeightForWidth(systic_lowBlock_4->sizePolicy().hasHeightForWidth());
        systic_lowBlock_4->setSizePolicy(sizePolicy);
        systic_lowBlock_4->setMinimumSize(QSize(15, 12));
        systic_lowBlock_4->setMaximumSize(QSize(10, 16));
        systic_lowBlock_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_4, 19, 0, 1, 1);

        systic_lowBlock_5 = new QLabel(groupBox_4);
        systic_lowBlock_5->setObjectName(QString::fromUtf8("systic_lowBlock_5"));
        sizePolicy.setHeightForWidth(systic_lowBlock_5->sizePolicy().hasHeightForWidth());
        systic_lowBlock_5->setSizePolicy(sizePolicy);
        systic_lowBlock_5->setMinimumSize(QSize(15, 12));
        systic_lowBlock_5->setMaximumSize(QSize(10, 16));
        systic_lowBlock_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_5, 20, 0, 1, 1);

        systic_lowBlock_6 = new QLabel(groupBox_4);
        systic_lowBlock_6->setObjectName(QString::fromUtf8("systic_lowBlock_6"));
        sizePolicy.setHeightForWidth(systic_lowBlock_6->sizePolicy().hasHeightForWidth());
        systic_lowBlock_6->setSizePolicy(sizePolicy);
        systic_lowBlock_6->setMinimumSize(QSize(15, 12));
        systic_lowBlock_6->setMaximumSize(QSize(10, 16));
        systic_lowBlock_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_6, 21, 0, 1, 1);

        systic_lowBlock_7 = new QLabel(groupBox_4);
        systic_lowBlock_7->setObjectName(QString::fromUtf8("systic_lowBlock_7"));
        sizePolicy.setHeightForWidth(systic_lowBlock_7->sizePolicy().hasHeightForWidth());
        systic_lowBlock_7->setSizePolicy(sizePolicy);
        systic_lowBlock_7->setMinimumSize(QSize(15, 12));
        systic_lowBlock_7->setMaximumSize(QSize(10, 16));
        systic_lowBlock_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_7, 22, 0, 1, 1);

        systic_lowBlock_8 = new QLabel(groupBox_4);
        systic_lowBlock_8->setObjectName(QString::fromUtf8("systic_lowBlock_8"));
        sizePolicy.setHeightForWidth(systic_lowBlock_8->sizePolicy().hasHeightForWidth());
        systic_lowBlock_8->setSizePolicy(sizePolicy);
        systic_lowBlock_8->setMinimumSize(QSize(15, 12));
        systic_lowBlock_8->setMaximumSize(QSize(10, 16));
        systic_lowBlock_8->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_8, 23, 0, 1, 1);

        systic_lowBlock_9 = new QLabel(groupBox_4);
        systic_lowBlock_9->setObjectName(QString::fromUtf8("systic_lowBlock_9"));
        sizePolicy.setHeightForWidth(systic_lowBlock_9->sizePolicy().hasHeightForWidth());
        systic_lowBlock_9->setSizePolicy(sizePolicy);
        systic_lowBlock_9->setMinimumSize(QSize(15, 12));
        systic_lowBlock_9->setMaximumSize(QSize(10, 16));
        systic_lowBlock_9->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_9, 24, 0, 1, 1);

        systic_lowBlock_10 = new QLabel(groupBox_4);
        systic_lowBlock_10->setObjectName(QString::fromUtf8("systic_lowBlock_10"));
        sizePolicy.setHeightForWidth(systic_lowBlock_10->sizePolicy().hasHeightForWidth());
        systic_lowBlock_10->setSizePolicy(sizePolicy);
        systic_lowBlock_10->setMinimumSize(QSize(15, 12));
        systic_lowBlock_10->setMaximumSize(QSize(10, 16));
        systic_lowBlock_10->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_10, 25, 0, 1, 1);

        systic_lowBlock_11 = new QLabel(groupBox_4);
        systic_lowBlock_11->setObjectName(QString::fromUtf8("systic_lowBlock_11"));
        sizePolicy.setHeightForWidth(systic_lowBlock_11->sizePolicy().hasHeightForWidth());
        systic_lowBlock_11->setSizePolicy(sizePolicy);
        systic_lowBlock_11->setMinimumSize(QSize(15, 12));
        systic_lowBlock_11->setMaximumSize(QSize(10, 16));
        systic_lowBlock_11->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_11, 26, 0, 1, 1);

        systic_lowBlock_12 = new QLabel(groupBox_4);
        systic_lowBlock_12->setObjectName(QString::fromUtf8("systic_lowBlock_12"));
        sizePolicy.setHeightForWidth(systic_lowBlock_12->sizePolicy().hasHeightForWidth());
        systic_lowBlock_12->setSizePolicy(sizePolicy);
        systic_lowBlock_12->setMinimumSize(QSize(15, 12));
        systic_lowBlock_12->setMaximumSize(QSize(10, 16));
        systic_lowBlock_12->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_12, 27, 0, 1, 1);

        systic_lowBlock_13 = new QLabel(groupBox_4);
        systic_lowBlock_13->setObjectName(QString::fromUtf8("systic_lowBlock_13"));
        sizePolicy.setHeightForWidth(systic_lowBlock_13->sizePolicy().hasHeightForWidth());
        systic_lowBlock_13->setSizePolicy(sizePolicy);
        systic_lowBlock_13->setMinimumSize(QSize(15, 12));
        systic_lowBlock_13->setMaximumSize(QSize(10, 16));
        systic_lowBlock_13->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_13, 28, 0, 1, 1);

        systic_lowBlock_14 = new QLabel(groupBox_4);
        systic_lowBlock_14->setObjectName(QString::fromUtf8("systic_lowBlock_14"));
        sizePolicy.setHeightForWidth(systic_lowBlock_14->sizePolicy().hasHeightForWidth());
        systic_lowBlock_14->setSizePolicy(sizePolicy);
        systic_lowBlock_14->setMinimumSize(QSize(15, 12));
        systic_lowBlock_14->setMaximumSize(QSize(10, 16));
        systic_lowBlock_14->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_14, 29, 0, 1, 1);

        systic_lowBlock_15 = new QLabel(groupBox_4);
        systic_lowBlock_15->setObjectName(QString::fromUtf8("systic_lowBlock_15"));
        sizePolicy.setHeightForWidth(systic_lowBlock_15->sizePolicy().hasHeightForWidth());
        systic_lowBlock_15->setSizePolicy(sizePolicy);
        systic_lowBlock_15->setMinimumSize(QSize(15, 12));
        systic_lowBlock_15->setMaximumSize(QSize(10, 16));
        systic_lowBlock_15->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_15, 30, 0, 1, 1);

        systic_lowBlock_16 = new QLabel(groupBox_4);
        systic_lowBlock_16->setObjectName(QString::fromUtf8("systic_lowBlock_16"));
        sizePolicy.setHeightForWidth(systic_lowBlock_16->sizePolicy().hasHeightForWidth());
        systic_lowBlock_16->setSizePolicy(sizePolicy);
        systic_lowBlock_16->setMinimumSize(QSize(15, 12));
        systic_lowBlock_16->setMaximumSize(QSize(10, 16));
        systic_lowBlock_16->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 1px;\n"
"margin-bottom: 1px;\n"
"margin-left: 0px;\n"
"margin-right: 0px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
"\n"
""));

        gridLayout_18->addWidget(systic_lowBlock_16, 31, 0, 1, 1);


        gridLayout->addWidget(groupBox_4, 0, 5, 7, 1);

        groupBox_7 = new QGroupBox(dialog_systic);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        groupBox_7->setMaximumSize(QSize(16777215, 75));
        groupBox_7->setFont(font);
        gridLayout_27 = new QGridLayout(groupBox_7);
        gridLayout_27->setObjectName(QString::fromUtf8("gridLayout_27"));
        estop_8 = new QLabel(groupBox_7);
        estop_8->setObjectName(QString::fromUtf8("estop_8"));
        estop_8->setMinimumSize(QSize(20, 26));
        estop_8->setMaximumSize(QSize(20, 26));
        estop_8->setFont(font);
        estop_8->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        estop_8->setAlignment(Qt::AlignCenter);

        gridLayout_27->addWidget(estop_8, 0, 17, 1, 1);

        horizontalSpacer_41 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_27->addItem(horizontalSpacer_41, 0, 14, 1, 1);

        estop_1 = new QLabel(groupBox_7);
        estop_1->setObjectName(QString::fromUtf8("estop_1"));
        estop_1->setMinimumSize(QSize(20, 26));
        estop_1->setMaximumSize(QSize(20, 26));
        estop_1->setFont(font);
        estop_1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        estop_1->setAlignment(Qt::AlignCenter);

        gridLayout_27->addWidget(estop_1, 0, 2, 1, 1);

        horizontalSpacer_42 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_27->addItem(horizontalSpacer_42, 0, 6, 1, 1);

        estop_5 = new QLabel(groupBox_7);
        estop_5->setObjectName(QString::fromUtf8("estop_5"));
        estop_5->setMinimumSize(QSize(20, 26));
        estop_5->setMaximumSize(QSize(20, 26));
        estop_5->setFont(font);
        estop_5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        estop_5->setAlignment(Qt::AlignCenter);

        gridLayout_27->addWidget(estop_5, 0, 11, 1, 1);

        horizontalSpacer_43 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_27->addItem(horizontalSpacer_43, 0, 16, 1, 1);

        estop_7 = new QLabel(groupBox_7);
        estop_7->setObjectName(QString::fromUtf8("estop_7"));
        estop_7->setMinimumSize(QSize(20, 26));
        estop_7->setMaximumSize(QSize(20, 26));
        estop_7->setFont(font);
        estop_7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        estop_7->setAlignment(Qt::AlignCenter);

        gridLayout_27->addWidget(estop_7, 0, 15, 1, 1);

        horizontalSpacer_44 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_27->addItem(horizontalSpacer_44, 0, 10, 1, 1);

        estop_2 = new QLabel(groupBox_7);
        estop_2->setObjectName(QString::fromUtf8("estop_2"));
        estop_2->setMinimumSize(QSize(20, 26));
        estop_2->setMaximumSize(QSize(20, 26));
        estop_2->setFont(font);
        estop_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        estop_2->setAlignment(Qt::AlignCenter);

        gridLayout_27->addWidget(estop_2, 0, 5, 1, 1);

        estop_3 = new QLabel(groupBox_7);
        estop_3->setObjectName(QString::fromUtf8("estop_3"));
        estop_3->setMinimumSize(QSize(20, 26));
        estop_3->setMaximumSize(QSize(20, 26));
        estop_3->setFont(font);
        estop_3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        estop_3->setAlignment(Qt::AlignCenter);

        gridLayout_27->addWidget(estop_3, 0, 7, 1, 1);

        horizontalSpacer_45 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_27->addItem(horizontalSpacer_45, 0, 3, 1, 1);

        horizontalSpacer_46 = new QSpacerItem(10, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_27->addItem(horizontalSpacer_46, 0, 0, 1, 1);

        horizontalSpacer_47 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_27->addItem(horizontalSpacer_47, 0, 12, 1, 1);

        horizontalSpacer_48 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_27->addItem(horizontalSpacer_48, 0, 18, 1, 1);

        horizontalSpacer_49 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_27->addItem(horizontalSpacer_49, 0, 8, 1, 1);

        estop_4 = new QLabel(groupBox_7);
        estop_4->setObjectName(QString::fromUtf8("estop_4"));
        estop_4->setMinimumSize(QSize(20, 26));
        estop_4->setMaximumSize(QSize(20, 26));
        estop_4->setFont(font);
        estop_4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        estop_4->setAlignment(Qt::AlignCenter);

        gridLayout_27->addWidget(estop_4, 0, 9, 1, 1);

        estop_6 = new QLabel(groupBox_7);
        estop_6->setObjectName(QString::fromUtf8("estop_6"));
        estop_6->setMinimumSize(QSize(20, 26));
        estop_6->setMaximumSize(QSize(20, 26));
        estop_6->setFont(font);
        estop_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));
        estop_6->setAlignment(Qt::AlignCenter);

        gridLayout_27->addWidget(estop_6, 0, 13, 1, 1);

        horizontalSpacer_50 = new QSpacerItem(19, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_27->addItem(horizontalSpacer_50, 0, 1, 1, 1);


        gridLayout->addWidget(groupBox_7, 1, 0, 1, 3);

        groupBox = new QGroupBox(dialog_systic);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setMaximumSize(QSize(16777215, 280));
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        palette.setBrush(QPalette::Active, QPalette::Window, brush);
        QBrush brush1(QColor(255, 0, 0, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Highlight, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Highlight, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush);
        QBrush brush2(QColor(0, 0, 128, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::Highlight, brush2);
        groupBox->setPalette(palette);
        groupBox->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
""));
        gridLayout_22 = new QGridLayout(groupBox);
        gridLayout_22->setObjectName(QString::fromUtf8("gridLayout_22"));
        actv_dcb6 = new QLabel(groupBox);
        actv_dcb6->setObjectName(QString::fromUtf8("actv_dcb6"));
        actv_dcb6->setMinimumSize(QSize(65, 16));
        actv_dcb6->setMaximumSize(QSize(65, 20));
        actv_dcb6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(actv_dcb6, 6, 4, 1, 1);

        label_157 = new QLabel(groupBox);
        label_157->setObjectName(QString::fromUtf8("label_157"));
        label_157->setMinimumSize(QSize(20, 20));
        label_157->setMaximumSize(QSize(20, 16777215));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Sans Serif"));
        font2.setPointSize(9);
        font2.setBold(true);
        font2.setItalic(false);
        font2.setWeight(75);
        label_157->setFont(font2);
        label_157->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_157, 7, 0, 1, 1);

        actv_dcb3 = new QLabel(groupBox);
        actv_dcb3->setObjectName(QString::fromUtf8("actv_dcb3"));
        actv_dcb3->setMinimumSize(QSize(65, 16));
        actv_dcb3->setMaximumSize(QSize(65, 20));
        actv_dcb3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(actv_dcb3, 3, 4, 1, 1);

        label_158 = new QLabel(groupBox);
        label_158->setObjectName(QString::fromUtf8("label_158"));
        label_158->setMinimumSize(QSize(20, 20));
        label_158->setMaximumSize(QSize(20, 16777215));
        label_158->setFont(font2);
        label_158->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_158, 4, 0, 1, 1);

        label_159 = new QLabel(groupBox);
        label_159->setObjectName(QString::fromUtf8("label_159"));
        label_159->setMinimumSize(QSize(0, 20));
        label_159->setFont(font2);
        label_159->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_159, 0, 3, 1, 1);

        health_dcb4 = new QLabel(groupBox);
        health_dcb4->setObjectName(QString::fromUtf8("health_dcb4"));
        health_dcb4->setMinimumSize(QSize(65, 16));
        health_dcb4->setMaximumSize(QSize(65, 20));
        health_dcb4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(health_dcb4, 4, 1, 1, 1);

        label_160 = new QLabel(groupBox);
        label_160->setObjectName(QString::fromUtf8("label_160"));
        label_160->setMinimumSize(QSize(20, 20));
        label_160->setMaximumSize(QSize(20, 16777215));
        label_160->setFont(font2);
        label_160->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_160, 3, 0, 1, 1);

        con_dcb3 = new QLabel(groupBox);
        con_dcb3->setObjectName(QString::fromUtf8("con_dcb3"));
        con_dcb3->setMinimumSize(QSize(65, 16));
        con_dcb3->setMaximumSize(QSize(65, 20));
        con_dcb3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(con_dcb3, 3, 3, 1, 1);

        con_dcb7 = new QLabel(groupBox);
        con_dcb7->setObjectName(QString::fromUtf8("con_dcb7"));
        con_dcb7->setMinimumSize(QSize(65, 16));
        con_dcb7->setMaximumSize(QSize(65, 20));
        con_dcb7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(con_dcb7, 7, 3, 1, 1);

        label_161 = new QLabel(groupBox);
        label_161->setObjectName(QString::fromUtf8("label_161"));
        label_161->setMinimumSize(QSize(20, 20));
        label_161->setMaximumSize(QSize(20, 20));
        label_161->setFont(font2);
        label_161->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_161, 6, 0, 1, 1);

        label_162 = new QLabel(groupBox);
        label_162->setObjectName(QString::fromUtf8("label_162"));
        label_162->setMinimumSize(QSize(0, 20));
        label_162->setFont(font2);
        label_162->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_162, 0, 2, 1, 1);

        ready_dcb5 = new QLabel(groupBox);
        ready_dcb5->setObjectName(QString::fromUtf8("ready_dcb5"));
        ready_dcb5->setMinimumSize(QSize(65, 16));
        ready_dcb5->setMaximumSize(QSize(65, 20));
        ready_dcb5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(ready_dcb5, 5, 2, 1, 1);

        actv_dcb7 = new QLabel(groupBox);
        actv_dcb7->setObjectName(QString::fromUtf8("actv_dcb7"));
        actv_dcb7->setMinimumSize(QSize(65, 16));
        actv_dcb7->setMaximumSize(QSize(65, 20));
        actv_dcb7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(actv_dcb7, 7, 4, 1, 1);

        con_dcb6 = new QLabel(groupBox);
        con_dcb6->setObjectName(QString::fromUtf8("con_dcb6"));
        con_dcb6->setMinimumSize(QSize(65, 16));
        con_dcb6->setMaximumSize(QSize(65, 20));
        con_dcb6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(con_dcb6, 6, 3, 1, 1);

        actv_dcb1 = new QLabel(groupBox);
        actv_dcb1->setObjectName(QString::fromUtf8("actv_dcb1"));
        actv_dcb1->setMinimumSize(QSize(65, 16));
        actv_dcb1->setMaximumSize(QSize(65, 20));
        actv_dcb1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(actv_dcb1, 1, 4, 1, 1);

        con_dcb2 = new QLabel(groupBox);
        con_dcb2->setObjectName(QString::fromUtf8("con_dcb2"));
        con_dcb2->setMinimumSize(QSize(65, 16));
        con_dcb2->setMaximumSize(QSize(65, 20));
        con_dcb2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(con_dcb2, 2, 3, 1, 1);

        label_163 = new QLabel(groupBox);
        label_163->setObjectName(QString::fromUtf8("label_163"));
        label_163->setMinimumSize(QSize(20, 20));
        label_163->setMaximumSize(QSize(20, 16777215));
        label_163->setFont(font2);
        label_163->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_163, 2, 0, 1, 1);

        actv_dcb4 = new QLabel(groupBox);
        actv_dcb4->setObjectName(QString::fromUtf8("actv_dcb4"));
        actv_dcb4->setMinimumSize(QSize(65, 16));
        actv_dcb4->setMaximumSize(QSize(65, 20));
        actv_dcb4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(actv_dcb4, 4, 4, 1, 1);

        ready_dcb4 = new QLabel(groupBox);
        ready_dcb4->setObjectName(QString::fromUtf8("ready_dcb4"));
        ready_dcb4->setMinimumSize(QSize(65, 16));
        ready_dcb4->setMaximumSize(QSize(65, 20));
        ready_dcb4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(ready_dcb4, 4, 2, 1, 1);

        ready_dcb2 = new QLabel(groupBox);
        ready_dcb2->setObjectName(QString::fromUtf8("ready_dcb2"));
        ready_dcb2->setMinimumSize(QSize(65, 16));
        ready_dcb2->setMaximumSize(QSize(65, 20));
        ready_dcb2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(ready_dcb2, 2, 2, 1, 1);

        con_dcb5 = new QLabel(groupBox);
        con_dcb5->setObjectName(QString::fromUtf8("con_dcb5"));
        con_dcb5->setMinimumSize(QSize(65, 16));
        con_dcb5->setMaximumSize(QSize(65, 20));
        con_dcb5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(con_dcb5, 5, 3, 1, 1);

        label_164 = new QLabel(groupBox);
        label_164->setObjectName(QString::fromUtf8("label_164"));
        label_164->setMinimumSize(QSize(20, 20));
        label_164->setMaximumSize(QSize(20, 16777215));
        label_164->setFont(font2);
        label_164->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_164, 5, 0, 1, 1);

        con_dcb4 = new QLabel(groupBox);
        con_dcb4->setObjectName(QString::fromUtf8("con_dcb4"));
        con_dcb4->setMinimumSize(QSize(65, 16));
        con_dcb4->setMaximumSize(QSize(65, 20));
        con_dcb4->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(con_dcb4, 4, 3, 1, 1);

        actv_dcb5 = new QLabel(groupBox);
        actv_dcb5->setObjectName(QString::fromUtf8("actv_dcb5"));
        actv_dcb5->setMinimumSize(QSize(65, 16));
        actv_dcb5->setMaximumSize(QSize(65, 20));
        actv_dcb5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(actv_dcb5, 5, 4, 1, 1);

        health_dcb1 = new QLabel(groupBox);
        health_dcb1->setObjectName(QString::fromUtf8("health_dcb1"));
        health_dcb1->setMinimumSize(QSize(65, 16));
        health_dcb1->setMaximumSize(QSize(65, 20));
        health_dcb1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(health_dcb1, 1, 1, 1, 1);

        health_dcb7 = new QLabel(groupBox);
        health_dcb7->setObjectName(QString::fromUtf8("health_dcb7"));
        health_dcb7->setMinimumSize(QSize(65, 16));
        health_dcb7->setMaximumSize(QSize(65, 20));
        health_dcb7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(health_dcb7, 7, 1, 1, 1);

        health_dcb2 = new QLabel(groupBox);
        health_dcb2->setObjectName(QString::fromUtf8("health_dcb2"));
        health_dcb2->setMinimumSize(QSize(65, 16));
        health_dcb2->setMaximumSize(QSize(65, 20));
        health_dcb2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(health_dcb2, 2, 1, 1, 1);

        health_dcb3 = new QLabel(groupBox);
        health_dcb3->setObjectName(QString::fromUtf8("health_dcb3"));
        health_dcb3->setMinimumSize(QSize(65, 16));
        health_dcb3->setMaximumSize(QSize(65, 20));
        health_dcb3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(health_dcb3, 3, 1, 1, 1);

        con_dcb1 = new QLabel(groupBox);
        con_dcb1->setObjectName(QString::fromUtf8("con_dcb1"));
        con_dcb1->setMinimumSize(QSize(65, 16));
        con_dcb1->setMaximumSize(QSize(65, 20));
        con_dcb1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(con_dcb1, 1, 3, 1, 1);

        ready_dcb3 = new QLabel(groupBox);
        ready_dcb3->setObjectName(QString::fromUtf8("ready_dcb3"));
        ready_dcb3->setMinimumSize(QSize(65, 16));
        ready_dcb3->setMaximumSize(QSize(65, 20));
        ready_dcb3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(ready_dcb3, 3, 2, 1, 1);

        ready_dcb1 = new QLabel(groupBox);
        ready_dcb1->setObjectName(QString::fromUtf8("ready_dcb1"));
        ready_dcb1->setMinimumSize(QSize(65, 16));
        ready_dcb1->setMaximumSize(QSize(65, 20));
        ready_dcb1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(ready_dcb1, 1, 2, 1, 1);

        health_dcb6 = new QLabel(groupBox);
        health_dcb6->setObjectName(QString::fromUtf8("health_dcb6"));
        health_dcb6->setMinimumSize(QSize(65, 16));
        health_dcb6->setMaximumSize(QSize(65, 20));
        health_dcb6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(health_dcb6, 6, 1, 1, 1);

        ready_dcb7 = new QLabel(groupBox);
        ready_dcb7->setObjectName(QString::fromUtf8("ready_dcb7"));
        ready_dcb7->setMinimumSize(QSize(65, 16));
        ready_dcb7->setMaximumSize(QSize(65, 20));
        ready_dcb7->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(ready_dcb7, 7, 2, 1, 1);

        label_165 = new QLabel(groupBox);
        label_165->setObjectName(QString::fromUtf8("label_165"));
        label_165->setMinimumSize(QSize(0, 20));
        label_165->setMaximumSize(QSize(300, 16777215));
        label_165->setFont(font2);
        label_165->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_165, 0, 1, 1, 1);

        label_166 = new QLabel(groupBox);
        label_166->setObjectName(QString::fromUtf8("label_166"));
        label_166->setMinimumSize(QSize(20, 20));
        label_166->setMaximumSize(QSize(20, 16777215));
        label_166->setFont(font2);
        label_166->setStyleSheet(QString::fromUtf8(""));
        label_166->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_166, 1, 0, 1, 1);

        actv_dcb2 = new QLabel(groupBox);
        actv_dcb2->setObjectName(QString::fromUtf8("actv_dcb2"));
        actv_dcb2->setMinimumSize(QSize(65, 16));
        actv_dcb2->setMaximumSize(QSize(65, 20));
        actv_dcb2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(actv_dcb2, 2, 4, 1, 1);

        ready_dcb6 = new QLabel(groupBox);
        ready_dcb6->setObjectName(QString::fromUtf8("ready_dcb6"));
        ready_dcb6->setMinimumSize(QSize(65, 16));
        ready_dcb6->setMaximumSize(QSize(65, 20));
        ready_dcb6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(ready_dcb6, 6, 2, 1, 1);

        health_dcb5 = new QLabel(groupBox);
        health_dcb5->setObjectName(QString::fromUtf8("health_dcb5"));
        health_dcb5->setMinimumSize(QSize(65, 16));
        health_dcb5->setMaximumSize(QSize(65, 20));
        health_dcb5->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_22->addWidget(health_dcb5, 5, 1, 1, 1);

        label_167 = new QLabel(groupBox);
        label_167->setObjectName(QString::fromUtf8("label_167"));
        label_167->setMinimumSize(QSize(0, 20));
        label_167->setFont(font2);
        label_167->setAlignment(Qt::AlignCenter);

        gridLayout_22->addWidget(label_167, 0, 4, 1, 1);

        verticalSpacer_7 = new QSpacerItem(20, 8, QSizePolicy::Minimum, QSizePolicy::Maximum);

        gridLayout_22->addItem(verticalSpacer_7, 8, 1, 1, 4);


        gridLayout->addWidget(groupBox, 2, 0, 1, 3);

        groupBox_2 = new QGroupBox(dialog_systic);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setMaximumSize(QSize(16777215, 150));
        groupBox_2->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";"));
        gridLayout_20 = new QGridLayout(groupBox_2);
        gridLayout_20->setObjectName(QString::fromUtf8("gridLayout_20"));
        con_hvps2 = new QLabel(groupBox_2);
        con_hvps2->setObjectName(QString::fromUtf8("con_hvps2"));
        con_hvps2->setMinimumSize(QSize(65, 16));
        con_hvps2->setMaximumSize(QSize(65, 20));
        con_hvps2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(con_hvps2, 2, 3, 1, 1);

        label_150 = new QLabel(groupBox_2);
        label_150->setObjectName(QString::fromUtf8("label_150"));
        label_150->setMinimumSize(QSize(20, 20));
        label_150->setMaximumSize(QSize(20, 20));
        label_150->setFont(font2);
        label_150->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_150, 1, 0, 1, 1);

        hlt_hvps2 = new QLabel(groupBox_2);
        hlt_hvps2->setObjectName(QString::fromUtf8("hlt_hvps2"));
        hlt_hvps2->setMinimumSize(QSize(65, 16));
        hlt_hvps2->setMaximumSize(QSize(65, 20));
        hlt_hvps2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(hlt_hvps2, 2, 1, 1, 1);

        hlt_hvps1 = new QLabel(groupBox_2);
        hlt_hvps1->setObjectName(QString::fromUtf8("hlt_hvps1"));
        hlt_hvps1->setMinimumSize(QSize(65, 16));
        hlt_hvps1->setMaximumSize(QSize(65, 20));
        hlt_hvps1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(hlt_hvps1, 1, 1, 1, 1);

        label_151 = new QLabel(groupBox_2);
        label_151->setObjectName(QString::fromUtf8("label_151"));
        label_151->setMinimumSize(QSize(20, 20));
        label_151->setMaximumSize(QSize(20, 20));
        label_151->setFont(font2);
        label_151->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_151, 3, 0, 1, 1);

        label_152 = new QLabel(groupBox_2);
        label_152->setObjectName(QString::fromUtf8("label_152"));
        label_152->setFont(font2);
        label_152->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_152, 0, 4, 1, 1);

        actv_hvps1 = new QLabel(groupBox_2);
        actv_hvps1->setObjectName(QString::fromUtf8("actv_hvps1"));
        actv_hvps1->setMinimumSize(QSize(65, 16));
        actv_hvps1->setMaximumSize(QSize(65, 20));
        actv_hvps1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(actv_hvps1, 1, 4, 1, 1);

        hlt_hvps3 = new QLabel(groupBox_2);
        hlt_hvps3->setObjectName(QString::fromUtf8("hlt_hvps3"));
        hlt_hvps3->setMinimumSize(QSize(65, 16));
        hlt_hvps3->setMaximumSize(QSize(65, 20));
        hlt_hvps3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(hlt_hvps3, 3, 1, 1, 1);

        rdy_hvps2 = new QLabel(groupBox_2);
        rdy_hvps2->setObjectName(QString::fromUtf8("rdy_hvps2"));
        rdy_hvps2->setMinimumSize(QSize(65, 16));
        rdy_hvps2->setMaximumSize(QSize(65, 20));
        rdy_hvps2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(rdy_hvps2, 2, 2, 1, 1);

        con_hvps1 = new QLabel(groupBox_2);
        con_hvps1->setObjectName(QString::fromUtf8("con_hvps1"));
        con_hvps1->setMinimumSize(QSize(65, 16));
        con_hvps1->setMaximumSize(QSize(65, 20));
        con_hvps1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(con_hvps1, 1, 3, 1, 1);

        verticalSpacer_6 = new QSpacerItem(20, 15, QSizePolicy::Minimum, QSizePolicy::Maximum);

        gridLayout_20->addItem(verticalSpacer_6, 4, 1, 1, 4);

        label_153 = new QLabel(groupBox_2);
        label_153->setObjectName(QString::fromUtf8("label_153"));
        label_153->setMaximumSize(QSize(300, 16777215));
        label_153->setFont(font2);
        label_153->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_153, 0, 1, 1, 1);

        label_154 = new QLabel(groupBox_2);
        label_154->setObjectName(QString::fromUtf8("label_154"));
        label_154->setFont(font2);
        label_154->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_154, 0, 3, 1, 1);

        label_155 = new QLabel(groupBox_2);
        label_155->setObjectName(QString::fromUtf8("label_155"));
        label_155->setFont(font2);
        label_155->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_155, 0, 2, 1, 1);

        actv_hvps3 = new QLabel(groupBox_2);
        actv_hvps3->setObjectName(QString::fromUtf8("actv_hvps3"));
        actv_hvps3->setMinimumSize(QSize(65, 16));
        actv_hvps3->setMaximumSize(QSize(65, 20));
        actv_hvps3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(actv_hvps3, 3, 4, 1, 1);

        con_hvps3 = new QLabel(groupBox_2);
        con_hvps3->setObjectName(QString::fromUtf8("con_hvps3"));
        con_hvps3->setMinimumSize(QSize(65, 16));
        con_hvps3->setMaximumSize(QSize(65, 20));
        con_hvps3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(con_hvps3, 3, 3, 1, 1);

        rdy_hvps3 = new QLabel(groupBox_2);
        rdy_hvps3->setObjectName(QString::fromUtf8("rdy_hvps3"));
        rdy_hvps3->setMinimumSize(QSize(65, 16));
        rdy_hvps3->setMaximumSize(QSize(65, 20));
        rdy_hvps3->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(rdy_hvps3, 3, 2, 1, 1);

        rdy_hvps1 = new QLabel(groupBox_2);
        rdy_hvps1->setObjectName(QString::fromUtf8("rdy_hvps1"));
        rdy_hvps1->setMinimumSize(QSize(65, 16));
        rdy_hvps1->setMaximumSize(QSize(65, 20));
        rdy_hvps1->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(rdy_hvps1, 1, 2, 1, 1);

        actv_hvps2 = new QLabel(groupBox_2);
        actv_hvps2->setObjectName(QString::fromUtf8("actv_hvps2"));
        actv_hvps2->setMinimumSize(QSize(65, 16));
        actv_hvps2->setMaximumSize(QSize(65, 20));
        actv_hvps2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"margin-left: 25px;\n"
"margin-right: 25px;\n"
"border-radius: 7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_20->addWidget(actv_hvps2, 2, 4, 1, 1);

        label_156 = new QLabel(groupBox_2);
        label_156->setObjectName(QString::fromUtf8("label_156"));
        label_156->setMinimumSize(QSize(20, 20));
        label_156->setMaximumSize(QSize(20, 20));
        label_156->setFont(font2);
        label_156->setAlignment(Qt::AlignCenter);

        gridLayout_20->addWidget(label_156, 2, 0, 1, 1);


        gridLayout->addWidget(groupBox_2, 3, 0, 1, 3);

        widget_2 = new QWidget(dialog_systic);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setMaximumSize(QSize(16777215, 50));
        gridLayout_16 = new QGridLayout(widget_2);
        gridLayout_16->setObjectName(QString::fromUtf8("gridLayout_16"));
        systic_temp_value = new QLabel(widget_2);
        systic_temp_value->setObjectName(QString::fromUtf8("systic_temp_value"));
        systic_temp_value->setMinimumSize(QSize(0, 18));
        systic_temp_value->setMaximumSize(QSize(16777215, 18));
        systic_temp_value->setFont(font);
        systic_temp_value->setStyleSheet(QString::fromUtf8("border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        systic_temp_value->setAlignment(Qt::AlignCenter);

        gridLayout_16->addWidget(systic_temp_value, 0, 1, 1, 1);

        label_temp_5 = new QLabel(widget_2);
        label_temp_5->setObjectName(QString::fromUtf8("label_temp_5"));
        label_temp_5->setFont(font);

        gridLayout_16->addWidget(label_temp_5, 0, 0, 1, 1);


        gridLayout->addWidget(widget_2, 5, 0, 1, 3);

        groupBox_5 = new QGroupBox(dialog_systic);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(125);
        sizePolicy1.setVerticalStretch(100);
        sizePolicy1.setHeightForWidth(groupBox_5->sizePolicy().hasHeightForWidth());
        groupBox_5->setSizePolicy(sizePolicy1);
        groupBox_5->setMaximumSize(QSize(86, 225));
        groupBox_5->setFont(font);
        groupBox_5->setAlignment(Qt::AlignCenter);
        gridLayout_19 = new QGridLayout(groupBox_5);
        gridLayout_19->setObjectName(QString::fromUtf8("gridLayout_19"));
        systic_ent_ph = new QLabel(groupBox_5);
        systic_ent_ph->setObjectName(QString::fromUtf8("systic_ent_ph"));
        systic_ent_ph->setMaximumSize(QSize(20, 26));
        systic_ent_ph->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(systic_ent_ph, 0, 0, 1, 1);

        systic_ent_ph2 = new QLabel(groupBox_5);
        systic_ent_ph2->setObjectName(QString::fromUtf8("systic_ent_ph2"));
        systic_ent_ph2->setMaximumSize(QSize(20, 26));
        systic_ent_ph2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 3px;\n"
"margin-bottom: 3px;\n"
"border-radius: 10px;\n"
"min-height: 20px;\n"
"min-width: 20px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_19->addWidget(systic_ent_ph2, 1, 0, 1, 1);


        gridLayout->addWidget(groupBox_5, 4, 0, 1, 1);

        widget = new QWidget(dialog_systic);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setMaximumSize(QSize(16777215, 50));
        gridLayout_17 = new QGridLayout(widget);
        gridLayout_17->setObjectName(QString::fromUtf8("gridLayout_17"));
        label_temp_6 = new QLabel(widget);
        label_temp_6->setObjectName(QString::fromUtf8("label_temp_6"));
        label_temp_6->setFont(font);

        gridLayout_17->addWidget(label_temp_6, 0, 0, 1, 1);

        sdb_temp_value = new QLabel(widget);
        sdb_temp_value->setObjectName(QString::fromUtf8("sdb_temp_value"));
        sdb_temp_value->setMinimumSize(QSize(0, 18));
        sdb_temp_value->setMaximumSize(QSize(16777215, 18));
        sdb_temp_value->setFont(font);
        sdb_temp_value->setStyleSheet(QString::fromUtf8("border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        sdb_temp_value->setAlignment(Qt::AlignCenter);

        gridLayout_17->addWidget(sdb_temp_value, 0, 1, 1, 1);


        gridLayout->addWidget(widget, 6, 0, 1, 3);

        tabWidget = new QTabWidget(dialog_systic);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setFocusPolicy(Qt::NoFocus);
        tabWidget->setStyleSheet(QString::fromUtf8("QTabBar::tab:!selected	{\n"
"	font: 75 9pt \"Sans Serif\";\n"
"	background-color: rgb(193, 193, 193);\n"
"	border-top-left-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	margin-left: px;\n"
"	margin-right: px;\n"
"	border: 1px solid black;\n"
"	border-bottom-color: black;\n"
"	min-width: 8ex;\n"
"}\n"
"QTabBar::tab:selected	{\n"
"	background-color: rgb(255, 255, 255);\n"
"	font: 75  9pt \"Sans Serif\";\n"
"	border-top-left-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	margin-left: px;\n"
"	margin-right: px;\n"
"	border: 1px solid black;\n"
"	border-bottom-color: rgb(255, 255, 255);\n"
"	min-width: 8ex;\n"
"}\n"
"QTabWidget::pane	{\n"
"	border: 1px solid black\n"
"}"));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        gridLayout_2 = new QGridLayout(tab);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        groupBox_3 = new QGroupBox(tab);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";"));
        gridLayout_3 = new QGridLayout(groupBox_3);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label = new QLabel(groupBox_3);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(63, 0));
        label->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_3->addWidget(label, 0, 0, 1, 1);

        ups1_input_freq = new QLabel(groupBox_3);
        ups1_input_freq->setObjectName(QString::fromUtf8("ups1_input_freq"));
        QFont font3;
        font3.setFamily(QString::fromUtf8("Sans Serif"));
        font3.setPointSize(9);
        font3.setBold(false);
        font3.setItalic(false);
        font3.setWeight(50);
        ups1_input_freq->setFont(font3);
        ups1_input_freq->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups1_input_freq->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(ups1_input_freq, 0, 1, 1, 1);

        label_3 = new QLabel(groupBox_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMinimumSize(QSize(63, 0));
        label_3->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_3->addWidget(label_3, 1, 0, 1, 1);

        ups1_input_vol = new QLabel(groupBox_3);
        ups1_input_vol->setObjectName(QString::fromUtf8("ups1_input_vol"));
        ups1_input_vol->setFont(font3);
        ups1_input_vol->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups1_input_vol->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(ups1_input_vol, 1, 1, 1, 1);


        gridLayout_2->addWidget(groupBox_3, 1, 0, 1, 1);

        groupBox_8 = new QGroupBox(tab);
        groupBox_8->setObjectName(QString::fromUtf8("groupBox_8"));
        groupBox_8->setFont(font);
        gridLayout_5 = new QGridLayout(groupBox_8);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        label_7 = new QLabel(groupBox_8);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_5->addWidget(label_7, 0, 0, 1, 1);

        ups1_status = new QLabel(groupBox_8);
        ups1_status->setObjectName(QString::fromUtf8("ups1_status"));
        ups1_status->setMinimumSize(QSize(0, 23));
        ups1_status->setFont(font3);
        ups1_status->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups1_status->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(ups1_status, 0, 1, 1, 1);

        label_9 = new QLabel(groupBox_8);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_5->addWidget(label_9, 1, 0, 1, 1);

        ups1_temp = new QLabel(groupBox_8);
        ups1_temp->setObjectName(QString::fromUtf8("ups1_temp"));
        ups1_temp->setMinimumSize(QSize(0, 24));
        ups1_temp->setFont(font3);
        ups1_temp->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups1_temp->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(ups1_temp, 1, 1, 1, 1);

        label_11 = new QLabel(groupBox_8);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_5->addWidget(label_11, 2, 0, 1, 1);

        ups1_load = new QLabel(groupBox_8);
        ups1_load->setObjectName(QString::fromUtf8("ups1_load"));
        ups1_load->setMinimumSize(QSize(0, 24));
        ups1_load->setFont(font3);
        ups1_load->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups1_load->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(ups1_load, 2, 1, 1, 1);

        label_13 = new QLabel(groupBox_8);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_5->addWidget(label_13, 3, 0, 1, 1);

        ups1_charge = new QLabel(groupBox_8);
        ups1_charge->setObjectName(QString::fromUtf8("ups1_charge"));
        ups1_charge->setMinimumSize(QSize(0, 24));
        ups1_charge->setFont(font3);
        ups1_charge->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups1_charge->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(ups1_charge, 3, 1, 1, 1);


        gridLayout_2->addWidget(groupBox_8, 1, 1, 2, 1);

        groupBox_9 = new QGroupBox(tab);
        groupBox_9->setObjectName(QString::fromUtf8("groupBox_9"));
        groupBox_9->setMaximumSize(QSize(16777215, 60));
        groupBox_9->setFont(font);
        gridLayout_4 = new QGridLayout(groupBox_9);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        label_5 = new QLabel(groupBox_9);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setMinimumSize(QSize(63, 0));
        label_5->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;"));

        gridLayout_4->addWidget(label_5, 0, 0, 1, 1);

        ups1_output_vol = new QLabel(groupBox_9);
        ups1_output_vol->setObjectName(QString::fromUtf8("ups1_output_vol"));
        ups1_output_vol->setFont(font3);
        ups1_output_vol->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups1_output_vol->setAlignment(Qt::AlignCenter);

        gridLayout_4->addWidget(ups1_output_vol, 0, 1, 1, 1);


        gridLayout_2->addWidget(groupBox_9, 2, 0, 1, 1);

        label_15 = new QLabel(tab);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setMaximumSize(QSize(16777215, 15));
        label_15->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_15, 0, 0, 1, 1);

        ups1_model = new QLabel(tab);
        ups1_model->setObjectName(QString::fromUtf8("ups1_model"));
        ups1_model->setMaximumSize(QSize(16777215, 15));
        ups1_model->setFont(font);
        ups1_model->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(ups1_model, 0, 1, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        gridLayout_9 = new QGridLayout(tab_2);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        label_16 = new QLabel(tab_2);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setMaximumSize(QSize(16777215, 15));
        label_16->setAlignment(Qt::AlignCenter);

        gridLayout_9->addWidget(label_16, 0, 0, 1, 1);

        ups2_model = new QLabel(tab_2);
        ups2_model->setObjectName(QString::fromUtf8("ups2_model"));
        ups2_model->setEnabled(true);
        ups2_model->setMaximumSize(QSize(16777215, 15));
        ups2_model->setFont(font);
        ups2_model->setAlignment(Qt::AlignCenter);

        gridLayout_9->addWidget(ups2_model, 0, 1, 1, 1);

        groupBox_11 = new QGroupBox(tab_2);
        groupBox_11->setObjectName(QString::fromUtf8("groupBox_11"));
        groupBox_11->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";"));
        gridLayout_7 = new QGridLayout(groupBox_11);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        label_2 = new QLabel(groupBox_11);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(63, 0));
        label_2->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_7->addWidget(label_2, 0, 0, 1, 1);

        ups2_input_freq = new QLabel(groupBox_11);
        ups2_input_freq->setObjectName(QString::fromUtf8("ups2_input_freq"));
        ups2_input_freq->setFont(font3);
        ups2_input_freq->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups2_input_freq->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(ups2_input_freq, 0, 1, 1, 1);

        label_4 = new QLabel(groupBox_11);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMinimumSize(QSize(63, 0));
        label_4->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_7->addWidget(label_4, 1, 0, 1, 1);

        ups2_input_vol = new QLabel(groupBox_11);
        ups2_input_vol->setObjectName(QString::fromUtf8("ups2_input_vol"));
        ups2_input_vol->setFont(font3);
        ups2_input_vol->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups2_input_vol->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(ups2_input_vol, 1, 1, 1, 1);


        gridLayout_9->addWidget(groupBox_11, 1, 0, 1, 1);

        groupBox_10 = new QGroupBox(tab_2);
        groupBox_10->setObjectName(QString::fromUtf8("groupBox_10"));
        groupBox_10->setFont(font);
        gridLayout_6 = new QGridLayout(groupBox_10);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        label_8 = new QLabel(groupBox_10);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_6->addWidget(label_8, 0, 0, 1, 1);

        ups2_status = new QLabel(groupBox_10);
        ups2_status->setObjectName(QString::fromUtf8("ups2_status"));
        ups2_status->setFont(font3);
        ups2_status->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups2_status->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(ups2_status, 0, 1, 1, 1);

        label_10 = new QLabel(groupBox_10);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_6->addWidget(label_10, 1, 0, 1, 1);

        ups2_temp = new QLabel(groupBox_10);
        ups2_temp->setObjectName(QString::fromUtf8("ups2_temp"));
        ups2_temp->setFont(font3);
        ups2_temp->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups2_temp->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(ups2_temp, 1, 1, 1, 1);

        label_12 = new QLabel(groupBox_10);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_6->addWidget(label_12, 2, 0, 1, 1);

        ups2_load = new QLabel(groupBox_10);
        ups2_load->setObjectName(QString::fromUtf8("ups2_load"));
        ups2_load->setFont(font3);
        ups2_load->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups2_load->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(ups2_load, 2, 1, 1, 1);

        label_14 = new QLabel(groupBox_10);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_6->addWidget(label_14, 3, 0, 1, 1);

        ups2_charge = new QLabel(groupBox_10);
        ups2_charge->setObjectName(QString::fromUtf8("ups2_charge"));
        ups2_charge->setFont(font3);
        ups2_charge->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups2_charge->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(ups2_charge, 3, 1, 1, 1);


        gridLayout_9->addWidget(groupBox_10, 1, 1, 2, 1);

        groupBox_12 = new QGroupBox(tab_2);
        groupBox_12->setObjectName(QString::fromUtf8("groupBox_12"));
        groupBox_12->setMaximumSize(QSize(16777215, 60));
        groupBox_12->setFont(font);
        gridLayout_8 = new QGridLayout(groupBox_12);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        label_6 = new QLabel(groupBox_12);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setMinimumSize(QSize(63, 0));
        label_6->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;"));

        gridLayout_8->addWidget(label_6, 0, 0, 1, 1);

        ups2_output_vol = new QLabel(groupBox_12);
        ups2_output_vol->setObjectName(QString::fromUtf8("ups2_output_vol"));
        ups2_output_vol->setFont(font3);
        ups2_output_vol->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"border-radius: 3px;\n"
"background-color: rgb(175, 175, 175);"));
        ups2_output_vol->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(ups2_output_vol, 0, 1, 1, 1);


        gridLayout_9->addWidget(groupBox_12, 2, 0, 1, 1);

        tabWidget->addTab(tab_2, QString());

        gridLayout->addWidget(tabWidget, 4, 1, 1, 1);


        retranslateUi(dialog_systic);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(dialog_systic);
    } // setupUi

    void retranslateUi(QDialog *dialog_systic)
    {
        dialog_systic->setWindowTitle(QApplication::translate("dialog_systic", "SDB & SYSTIC BOARD", 0, QApplication::UnicodeUTF8));
        groupBox_6->setTitle(QApplication::translate("dialog_systic", "INTERLOCK", 0, QApplication::UnicodeUTF8));
        interlock_6->setText(QApplication::translate("dialog_systic", "6", 0, QApplication::UnicodeUTF8));
        interlock_3->setText(QApplication::translate("dialog_systic", "3", 0, QApplication::UnicodeUTF8));
        interlock_2->setText(QApplication::translate("dialog_systic", "2", 0, QApplication::UnicodeUTF8));
        interlock_5->setText(QApplication::translate("dialog_systic", "5", 0, QApplication::UnicodeUTF8));
        interlock_1->setText(QApplication::translate("dialog_systic", "1", 0, QApplication::UnicodeUTF8));
        interlock_4->setText(QApplication::translate("dialog_systic", "4", 0, QApplication::UnicodeUTF8));
        groupBox_4->setTitle(QString());
        systic_highBlock->setText(QString());
        systic_highBlock_2->setText(QString());
        systic_highBlock_3->setText(QString());
        systic_highBlock_4->setText(QString());
        systic_highBlock_5->setText(QString());
        systic_highBlock_6->setText(QString());
        systic_highBlock_7->setText(QString());
        systic_highBlock_8->setText(QString());
        systic_highBlock_9->setText(QString());
        systic_highBlock_10->setText(QString());
        systic_highBlock_11->setText(QString());
        systic_highBlock_12->setText(QString());
        systic_highBlock_13->setText(QString());
        systic_highBlock_14->setText(QString());
        systic_highBlock_15->setText(QString());
        systic_highBlock_16->setText(QString());
        systic_lowBlock->setText(QString());
        systic_lowBlock_2->setText(QString());
        systic_lowBlock_3->setText(QString());
        systic_lowBlock_4->setText(QString());
        systic_lowBlock_5->setText(QString());
        systic_lowBlock_6->setText(QString());
        systic_lowBlock_7->setText(QString());
        systic_lowBlock_8->setText(QString());
        systic_lowBlock_9->setText(QString());
        systic_lowBlock_10->setText(QString());
        systic_lowBlock_11->setText(QString());
        systic_lowBlock_12->setText(QString());
        systic_lowBlock_13->setText(QString());
        systic_lowBlock_14->setText(QString());
        systic_lowBlock_15->setText(QString());
        systic_lowBlock_16->setText(QString());
        groupBox_7->setTitle(QApplication::translate("dialog_systic", "E-STOP", 0, QApplication::UnicodeUTF8));
        estop_8->setText(QApplication::translate("dialog_systic", "8", 0, QApplication::UnicodeUTF8));
        estop_1->setText(QApplication::translate("dialog_systic", "1", 0, QApplication::UnicodeUTF8));
        estop_5->setText(QApplication::translate("dialog_systic", "5", 0, QApplication::UnicodeUTF8));
        estop_7->setText(QApplication::translate("dialog_systic", "7", 0, QApplication::UnicodeUTF8));
        estop_2->setText(QApplication::translate("dialog_systic", "2", 0, QApplication::UnicodeUTF8));
        estop_3->setText(QApplication::translate("dialog_systic", "3", 0, QApplication::UnicodeUTF8));
        estop_4->setText(QApplication::translate("dialog_systic", "4", 0, QApplication::UnicodeUTF8));
        estop_6->setText(QApplication::translate("dialog_systic", "6", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("dialog_systic", "Data Combiner Board", 0, QApplication::UnicodeUTF8));
        actv_dcb6->setText(QString());
        label_157->setText(QApplication::translate("dialog_systic", "7", 0, QApplication::UnicodeUTF8));
        actv_dcb3->setText(QString());
        label_158->setText(QApplication::translate("dialog_systic", "4", 0, QApplication::UnicodeUTF8));
        label_159->setText(QApplication::translate("dialog_systic", "Connected", 0, QApplication::UnicodeUTF8));
        health_dcb4->setText(QString());
        label_160->setText(QApplication::translate("dialog_systic", "3", 0, QApplication::UnicodeUTF8));
        con_dcb3->setText(QString());
        con_dcb7->setText(QString());
        label_161->setText(QApplication::translate("dialog_systic", "6", 0, QApplication::UnicodeUTF8));
        label_162->setText(QApplication::translate("dialog_systic", "Ready", 0, QApplication::UnicodeUTF8));
        ready_dcb5->setText(QString());
        actv_dcb7->setText(QString());
        con_dcb6->setText(QString());
        actv_dcb1->setText(QString());
        con_dcb2->setText(QString());
        label_163->setText(QApplication::translate("dialog_systic", "2", 0, QApplication::UnicodeUTF8));
        actv_dcb4->setText(QString());
        ready_dcb4->setText(QString());
        ready_dcb2->setText(QString());
        con_dcb5->setText(QString());
        label_164->setText(QApplication::translate("dialog_systic", "5", 0, QApplication::UnicodeUTF8));
        con_dcb4->setText(QString());
        actv_dcb5->setText(QString());
        health_dcb1->setText(QString());
        health_dcb7->setText(QString());
        health_dcb2->setText(QString());
        health_dcb3->setText(QString());
        con_dcb1->setText(QString());
        ready_dcb3->setText(QString());
        ready_dcb1->setText(QString());
        health_dcb6->setText(QString());
        ready_dcb7->setText(QString());
        label_165->setText(QApplication::translate("dialog_systic", "Healthy", 0, QApplication::UnicodeUTF8));
        label_166->setText(QApplication::translate("dialog_systic", "1", 0, QApplication::UnicodeUTF8));
        actv_dcb2->setText(QString());
        ready_dcb6->setText(QString());
        health_dcb5->setText(QString());
        label_167->setText(QApplication::translate("dialog_systic", "Active", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("dialog_systic", "HVPS", 0, QApplication::UnicodeUTF8));
        con_hvps2->setText(QString());
        label_150->setText(QApplication::translate("dialog_systic", "1", 0, QApplication::UnicodeUTF8));
        hlt_hvps2->setText(QString());
        hlt_hvps1->setText(QString());
        label_151->setText(QApplication::translate("dialog_systic", "3", 0, QApplication::UnicodeUTF8));
        label_152->setText(QApplication::translate("dialog_systic", "Active", 0, QApplication::UnicodeUTF8));
        actv_hvps1->setText(QString());
        hlt_hvps3->setText(QString());
        rdy_hvps2->setText(QString());
        con_hvps1->setText(QString());
        label_153->setText(QApplication::translate("dialog_systic", "Healthy", 0, QApplication::UnicodeUTF8));
        label_154->setText(QApplication::translate("dialog_systic", "Connected", 0, QApplication::UnicodeUTF8));
        label_155->setText(QApplication::translate("dialog_systic", "Ready", 0, QApplication::UnicodeUTF8));
        actv_hvps3->setText(QString());
        con_hvps3->setText(QString());
        rdy_hvps3->setText(QString());
        rdy_hvps1->setText(QString());
        actv_hvps2->setText(QString());
        label_156->setText(QApplication::translate("dialog_systic", "2", 0, QApplication::UnicodeUTF8));
        systic_temp_value->setText(QString());
        label_temp_5->setText(QApplication::translate("dialog_systic", "Systic Board Temperature", 0, QApplication::UnicodeUTF8));
        groupBox_5->setTitle(QApplication::translate("dialog_systic", "Photocells", 0, QApplication::UnicodeUTF8));
        systic_ent_ph->setText(QString());
        systic_ent_ph2->setText(QString());
        label_temp_6->setText(QApplication::translate("dialog_systic", "SDB Board Temperature", 0, QApplication::UnicodeUTF8));
        sdb_temp_value->setText(QString());
        groupBox_3->setTitle(QApplication::translate("dialog_systic", "INPUT", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("dialog_systic", "Frequency", 0, QApplication::UnicodeUTF8));
        ups1_input_freq->setText(QString());
        label_3->setText(QApplication::translate("dialog_systic", "Voltage", 0, QApplication::UnicodeUTF8));
        ups1_input_vol->setText(QString());
        groupBox_8->setTitle(QApplication::translate("dialog_systic", "STATUS", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("dialog_systic", "Status", 0, QApplication::UnicodeUTF8));
        ups1_status->setText(QString());
        label_9->setText(QApplication::translate("dialog_systic", "Temp.", 0, QApplication::UnicodeUTF8));
        ups1_temp->setText(QString());
        label_11->setText(QApplication::translate("dialog_systic", "Load", 0, QApplication::UnicodeUTF8));
        ups1_load->setText(QString());
        label_13->setText(QApplication::translate("dialog_systic", "Charge", 0, QApplication::UnicodeUTF8));
        ups1_charge->setText(QString());
        groupBox_9->setTitle(QApplication::translate("dialog_systic", "OUTPUT", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("dialog_systic", "Voltage", 0, QApplication::UnicodeUTF8));
        ups1_output_vol->setText(QString());
        label_15->setText(QApplication::translate("dialog_systic", "MODEL NAME              :", 0, QApplication::UnicodeUTF8));
        ups1_model->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("dialog_systic", "UPS1", 0, QApplication::UnicodeUTF8));
        label_16->setText(QApplication::translate("dialog_systic", "MODEL NAME              :", 0, QApplication::UnicodeUTF8));
        ups2_model->setText(QString());
        groupBox_11->setTitle(QApplication::translate("dialog_systic", "INPUT", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("dialog_systic", "Frequency", 0, QApplication::UnicodeUTF8));
        ups2_input_freq->setText(QString());
        label_4->setText(QApplication::translate("dialog_systic", "Voltage", 0, QApplication::UnicodeUTF8));
        ups2_input_vol->setText(QString());
        groupBox_10->setTitle(QApplication::translate("dialog_systic", "STATUS", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("dialog_systic", "Status", 0, QApplication::UnicodeUTF8));
        ups2_status->setText(QString());
        label_10->setText(QApplication::translate("dialog_systic", "Temp.", 0, QApplication::UnicodeUTF8));
        ups2_temp->setText(QString());
        label_12->setText(QApplication::translate("dialog_systic", "Load", 0, QApplication::UnicodeUTF8));
        ups2_load->setText(QString());
        label_14->setText(QApplication::translate("dialog_systic", "Charge", 0, QApplication::UnicodeUTF8));
        ups2_charge->setText(QString());
        groupBox_12->setTitle(QApplication::translate("dialog_systic", "OUTPUT", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("dialog_systic", "Voltage", 0, QApplication::UnicodeUTF8));
        ups2_output_vol->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("dialog_systic", "UPS2", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class dialog_systic: public Ui_dialog_systic {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_SYSTIC_H
