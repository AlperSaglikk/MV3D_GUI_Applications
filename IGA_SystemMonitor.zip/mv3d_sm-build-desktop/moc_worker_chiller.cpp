/****************************************************************************
** Meta object code from reading C++ file 'worker_chiller.h'
**
** Created: Mon Aug 10 10:54:39 2020
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mv3d_sm/worker_chiller.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'worker_chiller.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_worker_chiller[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      18,   16,   15,   15, 0x05,
      41,   15,   15,   15, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_worker_chiller[] = {
    "worker_chiller\0\0,\0ch_sender(QString,int)\0"
    "ch_init()\0"
};

const QMetaObject worker_chiller::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_worker_chiller,
      qt_meta_data_worker_chiller, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &worker_chiller::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *worker_chiller::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *worker_chiller::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_worker_chiller))
        return static_cast<void*>(const_cast< worker_chiller*>(this));
    return QThread::qt_metacast(_clname);
}

int worker_chiller::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: ch_sender((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 1: ch_init(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void worker_chiller::ch_sender(QString _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void worker_chiller::ch_init()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}
QT_END_MOC_NAMESPACE
