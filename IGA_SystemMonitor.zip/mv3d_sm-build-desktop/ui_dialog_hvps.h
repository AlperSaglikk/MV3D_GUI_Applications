/********************************************************************************
** Form generated from reading UI file 'dialog_hvps.ui'
**
** Created: Mon Aug 10 10:54:15 2020
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_HVPS_H
#define UI_DIALOG_HVPS_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTabWidget>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_dialog_hvps
{
public:
    QGridLayout *gridLayout;
    QTabWidget *tab_hv;
    QWidget *hvps1;
    QGridLayout *gridLayout_4;
    QWidget *widget_2;
    QGridLayout *gridLayout_5;
    QLabel *label_bus_voltage;
    QLabel *label_fault_state;
    QLabel *label_arc;
    QLabel *hvps1_connector_state;
    QLabel *hvps1_temp;
    QLabel *hvps1_voltage;
    QLabel *label_voltage;
    QLabel *label_temp;
    QLabel *label_connector_state;
    QLabel *hvps1_arc_count;
    QLabel *hvps1_bus;
    QLabel *hvps1_fault_state;
    QLabel *label_20;
    QSpacerItem *verticalSpacer;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_6;
    QLabel *label_space;
    QLabel *hvps1_tube1_fil_cur_set;
    QLabel *label_18;
    QLabel *label_tube1;
    QLabel *label_tube3;
    QLabel *hvps1_tube3_fil_cur_set;
    QLabel *label_tube2;
    QLabel *hvps1_tube2_fil_cur_set;
    QLabel *hvps1_filament_current;
    QLabel *hvps1_tube1_fil_cur;
    QLabel *hvps1_tube2_fil_cur;
    QLabel *hvps1_tube3_fil_cur;
    QLabel *hvps1_beam_current;
    QLabel *hvps1_tube1_beam_cur;
    QLabel *hvps1_tube2_beam_cur;
    QLabel *hvps1_tube3_beam_cur;
    QLabel *label_4;
    QLabel *hvps1_tube1_fil_vol;
    QLabel *hvps1_tube2_fil_vol;
    QLabel *hvps1_tube3_fil_vol;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_2;
    QLabel *hvps1_connection;
    QWidget *hvps2;
    QGridLayout *gridLayout_9;
    QLabel *label_23;
    QLabel *hvps2_connection;
    QWidget *widget_3;
    QGridLayout *gridLayout_8;
    QLabel *label_bus_voltage_2;
    QLabel *label_fault_state_2;
    QLabel *label_arc_2;
    QLabel *hvps2_connector_state;
    QLabel *hvps2_temp;
    QLabel *hvps2_voltage;
    QLabel *label_voltage_2;
    QLabel *label_temp_2;
    QLabel *label_connector_state_2;
    QLabel *hvps2_arc_count;
    QLabel *hvps2_bus;
    QLabel *hvps2_fault_state;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_7;
    QLabel *label_space_2;
    QLabel *hvps2_tube1_fil_cur_set;
    QLabel *label_19;
    QLabel *label_tube1_2;
    QLabel *label_tube3_2;
    QLabel *hvps2_tube3_fil_cur_set;
    QLabel *label_tube2_2;
    QLabel *hvps2_tube2_fil_cur_set;
    QLabel *hvps1_filament_current_2;
    QLabel *hvps2_tube1_fil_cur;
    QLabel *hvps2_tube2_fil_cur;
    QLabel *hvps2_tube3_fil_cur;
    QLabel *hvps1_beam_current_2;
    QLabel *hvps2_tube1_beam_cur;
    QLabel *hvps2_tube2_beam_cur;
    QLabel *hvps2_tube3_beam_cur;
    QLabel *label_5;
    QLabel *hvps2_tube1_fil_vol;
    QLabel *hvps2_tube2_fil_vol;
    QLabel *hvps2_tube3_fil_vol;
    QSpacerItem *verticalSpacer_4;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *horizontalSpacer_4;
    QWidget *hvps3;
    QGridLayout *gridLayout_12;
    QLabel *label_25;
    QWidget *widget_4;
    QGridLayout *gridLayout_10;
    QLabel *label_bus_voltage_3;
    QLabel *label_fault_state_3;
    QLabel *label_arc_3;
    QLabel *hvps3_connector_state;
    QLabel *hvps3_temp;
    QLabel *hvps3_voltage;
    QLabel *label_voltage_3;
    QLabel *label_temp_3;
    QLabel *label_connector_state_3;
    QLabel *hvps3_arc_count;
    QLabel *hvps3_bus;
    QLabel *hvps3_fault_state;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout_11;
    QLabel *label_space_3;
    QLabel *hvps3_tube1_fil_cur_set;
    QLabel *label_26;
    QLabel *label_tube1_3;
    QLabel *label_tube3_3;
    QLabel *hvps3_tube3_fil_cur_set;
    QLabel *label_tube2_3;
    QLabel *hvps3_tube2_fil_cur_set;
    QLabel *hvps1_filament_current_3;
    QLabel *hvps3_tube1_fil_cur;
    QLabel *hvps3_tube2_fil_cur;
    QLabel *hvps3_tube3_fil_cur;
    QLabel *hvps1_beam_current_3;
    QLabel *hvps3_tube1_beam_cur;
    QLabel *hvps3_tube2_beam_cur;
    QLabel *hvps3_tube3_beam_cur;
    QLabel *label_6;
    QLabel *hvps3_tube1_fil_vol;
    QLabel *hvps3_tube2_fil_vol;
    QLabel *hvps3_tube3_fil_vol;
    QSpacerItem *verticalSpacer_5;
    QSpacerItem *verticalSpacer_6;
    QLabel *hvps3_connection;
    QSpacerItem *horizontalSpacer_5;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *hvps_control_button;

    void setupUi(QDialog *dialog_hvps)
    {
        if (dialog_hvps->objectName().isEmpty())
            dialog_hvps->setObjectName(QString::fromUtf8("dialog_hvps"));
        dialog_hvps->resize(541, 472);
        dialog_hvps->setMinimumSize(QSize(0, 472));
        dialog_hvps->setStyleSheet(QString::fromUtf8("background-color: rgb(245, 245, 245);\n"
"background-color: rgb(255, 255, 255);"));
        gridLayout = new QGridLayout(dialog_hvps);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        tab_hv = new QTabWidget(dialog_hvps);
        tab_hv->setObjectName(QString::fromUtf8("tab_hv"));
        tab_hv->setFocusPolicy(Qt::NoFocus);
        tab_hv->setStyleSheet(QString::fromUtf8("QTabBar::tab:!selected	{\n"
"	font: 75 9pt \"Sans Serif\";\n"
"	background-color: rgb(193, 193, 193);\n"
"	border-top-left-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	margin-left: px;\n"
"	margin-right: px;\n"
"	border: 1px solid black;\n"
"	border-bottom-color: black;\n"
"	min-width: 8ex;\n"
"}\n"
"QTabBar::tab:selected	{\n"
"	background-color: rgb(255, 255, 255);\n"
"	font: 75  9pt \"Sans Serif\";\n"
"	border-top-left-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	margin-left: px;\n"
"	margin-right: px;\n"
"	border: 1px solid black;\n"
"	border-bottom-color: rgb(255, 255, 255);\n"
"	min-width: 8ex;\n"
"}\n"
"QTabWidget::pane	{\n"
"	border: 1px solid black\n"
"}"));
        hvps1 = new QWidget();
        hvps1->setObjectName(QString::fromUtf8("hvps1"));
        hvps1->setStyleSheet(QString::fromUtf8("font: 75  bold 9pt \"Sans Serif\";\n"
""));
        gridLayout_4 = new QGridLayout(hvps1);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        widget_2 = new QWidget(hvps1);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        gridLayout_5 = new QGridLayout(widget_2);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        label_bus_voltage = new QLabel(widget_2);
        label_bus_voltage->setObjectName(QString::fromUtf8("label_bus_voltage"));
        label_bus_voltage->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_5->addWidget(label_bus_voltage, 1, 0, 1, 1);

        label_fault_state = new QLabel(widget_2);
        label_fault_state->setObjectName(QString::fromUtf8("label_fault_state"));
        label_fault_state->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_5->addWidget(label_fault_state, 0, 0, 1, 1);

        label_arc = new QLabel(widget_2);
        label_arc->setObjectName(QString::fromUtf8("label_arc"));
        label_arc->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_5->addWidget(label_arc, 2, 0, 1, 1);

        hvps1_connector_state = new QLabel(widget_2);
        hvps1_connector_state->setObjectName(QString::fromUtf8("hvps1_connector_state"));
        hvps1_connector_state->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_connector_state->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(hvps1_connector_state, 0, 3, 1, 1);

        hvps1_temp = new QLabel(widget_2);
        hvps1_temp->setObjectName(QString::fromUtf8("hvps1_temp"));
        hvps1_temp->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_temp->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(hvps1_temp, 1, 3, 1, 1);

        hvps1_voltage = new QLabel(widget_2);
        hvps1_voltage->setObjectName(QString::fromUtf8("hvps1_voltage"));
        hvps1_voltage->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_voltage->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(hvps1_voltage, 2, 3, 1, 1);

        label_voltage = new QLabel(widget_2);
        label_voltage->setObjectName(QString::fromUtf8("label_voltage"));
        label_voltage->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_5->addWidget(label_voltage, 2, 2, 1, 1);

        label_temp = new QLabel(widget_2);
        label_temp->setObjectName(QString::fromUtf8("label_temp"));
        label_temp->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_5->addWidget(label_temp, 1, 2, 1, 1);

        label_connector_state = new QLabel(widget_2);
        label_connector_state->setObjectName(QString::fromUtf8("label_connector_state"));
        label_connector_state->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_5->addWidget(label_connector_state, 0, 2, 1, 1);

        hvps1_arc_count = new QLabel(widget_2);
        hvps1_arc_count->setObjectName(QString::fromUtf8("hvps1_arc_count"));
        hvps1_arc_count->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_arc_count->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(hvps1_arc_count, 2, 1, 1, 1);

        hvps1_bus = new QLabel(widget_2);
        hvps1_bus->setObjectName(QString::fromUtf8("hvps1_bus"));
        hvps1_bus->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_bus->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(hvps1_bus, 1, 1, 1, 1);

        hvps1_fault_state = new QLabel(widget_2);
        hvps1_fault_state->setObjectName(QString::fromUtf8("hvps1_fault_state"));
        hvps1_fault_state->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_fault_state->setAlignment(Qt::AlignCenter);

        gridLayout_5->addWidget(hvps1_fault_state, 0, 1, 1, 1);


        gridLayout_4->addWidget(widget_2, 2, 0, 1, 4);

        label_20 = new QLabel(hvps1);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setMaximumSize(QSize(500, 30));
        label_20->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";"));
        label_20->setTextFormat(Qt::RichText);
        label_20->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_4->addWidget(label_20, 0, 1, 1, 1);

        verticalSpacer = new QSpacerItem(5, 5, QSizePolicy::Minimum, QSizePolicy::Maximum);

        gridLayout_4->addItem(verticalSpacer, 1, 1, 1, 2);

        groupBox = new QGroupBox(hvps1);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";"));
        gridLayout_6 = new QGridLayout(groupBox);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        label_space = new QLabel(groupBox);
        label_space->setObjectName(QString::fromUtf8("label_space"));

        gridLayout_6->addWidget(label_space, 0, 0, 1, 1);

        hvps1_tube1_fil_cur_set = new QLabel(groupBox);
        hvps1_tube1_fil_cur_set->setObjectName(QString::fromUtf8("hvps1_tube1_fil_cur_set"));
        hvps1_tube1_fil_cur_set->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube1_fil_cur_set->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube1_fil_cur_set, 4, 1, 1, 1);

        label_18 = new QLabel(groupBox);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        label_18->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_6->addWidget(label_18, 4, 0, 1, 1);

        label_tube1 = new QLabel(groupBox);
        label_tube1->setObjectName(QString::fromUtf8("label_tube1"));
        QFont font;
        font.setFamily(QString::fromUtf8("Sans Serif"));
        font.setPointSize(10);
        font.setBold(true);
        font.setItalic(false);
        font.setWeight(75);
        label_tube1->setFont(font);
        label_tube1->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";"));
        label_tube1->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(label_tube1, 0, 1, 1, 1);

        label_tube3 = new QLabel(groupBox);
        label_tube3->setObjectName(QString::fromUtf8("label_tube3"));
        label_tube3->setFont(font);
        label_tube3->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";"));
        label_tube3->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(label_tube3, 0, 3, 1, 1);

        hvps1_tube3_fil_cur_set = new QLabel(groupBox);
        hvps1_tube3_fil_cur_set->setObjectName(QString::fromUtf8("hvps1_tube3_fil_cur_set"));
        hvps1_tube3_fil_cur_set->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube3_fil_cur_set->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube3_fil_cur_set, 4, 3, 1, 1);

        label_tube2 = new QLabel(groupBox);
        label_tube2->setObjectName(QString::fromUtf8("label_tube2"));
        label_tube2->setFont(font);
        label_tube2->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";"));
        label_tube2->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(label_tube2, 0, 2, 1, 1);

        hvps1_tube2_fil_cur_set = new QLabel(groupBox);
        hvps1_tube2_fil_cur_set->setObjectName(QString::fromUtf8("hvps1_tube2_fil_cur_set"));
        hvps1_tube2_fil_cur_set->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube2_fil_cur_set->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube2_fil_cur_set, 4, 2, 1, 1);

        hvps1_filament_current = new QLabel(groupBox);
        hvps1_filament_current->setObjectName(QString::fromUtf8("hvps1_filament_current"));
        hvps1_filament_current->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        hvps1_filament_current->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_6->addWidget(hvps1_filament_current, 3, 0, 1, 1);

        hvps1_tube1_fil_cur = new QLabel(groupBox);
        hvps1_tube1_fil_cur->setObjectName(QString::fromUtf8("hvps1_tube1_fil_cur"));
        hvps1_tube1_fil_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube1_fil_cur->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube1_fil_cur, 3, 1, 1, 1);

        hvps1_tube2_fil_cur = new QLabel(groupBox);
        hvps1_tube2_fil_cur->setObjectName(QString::fromUtf8("hvps1_tube2_fil_cur"));
        hvps1_tube2_fil_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube2_fil_cur->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube2_fil_cur, 3, 2, 1, 1);

        hvps1_tube3_fil_cur = new QLabel(groupBox);
        hvps1_tube3_fil_cur->setObjectName(QString::fromUtf8("hvps1_tube3_fil_cur"));
        hvps1_tube3_fil_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube3_fil_cur->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube3_fil_cur, 3, 3, 1, 1);

        hvps1_beam_current = new QLabel(groupBox);
        hvps1_beam_current->setObjectName(QString::fromUtf8("hvps1_beam_current"));
        hvps1_beam_current->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        hvps1_beam_current->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_6->addWidget(hvps1_beam_current, 2, 0, 1, 1);

        hvps1_tube1_beam_cur = new QLabel(groupBox);
        hvps1_tube1_beam_cur->setObjectName(QString::fromUtf8("hvps1_tube1_beam_cur"));
        hvps1_tube1_beam_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube1_beam_cur->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube1_beam_cur, 2, 1, 1, 1);

        hvps1_tube2_beam_cur = new QLabel(groupBox);
        hvps1_tube2_beam_cur->setObjectName(QString::fromUtf8("hvps1_tube2_beam_cur"));
        hvps1_tube2_beam_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube2_beam_cur->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube2_beam_cur, 2, 2, 1, 1);

        hvps1_tube3_beam_cur = new QLabel(groupBox);
        hvps1_tube3_beam_cur->setObjectName(QString::fromUtf8("hvps1_tube3_beam_cur"));
        hvps1_tube3_beam_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube3_beam_cur->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube3_beam_cur, 2, 3, 1, 1);

        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        label_4->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_6->addWidget(label_4, 5, 0, 1, 1);

        hvps1_tube1_fil_vol = new QLabel(groupBox);
        hvps1_tube1_fil_vol->setObjectName(QString::fromUtf8("hvps1_tube1_fil_vol"));
        hvps1_tube1_fil_vol->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube1_fil_vol->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube1_fil_vol, 5, 1, 1, 1);

        hvps1_tube2_fil_vol = new QLabel(groupBox);
        hvps1_tube2_fil_vol->setObjectName(QString::fromUtf8("hvps1_tube2_fil_vol"));
        hvps1_tube2_fil_vol->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube2_fil_vol->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube2_fil_vol, 5, 2, 1, 1);

        hvps1_tube3_fil_vol = new QLabel(groupBox);
        hvps1_tube3_fil_vol->setObjectName(QString::fromUtf8("hvps1_tube3_fil_vol"));
        hvps1_tube3_fil_vol->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps1_tube3_fil_vol->setAlignment(Qt::AlignCenter);

        gridLayout_6->addWidget(hvps1_tube3_fil_vol, 5, 3, 1, 1);


        gridLayout_4->addWidget(groupBox, 4, 0, 1, 4);

        verticalSpacer_3 = new QSpacerItem(20, 5, QSizePolicy::Minimum, QSizePolicy::Maximum);

        gridLayout_4->addItem(verticalSpacer_3, 3, 1, 1, 2);

        horizontalSpacer = new QSpacerItem(280, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer, 0, 3, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(225, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_2, 0, 0, 1, 1);

        hvps1_connection = new QLabel(hvps1);
        hvps1_connection->setObjectName(QString::fromUtf8("hvps1_connection"));
        hvps1_connection->setMinimumSize(QSize(15, 22));
        hvps1_connection->setMaximumSize(QSize(15, 26));
        hvps1_connection->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_4->addWidget(hvps1_connection, 0, 2, 1, 1);

        tab_hv->addTab(hvps1, QString());
        hvps2 = new QWidget();
        hvps2->setObjectName(QString::fromUtf8("hvps2"));
        hvps2->setStyleSheet(QString::fromUtf8("font: 75  bold 9pt \"Sans Serif\";\n"
""));
        gridLayout_9 = new QGridLayout(hvps2);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        label_23 = new QLabel(hvps2);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setMaximumSize(QSize(500, 30));
        label_23->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";"));
        label_23->setTextFormat(Qt::RichText);
        label_23->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_9->addWidget(label_23, 0, 1, 1, 1);

        hvps2_connection = new QLabel(hvps2);
        hvps2_connection->setObjectName(QString::fromUtf8("hvps2_connection"));
        hvps2_connection->setMinimumSize(QSize(15, 22));
        hvps2_connection->setMaximumSize(QSize(15, 26));
        hvps2_connection->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}\n"
""));

        gridLayout_9->addWidget(hvps2_connection, 0, 2, 1, 1);

        widget_3 = new QWidget(hvps2);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        gridLayout_8 = new QGridLayout(widget_3);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        label_bus_voltage_2 = new QLabel(widget_3);
        label_bus_voltage_2->setObjectName(QString::fromUtf8("label_bus_voltage_2"));
        label_bus_voltage_2->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_8->addWidget(label_bus_voltage_2, 1, 0, 1, 1);

        label_fault_state_2 = new QLabel(widget_3);
        label_fault_state_2->setObjectName(QString::fromUtf8("label_fault_state_2"));
        label_fault_state_2->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_8->addWidget(label_fault_state_2, 0, 0, 1, 1);

        label_arc_2 = new QLabel(widget_3);
        label_arc_2->setObjectName(QString::fromUtf8("label_arc_2"));
        label_arc_2->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_8->addWidget(label_arc_2, 2, 0, 1, 1);

        hvps2_connector_state = new QLabel(widget_3);
        hvps2_connector_state->setObjectName(QString::fromUtf8("hvps2_connector_state"));
        hvps2_connector_state->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_connector_state->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(hvps2_connector_state, 0, 3, 1, 1);

        hvps2_temp = new QLabel(widget_3);
        hvps2_temp->setObjectName(QString::fromUtf8("hvps2_temp"));
        hvps2_temp->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_temp->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(hvps2_temp, 1, 3, 1, 1);

        hvps2_voltage = new QLabel(widget_3);
        hvps2_voltage->setObjectName(QString::fromUtf8("hvps2_voltage"));
        hvps2_voltage->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_voltage->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(hvps2_voltage, 2, 3, 1, 1);

        label_voltage_2 = new QLabel(widget_3);
        label_voltage_2->setObjectName(QString::fromUtf8("label_voltage_2"));
        label_voltage_2->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_8->addWidget(label_voltage_2, 2, 2, 1, 1);

        label_temp_2 = new QLabel(widget_3);
        label_temp_2->setObjectName(QString::fromUtf8("label_temp_2"));
        label_temp_2->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_8->addWidget(label_temp_2, 1, 2, 1, 1);

        label_connector_state_2 = new QLabel(widget_3);
        label_connector_state_2->setObjectName(QString::fromUtf8("label_connector_state_2"));
        label_connector_state_2->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_8->addWidget(label_connector_state_2, 0, 2, 1, 1);

        hvps2_arc_count = new QLabel(widget_3);
        hvps2_arc_count->setObjectName(QString::fromUtf8("hvps2_arc_count"));
        hvps2_arc_count->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_arc_count->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(hvps2_arc_count, 2, 1, 1, 1);

        hvps2_bus = new QLabel(widget_3);
        hvps2_bus->setObjectName(QString::fromUtf8("hvps2_bus"));
        hvps2_bus->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_bus->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(hvps2_bus, 1, 1, 1, 1);

        hvps2_fault_state = new QLabel(widget_3);
        hvps2_fault_state->setObjectName(QString::fromUtf8("hvps2_fault_state"));
        hvps2_fault_state->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_fault_state->setAlignment(Qt::AlignCenter);

        gridLayout_8->addWidget(hvps2_fault_state, 0, 1, 1, 1);


        gridLayout_9->addWidget(widget_3, 2, 0, 1, 4);

        groupBox_2 = new QGroupBox(hvps2);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";"));
        gridLayout_7 = new QGridLayout(groupBox_2);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        label_space_2 = new QLabel(groupBox_2);
        label_space_2->setObjectName(QString::fromUtf8("label_space_2"));

        gridLayout_7->addWidget(label_space_2, 0, 0, 1, 1);

        hvps2_tube1_fil_cur_set = new QLabel(groupBox_2);
        hvps2_tube1_fil_cur_set->setObjectName(QString::fromUtf8("hvps2_tube1_fil_cur_set"));
        hvps2_tube1_fil_cur_set->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube1_fil_cur_set->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube1_fil_cur_set, 4, 1, 1, 1);

        label_19 = new QLabel(groupBox_2);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        label_19->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_7->addWidget(label_19, 4, 0, 1, 1);

        label_tube1_2 = new QLabel(groupBox_2);
        label_tube1_2->setObjectName(QString::fromUtf8("label_tube1_2"));
        label_tube1_2->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";"));
        label_tube1_2->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(label_tube1_2, 0, 1, 1, 1);

        label_tube3_2 = new QLabel(groupBox_2);
        label_tube3_2->setObjectName(QString::fromUtf8("label_tube3_2"));
        label_tube3_2->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";"));
        label_tube3_2->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(label_tube3_2, 0, 3, 1, 1);

        hvps2_tube3_fil_cur_set = new QLabel(groupBox_2);
        hvps2_tube3_fil_cur_set->setObjectName(QString::fromUtf8("hvps2_tube3_fil_cur_set"));
        hvps2_tube3_fil_cur_set->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube3_fil_cur_set->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube3_fil_cur_set, 4, 3, 1, 1);

        label_tube2_2 = new QLabel(groupBox_2);
        label_tube2_2->setObjectName(QString::fromUtf8("label_tube2_2"));
        label_tube2_2->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";"));
        label_tube2_2->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(label_tube2_2, 0, 2, 1, 1);

        hvps2_tube2_fil_cur_set = new QLabel(groupBox_2);
        hvps2_tube2_fil_cur_set->setObjectName(QString::fromUtf8("hvps2_tube2_fil_cur_set"));
        hvps2_tube2_fil_cur_set->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube2_fil_cur_set->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube2_fil_cur_set, 4, 2, 1, 1);

        hvps1_filament_current_2 = new QLabel(groupBox_2);
        hvps1_filament_current_2->setObjectName(QString::fromUtf8("hvps1_filament_current_2"));
        hvps1_filament_current_2->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        hvps1_filament_current_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_7->addWidget(hvps1_filament_current_2, 3, 0, 1, 1);

        hvps2_tube1_fil_cur = new QLabel(groupBox_2);
        hvps2_tube1_fil_cur->setObjectName(QString::fromUtf8("hvps2_tube1_fil_cur"));
        hvps2_tube1_fil_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube1_fil_cur->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube1_fil_cur, 3, 1, 1, 1);

        hvps2_tube2_fil_cur = new QLabel(groupBox_2);
        hvps2_tube2_fil_cur->setObjectName(QString::fromUtf8("hvps2_tube2_fil_cur"));
        hvps2_tube2_fil_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube2_fil_cur->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube2_fil_cur, 3, 2, 1, 1);

        hvps2_tube3_fil_cur = new QLabel(groupBox_2);
        hvps2_tube3_fil_cur->setObjectName(QString::fromUtf8("hvps2_tube3_fil_cur"));
        hvps2_tube3_fil_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube3_fil_cur->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube3_fil_cur, 3, 3, 1, 1);

        hvps1_beam_current_2 = new QLabel(groupBox_2);
        hvps1_beam_current_2->setObjectName(QString::fromUtf8("hvps1_beam_current_2"));
        hvps1_beam_current_2->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        hvps1_beam_current_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_7->addWidget(hvps1_beam_current_2, 2, 0, 1, 1);

        hvps2_tube1_beam_cur = new QLabel(groupBox_2);
        hvps2_tube1_beam_cur->setObjectName(QString::fromUtf8("hvps2_tube1_beam_cur"));
        hvps2_tube1_beam_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube1_beam_cur->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube1_beam_cur, 2, 1, 1, 1);

        hvps2_tube2_beam_cur = new QLabel(groupBox_2);
        hvps2_tube2_beam_cur->setObjectName(QString::fromUtf8("hvps2_tube2_beam_cur"));
        hvps2_tube2_beam_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube2_beam_cur->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube2_beam_cur, 2, 2, 1, 1);

        hvps2_tube3_beam_cur = new QLabel(groupBox_2);
        hvps2_tube3_beam_cur->setObjectName(QString::fromUtf8("hvps2_tube3_beam_cur"));
        hvps2_tube3_beam_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube3_beam_cur->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube3_beam_cur, 2, 3, 1, 1);

        label_5 = new QLabel(groupBox_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        label_5->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_7->addWidget(label_5, 5, 0, 1, 1);

        hvps2_tube1_fil_vol = new QLabel(groupBox_2);
        hvps2_tube1_fil_vol->setObjectName(QString::fromUtf8("hvps2_tube1_fil_vol"));
        hvps2_tube1_fil_vol->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube1_fil_vol->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube1_fil_vol, 5, 1, 1, 1);

        hvps2_tube2_fil_vol = new QLabel(groupBox_2);
        hvps2_tube2_fil_vol->setObjectName(QString::fromUtf8("hvps2_tube2_fil_vol"));
        hvps2_tube2_fil_vol->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube2_fil_vol->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube2_fil_vol, 5, 2, 1, 1);

        hvps2_tube3_fil_vol = new QLabel(groupBox_2);
        hvps2_tube3_fil_vol->setObjectName(QString::fromUtf8("hvps2_tube3_fil_vol"));
        hvps2_tube3_fil_vol->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps2_tube3_fil_vol->setAlignment(Qt::AlignCenter);

        gridLayout_7->addWidget(hvps2_tube3_fil_vol, 5, 3, 1, 1);


        gridLayout_9->addWidget(groupBox_2, 4, 0, 1, 4);

        verticalSpacer_4 = new QSpacerItem(20, 5, QSizePolicy::Minimum, QSizePolicy::Maximum);

        gridLayout_9->addItem(verticalSpacer_4, 3, 1, 1, 2);

        verticalSpacer_2 = new QSpacerItem(20, 5, QSizePolicy::Minimum, QSizePolicy::Maximum);

        gridLayout_9->addItem(verticalSpacer_2, 1, 1, 1, 2);

        horizontalSpacer_3 = new QSpacerItem(225, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_9->addItem(horizontalSpacer_3, 0, 0, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(280, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_9->addItem(horizontalSpacer_4, 0, 3, 1, 1);

        tab_hv->addTab(hvps2, QString());
        hvps3 = new QWidget();
        hvps3->setObjectName(QString::fromUtf8("hvps3"));
        hvps3->setStyleSheet(QString::fromUtf8("font: 75  bold 9pt \"Sans Serif\";\n"
""));
        gridLayout_12 = new QGridLayout(hvps3);
        gridLayout_12->setObjectName(QString::fromUtf8("gridLayout_12"));
        label_25 = new QLabel(hvps3);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setMaximumSize(QSize(500, 30));
        label_25->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";"));
        label_25->setTextFormat(Qt::RichText);
        label_25->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_12->addWidget(label_25, 0, 1, 1, 1);

        widget_4 = new QWidget(hvps3);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        gridLayout_10 = new QGridLayout(widget_4);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        label_bus_voltage_3 = new QLabel(widget_4);
        label_bus_voltage_3->setObjectName(QString::fromUtf8("label_bus_voltage_3"));
        label_bus_voltage_3->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_10->addWidget(label_bus_voltage_3, 1, 0, 1, 1);

        label_fault_state_3 = new QLabel(widget_4);
        label_fault_state_3->setObjectName(QString::fromUtf8("label_fault_state_3"));
        label_fault_state_3->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_10->addWidget(label_fault_state_3, 0, 0, 1, 1);

        label_arc_3 = new QLabel(widget_4);
        label_arc_3->setObjectName(QString::fromUtf8("label_arc_3"));
        label_arc_3->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_10->addWidget(label_arc_3, 2, 0, 1, 1);

        hvps3_connector_state = new QLabel(widget_4);
        hvps3_connector_state->setObjectName(QString::fromUtf8("hvps3_connector_state"));
        hvps3_connector_state->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_connector_state->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(hvps3_connector_state, 0, 3, 1, 1);

        hvps3_temp = new QLabel(widget_4);
        hvps3_temp->setObjectName(QString::fromUtf8("hvps3_temp"));
        hvps3_temp->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_temp->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(hvps3_temp, 1, 3, 1, 1);

        hvps3_voltage = new QLabel(widget_4);
        hvps3_voltage->setObjectName(QString::fromUtf8("hvps3_voltage"));
        hvps3_voltage->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_voltage->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(hvps3_voltage, 2, 3, 1, 1);

        label_voltage_3 = new QLabel(widget_4);
        label_voltage_3->setObjectName(QString::fromUtf8("label_voltage_3"));
        label_voltage_3->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_10->addWidget(label_voltage_3, 2, 2, 1, 1);

        label_temp_3 = new QLabel(widget_4);
        label_temp_3->setObjectName(QString::fromUtf8("label_temp_3"));
        label_temp_3->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_10->addWidget(label_temp_3, 1, 2, 1, 1);

        label_connector_state_3 = new QLabel(widget_4);
        label_connector_state_3->setObjectName(QString::fromUtf8("label_connector_state_3"));
        label_connector_state_3->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));

        gridLayout_10->addWidget(label_connector_state_3, 0, 2, 1, 1);

        hvps3_arc_count = new QLabel(widget_4);
        hvps3_arc_count->setObjectName(QString::fromUtf8("hvps3_arc_count"));
        hvps3_arc_count->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_arc_count->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(hvps3_arc_count, 2, 1, 1, 1);

        hvps3_bus = new QLabel(widget_4);
        hvps3_bus->setObjectName(QString::fromUtf8("hvps3_bus"));
        hvps3_bus->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_bus->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(hvps3_bus, 1, 1, 1, 1);

        hvps3_fault_state = new QLabel(widget_4);
        hvps3_fault_state->setObjectName(QString::fromUtf8("hvps3_fault_state"));
        hvps3_fault_state->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_fault_state->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(hvps3_fault_state, 0, 1, 1, 1);


        gridLayout_12->addWidget(widget_4, 2, 0, 1, 4);

        groupBox_3 = new QGroupBox(hvps3);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";"));
        gridLayout_11 = new QGridLayout(groupBox_3);
        gridLayout_11->setObjectName(QString::fromUtf8("gridLayout_11"));
        label_space_3 = new QLabel(groupBox_3);
        label_space_3->setObjectName(QString::fromUtf8("label_space_3"));

        gridLayout_11->addWidget(label_space_3, 0, 0, 1, 1);

        hvps3_tube1_fil_cur_set = new QLabel(groupBox_3);
        hvps3_tube1_fil_cur_set->setObjectName(QString::fromUtf8("hvps3_tube1_fil_cur_set"));
        hvps3_tube1_fil_cur_set->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube1_fil_cur_set->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube1_fil_cur_set, 4, 1, 1, 1);

        label_26 = new QLabel(groupBox_3);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        label_26->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_11->addWidget(label_26, 4, 0, 1, 1);

        label_tube1_3 = new QLabel(groupBox_3);
        label_tube1_3->setObjectName(QString::fromUtf8("label_tube1_3"));
        label_tube1_3->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";"));
        label_tube1_3->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(label_tube1_3, 0, 1, 1, 1);

        label_tube3_3 = new QLabel(groupBox_3);
        label_tube3_3->setObjectName(QString::fromUtf8("label_tube3_3"));
        label_tube3_3->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";"));
        label_tube3_3->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(label_tube3_3, 0, 3, 1, 1);

        hvps3_tube3_fil_cur_set = new QLabel(groupBox_3);
        hvps3_tube3_fil_cur_set->setObjectName(QString::fromUtf8("hvps3_tube3_fil_cur_set"));
        hvps3_tube3_fil_cur_set->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube3_fil_cur_set->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube3_fil_cur_set, 4, 3, 1, 1);

        label_tube2_3 = new QLabel(groupBox_3);
        label_tube2_3->setObjectName(QString::fromUtf8("label_tube2_3"));
        label_tube2_3->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";"));
        label_tube2_3->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(label_tube2_3, 0, 2, 1, 1);

        hvps3_tube2_fil_cur_set = new QLabel(groupBox_3);
        hvps3_tube2_fil_cur_set->setObjectName(QString::fromUtf8("hvps3_tube2_fil_cur_set"));
        hvps3_tube2_fil_cur_set->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube2_fil_cur_set->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube2_fil_cur_set, 4, 2, 1, 1);

        hvps1_filament_current_3 = new QLabel(groupBox_3);
        hvps1_filament_current_3->setObjectName(QString::fromUtf8("hvps1_filament_current_3"));
        hvps1_filament_current_3->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        hvps1_filament_current_3->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_11->addWidget(hvps1_filament_current_3, 3, 0, 1, 1);

        hvps3_tube1_fil_cur = new QLabel(groupBox_3);
        hvps3_tube1_fil_cur->setObjectName(QString::fromUtf8("hvps3_tube1_fil_cur"));
        hvps3_tube1_fil_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube1_fil_cur->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube1_fil_cur, 3, 1, 1, 1);

        hvps3_tube2_fil_cur = new QLabel(groupBox_3);
        hvps3_tube2_fil_cur->setObjectName(QString::fromUtf8("hvps3_tube2_fil_cur"));
        hvps3_tube2_fil_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube2_fil_cur->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube2_fil_cur, 3, 2, 1, 1);

        hvps3_tube3_fil_cur = new QLabel(groupBox_3);
        hvps3_tube3_fil_cur->setObjectName(QString::fromUtf8("hvps3_tube3_fil_cur"));
        hvps3_tube3_fil_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube3_fil_cur->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube3_fil_cur, 3, 3, 1, 1);

        hvps1_beam_current_3 = new QLabel(groupBox_3);
        hvps1_beam_current_3->setObjectName(QString::fromUtf8("hvps1_beam_current_3"));
        hvps1_beam_current_3->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        hvps1_beam_current_3->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_11->addWidget(hvps1_beam_current_3, 2, 0, 1, 1);

        hvps3_tube1_beam_cur = new QLabel(groupBox_3);
        hvps3_tube1_beam_cur->setObjectName(QString::fromUtf8("hvps3_tube1_beam_cur"));
        hvps3_tube1_beam_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube1_beam_cur->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube1_beam_cur, 2, 1, 1, 1);

        hvps3_tube2_beam_cur = new QLabel(groupBox_3);
        hvps3_tube2_beam_cur->setObjectName(QString::fromUtf8("hvps3_tube2_beam_cur"));
        hvps3_tube2_beam_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube2_beam_cur->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube2_beam_cur, 2, 2, 1, 1);

        hvps3_tube3_beam_cur = new QLabel(groupBox_3);
        hvps3_tube3_beam_cur->setObjectName(QString::fromUtf8("hvps3_tube3_beam_cur"));
        hvps3_tube3_beam_cur->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube3_beam_cur->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube3_beam_cur, 2, 3, 1, 1);

        label_6 = new QLabel(groupBox_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";"));
        label_6->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_11->addWidget(label_6, 5, 0, 1, 1);

        hvps3_tube1_fil_vol = new QLabel(groupBox_3);
        hvps3_tube1_fil_vol->setObjectName(QString::fromUtf8("hvps3_tube1_fil_vol"));
        hvps3_tube1_fil_vol->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube1_fil_vol->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube1_fil_vol, 5, 1, 1, 1);

        hvps3_tube2_fil_vol = new QLabel(groupBox_3);
        hvps3_tube2_fil_vol->setObjectName(QString::fromUtf8("hvps3_tube2_fil_vol"));
        hvps3_tube2_fil_vol->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube2_fil_vol->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube2_fil_vol, 5, 2, 1, 1);

        hvps3_tube3_fil_vol = new QLabel(groupBox_3);
        hvps3_tube3_fil_vol->setObjectName(QString::fromUtf8("hvps3_tube3_fil_vol"));
        hvps3_tube3_fil_vol->setStyleSheet(QString::fromUtf8("font: 75 bold 9pt \"Sans Serif\";\n"
"border-radius:3px;\n"
"min-height: 10px;\n"
"min-width: 15px;"));
        hvps3_tube3_fil_vol->setAlignment(Qt::AlignCenter);

        gridLayout_11->addWidget(hvps3_tube3_fil_vol, 5, 3, 1, 1);


        gridLayout_12->addWidget(groupBox_3, 4, 0, 1, 4);

        verticalSpacer_5 = new QSpacerItem(20, 5, QSizePolicy::Minimum, QSizePolicy::Maximum);

        gridLayout_12->addItem(verticalSpacer_5, 1, 1, 1, 2);

        verticalSpacer_6 = new QSpacerItem(20, 5, QSizePolicy::Minimum, QSizePolicy::Maximum);

        gridLayout_12->addItem(verticalSpacer_6, 3, 1, 1, 2);

        hvps3_connection = new QLabel(hvps3);
        hvps3_connection->setObjectName(QString::fromUtf8("hvps3_connection"));
        hvps3_connection->setMinimumSize(QSize(15, 22));
        hvps3_connection->setMaximumSize(QSize(15, 26));
        hvps3_connection->setStyleSheet(QString::fromUtf8("QLabel {\n"
"margin-top: 6px;\n"
"margin-bottom: 6px;\n"
"border-radius:7px;\n"
"min-height: 10px;\n"
"min-width: 15px;\n"
"background-color: rgb(175, 175, 175);\n"
"}"));

        gridLayout_12->addWidget(hvps3_connection, 0, 2, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(225, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_12->addItem(horizontalSpacer_5, 0, 0, 1, 1);

        horizontalSpacer_6 = new QSpacerItem(280, 20, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout_12->addItem(horizontalSpacer_6, 0, 3, 1, 1);

        tab_hv->addTab(hvps3, QString());

        gridLayout->addWidget(tab_hv, 0, 0, 1, 1);

        hvps_control_button = new QPushButton(dialog_hvps);
        hvps_control_button->setObjectName(QString::fromUtf8("hvps_control_button"));

        gridLayout->addWidget(hvps_control_button, 1, 0, 1, 1);


        retranslateUi(dialog_hvps);

        tab_hv->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(dialog_hvps);
    } // setupUi

    void retranslateUi(QDialog *dialog_hvps)
    {
        dialog_hvps->setWindowTitle(QApplication::translate("dialog_hvps", "HVPS", 0, QApplication::UnicodeUTF8));
        label_bus_voltage->setText(QApplication::translate("dialog_hvps", "Bus Output Voltage", 0, QApplication::UnicodeUTF8));
        label_fault_state->setText(QApplication::translate("dialog_hvps", "Latched Fault State", 0, QApplication::UnicodeUTF8));
        label_arc->setText(QApplication::translate("dialog_hvps", "Arc Count", 0, QApplication::UnicodeUTF8));
        hvps1_connector_state->setText(QString());
        hvps1_temp->setText(QString());
        hvps1_voltage->setText(QString());
        label_voltage->setText(QApplication::translate("dialog_hvps", "Voltage", 0, QApplication::UnicodeUTF8));
        label_temp->setText(QApplication::translate("dialog_hvps", "Temperature", 0, QApplication::UnicodeUTF8));
        label_connector_state->setText(QApplication::translate("dialog_hvps", "Connector State", 0, QApplication::UnicodeUTF8));
        hvps1_arc_count->setText(QString());
        hvps1_bus->setText(QString());
        hvps1_fault_state->setText(QString());
        label_20->setText(QApplication::translate("dialog_hvps", "Connection Status", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("dialog_hvps", "Grid", 0, QApplication::UnicodeUTF8));
        label_space->setText(QString());
        hvps1_tube1_fil_cur_set->setText(QString());
        label_18->setText(QApplication::translate("dialog_hvps", "Filament Cur. Setpoint", 0, QApplication::UnicodeUTF8));
        label_tube1->setText(QApplication::translate("dialog_hvps", "Tube 1", 0, QApplication::UnicodeUTF8));
        label_tube3->setText(QApplication::translate("dialog_hvps", "Tube 3", 0, QApplication::UnicodeUTF8));
        hvps1_tube3_fil_cur_set->setText(QString());
        label_tube2->setText(QApplication::translate("dialog_hvps", "Tube 2", 0, QApplication::UnicodeUTF8));
        hvps1_tube2_fil_cur_set->setText(QString());
        hvps1_filament_current->setText(QApplication::translate("dialog_hvps", "Filament Current", 0, QApplication::UnicodeUTF8));
        hvps1_tube1_fil_cur->setText(QString());
        hvps1_tube2_fil_cur->setText(QString());
        hvps1_tube3_fil_cur->setText(QString());
        hvps1_beam_current->setText(QApplication::translate("dialog_hvps", "Beam Current", 0, QApplication::UnicodeUTF8));
        hvps1_tube1_beam_cur->setText(QString());
        hvps1_tube2_beam_cur->setText(QString());
        hvps1_tube3_beam_cur->setText(QString());
        label_4->setText(QApplication::translate("dialog_hvps", "Filament Voltage", 0, QApplication::UnicodeUTF8));
        hvps1_tube1_fil_vol->setText(QString());
        hvps1_tube2_fil_vol->setText(QString());
        hvps1_tube3_fil_vol->setText(QString());
        hvps1_connection->setText(QString());
        tab_hv->setTabText(tab_hv->indexOf(hvps1), QApplication::translate("dialog_hvps", "HVPS 1", 0, QApplication::UnicodeUTF8));
        label_23->setText(QApplication::translate("dialog_hvps", "Connection Status", 0, QApplication::UnicodeUTF8));
        hvps2_connection->setText(QString());
        label_bus_voltage_2->setText(QApplication::translate("dialog_hvps", "Bus Output Voltage", 0, QApplication::UnicodeUTF8));
        label_fault_state_2->setText(QApplication::translate("dialog_hvps", "Latched Fault State", 0, QApplication::UnicodeUTF8));
        label_arc_2->setText(QApplication::translate("dialog_hvps", "Arc Count", 0, QApplication::UnicodeUTF8));
        hvps2_connector_state->setText(QString());
        hvps2_temp->setText(QString());
        hvps2_voltage->setText(QString());
        label_voltage_2->setText(QApplication::translate("dialog_hvps", "Voltage", 0, QApplication::UnicodeUTF8));
        label_temp_2->setText(QApplication::translate("dialog_hvps", "Temperature", 0, QApplication::UnicodeUTF8));
        label_connector_state_2->setText(QApplication::translate("dialog_hvps", "Connector State", 0, QApplication::UnicodeUTF8));
        hvps2_arc_count->setText(QString());
        hvps2_bus->setText(QString());
        hvps2_fault_state->setText(QString());
        groupBox_2->setTitle(QApplication::translate("dialog_hvps", "Grid", 0, QApplication::UnicodeUTF8));
        label_space_2->setText(QString());
        hvps2_tube1_fil_cur_set->setText(QString());
        label_19->setText(QApplication::translate("dialog_hvps", "Filament Cur. Setpoint", 0, QApplication::UnicodeUTF8));
        label_tube1_2->setText(QApplication::translate("dialog_hvps", "Tube 1", 0, QApplication::UnicodeUTF8));
        label_tube3_2->setText(QApplication::translate("dialog_hvps", "Tube 3", 0, QApplication::UnicodeUTF8));
        hvps2_tube3_fil_cur_set->setText(QString());
        label_tube2_2->setText(QApplication::translate("dialog_hvps", "Tube 2", 0, QApplication::UnicodeUTF8));
        hvps2_tube2_fil_cur_set->setText(QString());
        hvps1_filament_current_2->setText(QApplication::translate("dialog_hvps", "Filament Current", 0, QApplication::UnicodeUTF8));
        hvps2_tube1_fil_cur->setText(QString());
        hvps2_tube2_fil_cur->setText(QString());
        hvps2_tube3_fil_cur->setText(QString());
        hvps1_beam_current_2->setText(QApplication::translate("dialog_hvps", "Beam Current", 0, QApplication::UnicodeUTF8));
        hvps2_tube1_beam_cur->setText(QString());
        hvps2_tube2_beam_cur->setText(QString());
        hvps2_tube3_beam_cur->setText(QString());
        label_5->setText(QApplication::translate("dialog_hvps", "Filament Voltage", 0, QApplication::UnicodeUTF8));
        hvps2_tube1_fil_vol->setText(QString());
        hvps2_tube2_fil_vol->setText(QString());
        hvps2_tube3_fil_vol->setText(QString());
        tab_hv->setTabText(tab_hv->indexOf(hvps2), QApplication::translate("dialog_hvps", "HVPS 2", 0, QApplication::UnicodeUTF8));
        label_25->setText(QApplication::translate("dialog_hvps", "Connection Status", 0, QApplication::UnicodeUTF8));
        label_bus_voltage_3->setText(QApplication::translate("dialog_hvps", "Bus Output Voltage", 0, QApplication::UnicodeUTF8));
        label_fault_state_3->setText(QApplication::translate("dialog_hvps", "Latched Fault State", 0, QApplication::UnicodeUTF8));
        label_arc_3->setText(QApplication::translate("dialog_hvps", "Arc Count", 0, QApplication::UnicodeUTF8));
        hvps3_connector_state->setText(QString());
        hvps3_temp->setText(QString());
        hvps3_voltage->setText(QString());
        label_voltage_3->setText(QApplication::translate("dialog_hvps", "Voltage", 0, QApplication::UnicodeUTF8));
        label_temp_3->setText(QApplication::translate("dialog_hvps", "Temperature", 0, QApplication::UnicodeUTF8));
        label_connector_state_3->setText(QApplication::translate("dialog_hvps", "Connector State", 0, QApplication::UnicodeUTF8));
        hvps3_arc_count->setText(QString());
        hvps3_bus->setText(QString());
        hvps3_fault_state->setText(QString());
        groupBox_3->setTitle(QApplication::translate("dialog_hvps", "Grid", 0, QApplication::UnicodeUTF8));
        label_space_3->setText(QString());
        hvps3_tube1_fil_cur_set->setText(QString());
        label_26->setText(QApplication::translate("dialog_hvps", "Filament Cur. Setpoint", 0, QApplication::UnicodeUTF8));
        label_tube1_3->setText(QApplication::translate("dialog_hvps", "Tube 1", 0, QApplication::UnicodeUTF8));
        label_tube3_3->setText(QApplication::translate("dialog_hvps", "Tube 3", 0, QApplication::UnicodeUTF8));
        hvps3_tube3_fil_cur_set->setText(QString());
        label_tube2_3->setText(QApplication::translate("dialog_hvps", "Tube 2", 0, QApplication::UnicodeUTF8));
        hvps3_tube2_fil_cur_set->setText(QString());
        hvps1_filament_current_3->setText(QApplication::translate("dialog_hvps", "Filament Current", 0, QApplication::UnicodeUTF8));
        hvps3_tube1_fil_cur->setText(QString());
        hvps3_tube2_fil_cur->setText(QString());
        hvps3_tube3_fil_cur->setText(QString());
        hvps1_beam_current_3->setText(QApplication::translate("dialog_hvps", "Beam Current", 0, QApplication::UnicodeUTF8));
        hvps3_tube1_beam_cur->setText(QString());
        hvps3_tube2_beam_cur->setText(QString());
        hvps3_tube3_beam_cur->setText(QString());
        label_6->setText(QApplication::translate("dialog_hvps", "Filament Voltage", 0, QApplication::UnicodeUTF8));
        hvps3_tube1_fil_vol->setText(QString());
        hvps3_tube2_fil_vol->setText(QString());
        hvps3_tube3_fil_vol->setText(QString());
        hvps3_connection->setText(QString());
        tab_hv->setTabText(tab_hv->indexOf(hvps3), QApplication::translate("dialog_hvps", "HVPS 3", 0, QApplication::UnicodeUTF8));
        hvps_control_button->setText(QApplication::translate("dialog_hvps", "Controls", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class dialog_hvps: public Ui_dialog_hvps {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_HVPS_H
