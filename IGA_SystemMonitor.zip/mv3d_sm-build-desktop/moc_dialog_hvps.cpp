/****************************************************************************
** Meta object code from reading C++ file 'dialog_hvps.h'
**
** Created: Mon Aug 10 10:54:38 2020
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mv3d_sm/dialog_hvps.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialog_hvps.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_dialog_hvps[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      15,   13,   12,   12, 0x05,

 // slots: signature, parameters, type, tag, flags
      37,   13,   12,   12, 0x0a,
      59,   12,   12,   12, 0x0a,
      74,   12,   12,   12, 0x0a,
      87,   12,   12,   12, 0x0a,
     104,   12,   12,   12, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_dialog_hvps[] = {
    "dialog_hvps\0\0,\0hvfaultState(int,int)\0"
    "hv_taker(QString,int)\0hvOpenTab(int)\0"
    "initilazer()\0gettingWarmHuh()\0"
    "on_hvps_control_button_clicked()\0"
};

const QMetaObject dialog_hvps::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_dialog_hvps,
      qt_meta_data_dialog_hvps, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &dialog_hvps::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *dialog_hvps::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *dialog_hvps::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_dialog_hvps))
        return static_cast<void*>(const_cast< dialog_hvps*>(this));
    return QDialog::qt_metacast(_clname);
}

int dialog_hvps::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: hvfaultState((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 1: hv_taker((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 2: hvOpenTab((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: initilazer(); break;
        case 4: gettingWarmHuh(); break;
        case 5: on_hvps_control_button_clicked(); break;
        default: ;
        }
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void dialog_hvps::hvfaultState(int _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
