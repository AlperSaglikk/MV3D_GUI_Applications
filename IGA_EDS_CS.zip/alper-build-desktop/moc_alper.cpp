/****************************************************************************
** Meta object code from reading C++ file 'alper.h'
**
** Created: Wed Jan 20 16:45:05 2021
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "/mnt/Diger/IGA_Turkey/alper/alper/alper.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'alper.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_alper[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
      66,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      12,    7,    6,    6, 0x0a,
      56,   54,    6,    6, 0x0a,
      71,    6,    6,    6, 0x0a,
      84,    6,    6,    6, 0x08,
     107,    6,    6,    6, 0x08,
     130,    6,    6,    6, 0x08,
     153,    6,    6,    6, 0x08,
     176,    6,    6,    6, 0x08,
     199,    6,    6,    6, 0x08,
     222,    6,    6,    6, 0x08,
     245,    6,    6,    6, 0x08,
     268,    6,    6,    6, 0x08,
     291,    6,    6,    6, 0x08,
     314,    6,    6,    6, 0x08,
     337,    6,    6,    6, 0x08,
     360,    6,    6,    6, 0x08,
     383,    6,    6,    6, 0x08,
     406,    6,    6,    6, 0x08,
     429,    6,    6,    6, 0x08,
     452,    6,    6,    6, 0x08,
     475,    6,    6,    6, 0x08,
     498,    6,    6,    6, 0x08,
     521,    6,    6,    6, 0x08,
     544,    6,    6,    6, 0x08,
     567,    6,    6,    6, 0x08,
     590,    6,    6,    6, 0x08,
     613,    6,    6,    6, 0x08,
     636,    6,    6,    6, 0x08,
     662,    6,    6,    6, 0x08,
     687,    6,    6,    6, 0x08,
     715,    6,    6,    6, 0x08,
     742,    6,    6,    6, 0x08,
     769,    6,    6,    6, 0x08,
     796,    6,    6,    6, 0x08,
     818,    6,    6,    6, 0x08,
     843,    6,    6,    6, 0x08,
     866,    6,    6,    6, 0x08,
     895,    6,    6,    6, 0x08,
     926,    6,    6,    6, 0x08,
     951,    6,    6,    6, 0x08,
     984,    6,    6,    6, 0x08,
    1011,    6,    6,    6, 0x08,
    1038,    6,    6,    6, 0x08,
    1065,    6,    6,    6, 0x08,
    1092,    6,    6,    6, 0x08,
    1119,    6,    6,    6, 0x08,
    1146,    6,    6,    6, 0x08,
    1173,    6,    6,    6, 0x08,
    1200,    6,    6,    6, 0x08,
    1227,    6,    6,    6, 0x08,
    1254,    6,    6,    6, 0x08,
    1281,    6,    6,    6, 0x08,
    1308,    6,    6,    6, 0x08,
    1335,    6,    6,    6, 0x08,
    1362,    6,    6,    6, 0x08,
    1389,    6,    6,    6, 0x08,
    1415,    6,    6,    6, 0x08,
    1441,    6,    6,    6, 0x08,
    1467,    6,    6,    6, 0x08,
    1493,    6,    6,    6, 0x08,
    1519,    6,    6,    6, 0x08,
    1545,    6,    6,    6, 0x08,
    1571,    6,    6,    6, 0x08,
    1597,    6,    6,    6, 0x08,
    1621,    6,    6,    6, 0x08,
    1655,    6,    6,    6, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_alper[] = {
    "alper\0\0,,,,\0writer(int,int,QDateTime,QString,QString)\0"
    ",\0reset(int,int)\0con_lcc(int)\0"
    "on_ED_28_lcc_clicked()\0on_ED_27_lcc_clicked()\0"
    "on_ED_26_lcc_clicked()\0on_ED_25_lcc_clicked()\0"
    "on_ED_24_lcc_clicked()\0on_ED_23_lcc_clicked()\0"
    "on_ED_20_lcc_clicked()\0on_ED_19_lcc_clicked()\0"
    "on_ED_18_lcc_clicked()\0on_ED_17_lcc_clicked()\0"
    "on_ED_16_lcc_clicked()\0on_ED_15_lcc_clicked()\0"
    "on_ED_14_lcc_clicked()\0on_ED_13_lcc_clicked()\0"
    "on_ED_12_lcc_clicked()\0on_ED_11_lcc_clicked()\0"
    "on_ED_10_lcc_clicked()\0on_ED_09_lcc_clicked()\0"
    "on_ED_06_lcc_clicked()\0on_ED_05_lcc_clicked()\0"
    "on_ED_04_lcc_clicked()\0on_ED_03_lcc_clicked()\0"
    "on_ED_02_lcc_clicked()\0on_ED_01_lcc_clicked()\0"
    "on_manuelactive_clicked()\0"
    "on_quickactive_clicked()\0"
    "on_system_monitor_clicked()\0"
    "on_silentmode_bt_clicked()\0"
    "on_screenshot_bt_clicked()\0"
    "on_bag_finder_bt_clicked()\0"
    "on_terminal_clicked()\0on_usb_unmount_clicked()\0"
    "on_usb_mount_clicked()\0"
    "on_save_flt_button_clicked()\0"
    "on_log_finder_button_clicked()\0"
    "on_call_button_clicked()\0"
    "on_fault_screen_button_clicked()\0"
    "on_pushButton_24_clicked()\0"
    "on_pushButton_23_clicked()\0"
    "on_pushButton_22_clicked()\0"
    "on_pushButton_21_clicked()\0"
    "on_pushButton_20_clicked()\0"
    "on_pushButton_19_clicked()\0"
    "on_pushButton_18_clicked()\0"
    "on_pushButton_17_clicked()\0"
    "on_pushButton_16_clicked()\0"
    "on_pushButton_15_clicked()\0"
    "on_pushButton_14_clicked()\0"
    "on_pushButton_13_clicked()\0"
    "on_pushButton_12_clicked()\0"
    "on_pushButton_11_clicked()\0"
    "on_pushButton_10_clicked()\0"
    "on_pushButton_9_clicked()\0"
    "on_pushButton_8_clicked()\0"
    "on_pushButton_7_clicked()\0"
    "on_pushButton_6_clicked()\0"
    "on_pushButton_5_clicked()\0"
    "on_pushButton_4_clicked()\0"
    "on_pushButton_3_clicked()\0"
    "on_pushButton_2_clicked()\0"
    "on_pushButton_clicked()\0"
    "on_fault_display_button_clicked()\0"
    "on_fault_browser_button_clicked()\0"
};

const QMetaObject alper::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_alper,
      qt_meta_data_alper, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &alper::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *alper::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *alper::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_alper))
        return static_cast<void*>(const_cast< alper*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int alper::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: writer((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QDateTime(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5]))); break;
        case 1: reset((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 2: con_lcc((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: on_ED_28_lcc_clicked(); break;
        case 4: on_ED_27_lcc_clicked(); break;
        case 5: on_ED_26_lcc_clicked(); break;
        case 6: on_ED_25_lcc_clicked(); break;
        case 7: on_ED_24_lcc_clicked(); break;
        case 8: on_ED_23_lcc_clicked(); break;
        case 9: on_ED_20_lcc_clicked(); break;
        case 10: on_ED_19_lcc_clicked(); break;
        case 11: on_ED_18_lcc_clicked(); break;
        case 12: on_ED_17_lcc_clicked(); break;
        case 13: on_ED_16_lcc_clicked(); break;
        case 14: on_ED_15_lcc_clicked(); break;
        case 15: on_ED_14_lcc_clicked(); break;
        case 16: on_ED_13_lcc_clicked(); break;
        case 17: on_ED_12_lcc_clicked(); break;
        case 18: on_ED_11_lcc_clicked(); break;
        case 19: on_ED_10_lcc_clicked(); break;
        case 20: on_ED_09_lcc_clicked(); break;
        case 21: on_ED_06_lcc_clicked(); break;
        case 22: on_ED_05_lcc_clicked(); break;
        case 23: on_ED_04_lcc_clicked(); break;
        case 24: on_ED_03_lcc_clicked(); break;
        case 25: on_ED_02_lcc_clicked(); break;
        case 26: on_ED_01_lcc_clicked(); break;
        case 27: on_manuelactive_clicked(); break;
        case 28: on_quickactive_clicked(); break;
        case 29: on_system_monitor_clicked(); break;
        case 30: on_silentmode_bt_clicked(); break;
        case 31: on_screenshot_bt_clicked(); break;
        case 32: on_bag_finder_bt_clicked(); break;
        case 33: on_terminal_clicked(); break;
        case 34: on_usb_unmount_clicked(); break;
        case 35: on_usb_mount_clicked(); break;
        case 36: on_save_flt_button_clicked(); break;
        case 37: on_log_finder_button_clicked(); break;
        case 38: on_call_button_clicked(); break;
        case 39: on_fault_screen_button_clicked(); break;
        case 40: on_pushButton_24_clicked(); break;
        case 41: on_pushButton_23_clicked(); break;
        case 42: on_pushButton_22_clicked(); break;
        case 43: on_pushButton_21_clicked(); break;
        case 44: on_pushButton_20_clicked(); break;
        case 45: on_pushButton_19_clicked(); break;
        case 46: on_pushButton_18_clicked(); break;
        case 47: on_pushButton_17_clicked(); break;
        case 48: on_pushButton_16_clicked(); break;
        case 49: on_pushButton_15_clicked(); break;
        case 50: on_pushButton_14_clicked(); break;
        case 51: on_pushButton_13_clicked(); break;
        case 52: on_pushButton_12_clicked(); break;
        case 53: on_pushButton_11_clicked(); break;
        case 54: on_pushButton_10_clicked(); break;
        case 55: on_pushButton_9_clicked(); break;
        case 56: on_pushButton_8_clicked(); break;
        case 57: on_pushButton_7_clicked(); break;
        case 58: on_pushButton_6_clicked(); break;
        case 59: on_pushButton_5_clicked(); break;
        case 60: on_pushButton_4_clicked(); break;
        case 61: on_pushButton_3_clicked(); break;
        case 62: on_pushButton_2_clicked(); break;
        case 63: on_pushButton_clicked(); break;
        case 64: on_fault_display_button_clicked(); break;
        case 65: on_fault_browser_button_clicked(); break;
        default: ;
        }
        _id -= 66;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
