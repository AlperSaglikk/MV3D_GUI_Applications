/********************************************************************************
** Form generated from reading UI file 'alper.ui'
**
** Created: Wed Jan 20 16:44:54 2021
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ALPER_H
#define UI_ALPER_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDateTimeEdit>
#include <QtGui/QDockWidget>
#include <QtGui/QFrame>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QStatusBar>
#include <QtGui/QTabWidget>
#include <QtGui/QTableWidget>
#include <QtGui/QTextBrowser>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_alper
{
public:
    QWidget *centralWidget;
    QGroupBox *groupBox;
    QLabel *ED_2_FAULT;
    QLabel *ED_6;
    QLabel *ED_3_STATE;
    QLabel *ED_2;
    QLabel *ED_2_STATE;
    QLabel *ED_6_FAULT;
    QLabel *ED_1;
    QLabel *ED_1_FAULT;
    QLabel *ED_5_FAULT;
    QLabel *ED_6_STATE;
    QLabel *ED_4;
    QLabel *ED_5;
    QLabel *ED_3;
    QLabel *ED_1_STATE;
    QLabel *ED_3_FAULT;
    QLabel *ED_4_FAULT;
    QLabel *ED_5_STATE;
    QLabel *ED_4_STATE;
    QLabel *label_19;
    QComboBox *comboBox;
    QLabel *com;
    QLabel *label_26;
    QLabel *label_27;
    QLabel *label_28;
    QLabel *label_29;
    QLabel *label_30;
    QPushButton *pushButton;
    QLabel *ED_10_STATE;
    QLabel *ED_10_FAULT;
    QLabel *ED_9_STATE;
    QLabel *ED_12;
    QLabel *ED_12_STATE;
    QLabel *ED_9;
    QLabel *ED_11;
    QLabel *ED_10;
    QLabel *ED_11_STATE;
    QLabel *ED_14_STATE;
    QLabel *ED_14;
    QLabel *ED_14_FAULT;
    QLabel *ED_13;
    QLabel *ED_12_FAULT;
    QLabel *ED_13_FAULT;
    QLabel *ED_9_FAULT;
    QGroupBox *groupBox_2;
    QLabel *ED_11_FAULT;
    QLabel *ED_13_STATE;
    QLabel *label_61;
    QLabel *ED_26;
    QLabel *ED_16;
    QLabel *label_64;
    QLabel *label_65;
    QLabel *label_66;
    QLabel *ED_23_FAULT;
    QLabel *label_69;
    QGroupBox *groupBox_3;
    QLabel *ED_23;
    QLabel *label_71;
    QLabel *ED_16_FAULT;
    QLabel *label_74;
    QLabel *label_75;
    QLabel *ED_20_STATE;
    QLabel *ED_19_STATE;
    QLabel *ED_17_STATE;
    QLabel *ED_15_STATE;
    QLabel *ED_20;
    QLabel *label_83;
    QLabel *ED_25_STATE;
    QLabel *ED_24_FAULT;
    QLabel *ED_24;
    QLabel *ED_28_STATE;
    QLabel *ED_18_FAULT;
    QLabel *label_92;
    QLabel *ED_20_FAULT;
    QGroupBox *groupBox_4;
    QLabel *ED_17;
    QLabel *ED_27_FAULT;
    QLabel *label_96;
    QLabel *ED_15;
    QLabel *ED_19_FAULT;
    QLabel *ED_23_STATE;
    QLabel *ED_15_FAULT;
    QLabel *label_105;
    QLabel *ED_18_STATE;
    QLabel *ED_26_STATE;
    QLabel *ED_18;
    QLabel *ED_17_FAULT;
    QLabel *ED_16_STATE;
    QLabel *ED_24_STATE;
    QLabel *ED_26_FAULT;
    QLabel *ED_27;
    QLabel *ED_28_FAULT;
    QLabel *ED_28;
    QLabel *ED_25;
    QLabel *ED_19;
    QLabel *ED_25_FAULT;
    QLabel *ED_27_STATE;
    QPushButton *pushButton_2;
    QLabel *com_2;
    QComboBox *comboBox_2;
    QPushButton *pushButton_3;
    QComboBox *comboBox_3;
    QLabel *com_3;
    QLabel *com_4;
    QComboBox *comboBox_4;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QLabel *com_5;
    QComboBox *comboBox_5;
    QLabel *com_6;
    QComboBox *comboBox_6;
    QPushButton *pushButton_6;
    QComboBox *comboBox_14;
    QLabel *com_13;
    QLabel *com_18;
    QComboBox *comboBox_15;
    QLabel *com_17;
    QLabel *com_15;
    QLabel *com_16;
    QComboBox *comboBox_16;
    QComboBox *comboBox_17;
    QPushButton *pushButton_14;
    QPushButton *pushButton_18;
    QComboBox *comboBox_18;
    QPushButton *pushButton_16;
    QLabel *com_14;
    QPushButton *pushButton_13;
    QPushButton *pushButton_15;
    QComboBox *comboBox_13;
    QPushButton *pushButton_17;
    QComboBox *comboBox_22;
    QPushButton *pushButton_23;
    QLabel *com_22;
    QLabel *com_23;
    QLabel *com_21;
    QLabel *com_24;
    QPushButton *pushButton_24;
    QComboBox *comboBox_19;
    QPushButton *pushButton_21;
    QComboBox *comboBox_23;
    QLabel *com_20;
    QPushButton *pushButton_20;
    QPushButton *pushButton_19;
    QComboBox *comboBox_20;
    QLabel *com_19;
    QComboBox *comboBox_21;
    QComboBox *comboBox_24;
    QPushButton *pushButton_22;
    QLabel *label_37;
    QLabel *label_52;
    QLabel *label_58;
    QLabel *label_54;
    QLabel *label_60;
    QLabel *label_50;
    QLabel *com_9;
    QLabel *com_12;
    QPushButton *pushButton_7;
    QLabel *com_10;
    QComboBox *comboBox_12;
    QComboBox *comboBox_11;
    QPushButton *pushButton_11;
    QPushButton *pushButton_9;
    QLabel *com_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_10;
    QComboBox *comboBox_7;
    QLabel *com_8;
    QComboBox *comboBox_10;
    QPushButton *pushButton_12;
    QComboBox *comboBox_8;
    QLabel *com_11;
    QComboBox *comboBox_9;
    QDateTimeEdit *dateTimeEdit;
    QLabel *info;
    QLabel *lstimag;
    QGroupBox *groupBox_5;
    QPushButton *fault_screen_button;
    QPushButton *log_finder_button;
    QPushButton *usb_mount;
    QPushButton *usb_unmount;
    QPushButton *terminal;
    QPushButton *bag_finder_bt;
    QPushButton *screenshot_bt;
    QPushButton *system_monitor;
    QLabel *crntmac;
    QLabel *Creator_label;
    QWidget *layoutWidget;
    QGridLayout *gridLayout_4;
    QPushButton *silentmode_bt;
    QPushButton *ED_01_lcc;
    QPushButton *ED_02_lcc;
    QPushButton *ED_03_lcc;
    QPushButton *ED_04_lcc;
    QPushButton *ED_05_lcc;
    QPushButton *ED_06_lcc;
    QPushButton *ED_09_lcc;
    QPushButton *ED_10_lcc;
    QPushButton *ED_12_lcc;
    QPushButton *ED_11_lcc;
    QPushButton *ED_13_lcc;
    QPushButton *ED_14_lcc;
    QPushButton *ED_16_lcc;
    QPushButton *ED_18_lcc;
    QPushButton *ED_20_lcc;
    QPushButton *ED_15_lcc;
    QPushButton *ED_17_lcc;
    QPushButton *ED_19_lcc;
    QPushButton *ED_23_lcc;
    QPushButton *ED_27_lcc;
    QPushButton *ED_25_lcc;
    QPushButton *ED_24_lcc;
    QPushButton *ED_26_lcc;
    QPushButton *ED_28_lcc;
    QDockWidget *FAULTS;
    QWidget *dockWidgetContents_6;
    QGridLayout *gridLayout;
    QTabWidget *tabWidget;
    QWidget *real_time_tab;
    QGridLayout *gridLayout_3;
    QFrame *frame_2;
    QFrame *line_10;
    QLabel *label_11;
    QLabel *label_12;
    QPushButton *save_flt_button;
    QFrame *line_11;
    QFrame *line_12;
    QDateTimeEdit *faultstartdate;
    QDateTimeEdit *faultenddate;
    QFrame *line_18;
    QComboBox *grep_mv3d_exp;
    QTableWidget *faulttable;
    QWidget *dsplay_tab;
    QGridLayout *gridLayout_5;
    QFrame *frame_3;
    QFrame *line_13;
    QLabel *label_13;
    QLabel *label_14;
    QPushButton *fault_display_button;
    QFrame *line_14;
    QFrame *line_15;
    QDateTimeEdit *faultstartdate_disp;
    QDateTimeEdit *faultenddate_disp;
    QFrame *line_16;
    QPushButton *fault_browser_button;
    QComboBox *grep_mv3d_disp;
    QFrame *line_17;
    QTableWidget *disp_faulttable;
    QDockWidget *bagdec;
    QWidget *dockWidgetContents;
    QGridLayout *gridLayout_2;
    QFrame *frame;
    QComboBox *grep_mv3d;
    QComboBox *grepperbox;
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QDateTimeEdit *grepdate;
    QFrame *line_4;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *call_button;
    QLabel *label_4;
    QLabel *label_5;
    QFrame *line_5;
    QLabel *label_6;
    QRadioButton *manuelactive;
    QComboBox *manuelcombo;
    QTextEdit *manuellabel;
    QLabel *label_10;
    QFrame *line_9;
    QComboBox *log_selection_box;
    QFrame *line_6;
    QRadioButton *quickactive;
    QLabel *label_7;
    QTextBrowser *bagdecision;
    QMenuBar *menuBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *alper)
    {
        if (alper->objectName().isEmpty())
            alper->setObjectName(QString::fromUtf8("alper"));
        alper->setEnabled(true);
        alper->resize(693, 1124);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(alper->sizePolicy().hasHeightForWidth());
        alper->setSizePolicy(sizePolicy);
        alper->setMinimumSize(QSize(693, 1124));
        alper->setMaximumSize(QSize(693, 1124));
        alper->setFocusPolicy(Qt::NoFocus);
        alper->setContextMenuPolicy(Qt::ActionsContextMenu);
        alper->setAcceptDrops(false);
        alper->setWindowOpacity(1);
        alper->setAutoFillBackground(false);
        alper->setStyleSheet(QString::fromUtf8(""));
        centralWidget = new QWidget(alper);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setEnabled(true);
        groupBox->setGeometry(QRect(20, 50, 311, 451));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy1);
        QPalette palette;
        QBrush brush(QColor(125, 0, 62, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(0, 0, 0, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush1);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        groupBox->setPalette(palette);
        QFont font;
        font.setFamily(QString::fromUtf8("Serif"));
        font.setPointSize(13);
        font.setBold(true);
        font.setItalic(false);
        font.setWeight(75);
        groupBox->setFont(font);
        groupBox->setCursor(QCursor(Qt::ArrowCursor));
        groupBox->setMouseTracking(false);
        groupBox->setFocusPolicy(Qt::NoFocus);
        groupBox->setContextMenuPolicy(Qt::DefaultContextMenu);
        groupBox->setStyleSheet(QString::fromUtf8("color: rgb(125, 0, 62);"));
        groupBox->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        groupBox->setFlat(false);
        groupBox->setCheckable(false);
        ED_2_FAULT = new QLabel(centralWidget);
        ED_2_FAULT->setObjectName(QString::fromUtf8("ED_2_FAULT"));
        ED_2_FAULT->setGeometry(QRect(30, 190, 241, 21));
        ED_2_FAULT->setFrameShape(QFrame::Box);
        ED_2_FAULT->setFrameShadow(QFrame::Plain);
        ED_2_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_6 = new QLabel(centralWidget);
        ED_6->setObjectName(QString::fromUtf8("ED_6"));
        ED_6->setGeometry(QRect(30, 430, 241, 20));
        QFont font1;
        font1.setBold(true);
        font1.setItalic(false);
        font1.setUnderline(false);
        font1.setWeight(75);
        ED_6->setFont(font1);
        ED_6->setFrameShape(QFrame::Box);
        ED_6->setFrameShadow(QFrame::Plain);
        ED_6->setAlignment(Qt::AlignCenter);
        ED_3_STATE = new QLabel(centralWidget);
        ED_3_STATE->setObjectName(QString::fromUtf8("ED_3_STATE"));
        ED_3_STATE->setGeometry(QRect(30, 240, 241, 21));
        ED_3_STATE->setFrameShape(QFrame::Box);
        ED_3_STATE->setFrameShadow(QFrame::Plain);
        ED_3_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_2 = new QLabel(centralWidget);
        ED_2->setObjectName(QString::fromUtf8("ED_2"));
        ED_2->setGeometry(QRect(30, 150, 241, 20));
        ED_2->setFont(font1);
        ED_2->setFrameShape(QFrame::Box);
        ED_2->setFrameShadow(QFrame::Plain);
        ED_2->setAlignment(Qt::AlignCenter);
        ED_2_STATE = new QLabel(centralWidget);
        ED_2_STATE->setObjectName(QString::fromUtf8("ED_2_STATE"));
        ED_2_STATE->setGeometry(QRect(30, 170, 241, 21));
        ED_2_STATE->setFrameShape(QFrame::Box);
        ED_2_STATE->setFrameShadow(QFrame::Plain);
        ED_2_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_6_FAULT = new QLabel(centralWidget);
        ED_6_FAULT->setObjectName(QString::fromUtf8("ED_6_FAULT"));
        ED_6_FAULT->setGeometry(QRect(30, 470, 241, 21));
        ED_6_FAULT->setFrameShape(QFrame::Box);
        ED_6_FAULT->setFrameShadow(QFrame::Plain);
        ED_6_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_1 = new QLabel(centralWidget);
        ED_1->setObjectName(QString::fromUtf8("ED_1"));
        ED_1->setGeometry(QRect(30, 80, 241, 20));
        ED_1->setFont(font1);
        ED_1->setFrameShape(QFrame::Box);
        ED_1->setFrameShadow(QFrame::Plain);
        ED_1->setAlignment(Qt::AlignCenter);
        ED_1_FAULT = new QLabel(centralWidget);
        ED_1_FAULT->setObjectName(QString::fromUtf8("ED_1_FAULT"));
        ED_1_FAULT->setGeometry(QRect(30, 120, 241, 21));
        ED_1_FAULT->setFrameShape(QFrame::Box);
        ED_1_FAULT->setFrameShadow(QFrame::Plain);
        ED_1_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_5_FAULT = new QLabel(centralWidget);
        ED_5_FAULT->setObjectName(QString::fromUtf8("ED_5_FAULT"));
        ED_5_FAULT->setGeometry(QRect(30, 400, 241, 21));
        ED_5_FAULT->setFrameShape(QFrame::Box);
        ED_5_FAULT->setFrameShadow(QFrame::Plain);
        ED_5_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_6_STATE = new QLabel(centralWidget);
        ED_6_STATE->setObjectName(QString::fromUtf8("ED_6_STATE"));
        ED_6_STATE->setGeometry(QRect(30, 450, 241, 21));
        ED_6_STATE->setFrameShape(QFrame::Box);
        ED_6_STATE->setFrameShadow(QFrame::Plain);
        ED_6_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_4 = new QLabel(centralWidget);
        ED_4->setObjectName(QString::fromUtf8("ED_4"));
        ED_4->setGeometry(QRect(30, 290, 241, 20));
        ED_4->setFont(font1);
        ED_4->setFrameShape(QFrame::Box);
        ED_4->setFrameShadow(QFrame::Plain);
        ED_4->setAlignment(Qt::AlignCenter);
        ED_5 = new QLabel(centralWidget);
        ED_5->setObjectName(QString::fromUtf8("ED_5"));
        ED_5->setGeometry(QRect(30, 360, 241, 20));
        ED_5->setFont(font1);
        ED_5->setFrameShape(QFrame::Box);
        ED_5->setFrameShadow(QFrame::Plain);
        ED_5->setAlignment(Qt::AlignCenter);
        ED_3 = new QLabel(centralWidget);
        ED_3->setObjectName(QString::fromUtf8("ED_3"));
        ED_3->setGeometry(QRect(30, 220, 241, 20));
        ED_3->setFont(font1);
        ED_3->setFrameShape(QFrame::Box);
        ED_3->setFrameShadow(QFrame::Plain);
        ED_3->setAlignment(Qt::AlignCenter);
        ED_1_STATE = new QLabel(centralWidget);
        ED_1_STATE->setObjectName(QString::fromUtf8("ED_1_STATE"));
        ED_1_STATE->setGeometry(QRect(30, 100, 241, 21));
        ED_1_STATE->setFrameShape(QFrame::Box);
        ED_1_STATE->setFrameShadow(QFrame::Plain);
        ED_1_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_3_FAULT = new QLabel(centralWidget);
        ED_3_FAULT->setObjectName(QString::fromUtf8("ED_3_FAULT"));
        ED_3_FAULT->setGeometry(QRect(30, 260, 241, 21));
        ED_3_FAULT->setFrameShape(QFrame::Box);
        ED_3_FAULT->setFrameShadow(QFrame::Plain);
        ED_3_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_4_FAULT = new QLabel(centralWidget);
        ED_4_FAULT->setObjectName(QString::fromUtf8("ED_4_FAULT"));
        ED_4_FAULT->setGeometry(QRect(30, 330, 241, 21));
        ED_4_FAULT->setFrameShape(QFrame::Box);
        ED_4_FAULT->setFrameShadow(QFrame::Plain);
        ED_4_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_5_STATE = new QLabel(centralWidget);
        ED_5_STATE->setObjectName(QString::fromUtf8("ED_5_STATE"));
        ED_5_STATE->setGeometry(QRect(30, 380, 241, 21));
        ED_5_STATE->setFrameShape(QFrame::Box);
        ED_5_STATE->setFrameShadow(QFrame::Plain);
        ED_5_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_4_STATE = new QLabel(centralWidget);
        ED_4_STATE->setObjectName(QString::fromUtf8("ED_4_STATE"));
        ED_4_STATE->setGeometry(QRect(30, 310, 241, 21));
        ED_4_STATE->setFrameShape(QFrame::Box);
        ED_4_STATE->setFrameShadow(QFrame::Plain);
        ED_4_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_19 = new QLabel(centralWidget);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(270, 80, 51, 61));
        QFont font2;
        font2.setBold(true);
        font2.setUnderline(false);
        font2.setWeight(75);
        label_19->setFont(font2);
        label_19->setFrameShape(QFrame::Box);
        label_19->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        comboBox = new QComboBox(centralWidget);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(270, 99, 53, 22));
        QFont font3;
        font3.setPointSize(9);
        comboBox->setFont(font3);
        comboBox->setMouseTracking(false);
        comboBox->setFocusPolicy(Qt::NoFocus);
        comboBox->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox->setLayoutDirection(Qt::LeftToRight);
        comboBox->setEditable(false);
        comboBox->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox->setFrame(true);
        com = new QLabel(centralWidget);
        com->setObjectName(QString::fromUtf8("com"));
        com->setGeometry(QRect(270, 80, 51, 20));
        QFont font4;
        font4.setPointSize(9);
        font4.setBold(true);
        font4.setWeight(75);
        com->setFont(font4);
        com->setStyleSheet(QString::fromUtf8(""));
        com->setFrameShape(QFrame::Box);
        com->setAlignment(Qt::AlignCenter);
        label_26 = new QLabel(centralWidget);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setGeometry(QRect(270, 150, 51, 61));
        label_26->setFont(font2);
        label_26->setFrameShape(QFrame::Box);
        label_26->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_27 = new QLabel(centralWidget);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setGeometry(QRect(270, 220, 51, 61));
        label_27->setFont(font2);
        label_27->setFrameShape(QFrame::Box);
        label_27->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_28 = new QLabel(centralWidget);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setGeometry(QRect(270, 290, 51, 61));
        label_28->setFont(font2);
        label_28->setFrameShape(QFrame::Box);
        label_28->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_29 = new QLabel(centralWidget);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setGeometry(QRect(270, 360, 51, 61));
        label_29->setFont(font2);
        label_29->setFrameShape(QFrame::Box);
        label_29->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_30 = new QLabel(centralWidget);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setGeometry(QRect(270, 430, 51, 61));
        label_30->setFont(font2);
        label_30->setFrameShape(QFrame::Box);
        label_30->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(271, 120, 50, 21));
        QFont font5;
        font5.setPointSize(8);
        font5.setBold(true);
        font5.setWeight(75);
        pushButton->setFont(font5);
        pushButton->setFocusPolicy(Qt::NoFocus);
        pushButton->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton->setAutoDefault(false);
        pushButton->setDefault(false);
        pushButton->setFlat(false);
        ED_10_STATE = new QLabel(centralWidget);
        ED_10_STATE->setObjectName(QString::fromUtf8("ED_10_STATE"));
        ED_10_STATE->setGeometry(QRect(370, 170, 241, 21));
        ED_10_STATE->setFrameShape(QFrame::Box);
        ED_10_STATE->setFrameShadow(QFrame::Plain);
        ED_10_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_10_FAULT = new QLabel(centralWidget);
        ED_10_FAULT->setObjectName(QString::fromUtf8("ED_10_FAULT"));
        ED_10_FAULT->setGeometry(QRect(370, 190, 241, 21));
        ED_10_FAULT->setFrameShape(QFrame::Box);
        ED_10_FAULT->setFrameShadow(QFrame::Plain);
        ED_10_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_9_STATE = new QLabel(centralWidget);
        ED_9_STATE->setObjectName(QString::fromUtf8("ED_9_STATE"));
        ED_9_STATE->setGeometry(QRect(370, 100, 241, 21));
        ED_9_STATE->setFrameShape(QFrame::Box);
        ED_9_STATE->setFrameShadow(QFrame::Plain);
        ED_9_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_12 = new QLabel(centralWidget);
        ED_12->setObjectName(QString::fromUtf8("ED_12"));
        ED_12->setGeometry(QRect(370, 290, 241, 20));
        ED_12->setFont(font1);
        ED_12->setFrameShape(QFrame::Box);
        ED_12->setFrameShadow(QFrame::Plain);
        ED_12->setAlignment(Qt::AlignCenter);
        ED_12_STATE = new QLabel(centralWidget);
        ED_12_STATE->setObjectName(QString::fromUtf8("ED_12_STATE"));
        ED_12_STATE->setGeometry(QRect(370, 310, 241, 21));
        ED_12_STATE->setFrameShape(QFrame::Box);
        ED_12_STATE->setFrameShadow(QFrame::Plain);
        ED_12_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_9 = new QLabel(centralWidget);
        ED_9->setObjectName(QString::fromUtf8("ED_9"));
        ED_9->setGeometry(QRect(370, 80, 241, 20));
        ED_9->setFont(font1);
        ED_9->setFrameShape(QFrame::Box);
        ED_9->setFrameShadow(QFrame::Plain);
        ED_9->setAlignment(Qt::AlignCenter);
        ED_11 = new QLabel(centralWidget);
        ED_11->setObjectName(QString::fromUtf8("ED_11"));
        ED_11->setGeometry(QRect(370, 220, 241, 20));
        ED_11->setFont(font1);
        ED_11->setFrameShape(QFrame::Box);
        ED_11->setFrameShadow(QFrame::Plain);
        ED_11->setAlignment(Qt::AlignCenter);
        ED_10 = new QLabel(centralWidget);
        ED_10->setObjectName(QString::fromUtf8("ED_10"));
        ED_10->setGeometry(QRect(370, 150, 241, 20));
        ED_10->setFont(font1);
        ED_10->setFrameShape(QFrame::Box);
        ED_10->setFrameShadow(QFrame::Plain);
        ED_10->setAlignment(Qt::AlignCenter);
        ED_11_STATE = new QLabel(centralWidget);
        ED_11_STATE->setObjectName(QString::fromUtf8("ED_11_STATE"));
        ED_11_STATE->setGeometry(QRect(370, 240, 241, 21));
        ED_11_STATE->setFrameShape(QFrame::Box);
        ED_11_STATE->setFrameShadow(QFrame::Plain);
        ED_11_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_14_STATE = new QLabel(centralWidget);
        ED_14_STATE->setObjectName(QString::fromUtf8("ED_14_STATE"));
        ED_14_STATE->setGeometry(QRect(370, 450, 241, 21));
        ED_14_STATE->setFrameShape(QFrame::Box);
        ED_14_STATE->setFrameShadow(QFrame::Plain);
        ED_14_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_14 = new QLabel(centralWidget);
        ED_14->setObjectName(QString::fromUtf8("ED_14"));
        ED_14->setGeometry(QRect(370, 430, 241, 20));
        ED_14->setFont(font1);
        ED_14->setFrameShape(QFrame::Box);
        ED_14->setFrameShadow(QFrame::Plain);
        ED_14->setAlignment(Qt::AlignCenter);
        ED_14_FAULT = new QLabel(centralWidget);
        ED_14_FAULT->setObjectName(QString::fromUtf8("ED_14_FAULT"));
        ED_14_FAULT->setGeometry(QRect(370, 470, 241, 21));
        ED_14_FAULT->setFrameShape(QFrame::Box);
        ED_14_FAULT->setFrameShadow(QFrame::Plain);
        ED_14_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_13 = new QLabel(centralWidget);
        ED_13->setObjectName(QString::fromUtf8("ED_13"));
        ED_13->setGeometry(QRect(370, 360, 241, 20));
        ED_13->setFont(font1);
        ED_13->setFrameShape(QFrame::Box);
        ED_13->setFrameShadow(QFrame::Plain);
        ED_13->setAlignment(Qt::AlignCenter);
        ED_12_FAULT = new QLabel(centralWidget);
        ED_12_FAULT->setObjectName(QString::fromUtf8("ED_12_FAULT"));
        ED_12_FAULT->setGeometry(QRect(370, 330, 241, 21));
        ED_12_FAULT->setFrameShape(QFrame::Box);
        ED_12_FAULT->setFrameShadow(QFrame::Plain);
        ED_12_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_13_FAULT = new QLabel(centralWidget);
        ED_13_FAULT->setObjectName(QString::fromUtf8("ED_13_FAULT"));
        ED_13_FAULT->setGeometry(QRect(370, 400, 241, 21));
        ED_13_FAULT->setFrameShape(QFrame::Box);
        ED_13_FAULT->setFrameShadow(QFrame::Plain);
        ED_13_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_9_FAULT = new QLabel(centralWidget);
        ED_9_FAULT->setObjectName(QString::fromUtf8("ED_9_FAULT"));
        ED_9_FAULT->setGeometry(QRect(370, 120, 241, 21));
        ED_9_FAULT->setFrameShape(QFrame::Box);
        ED_9_FAULT->setFrameShadow(QFrame::Plain);
        ED_9_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        groupBox_2 = new QGroupBox(centralWidget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setEnabled(true);
        groupBox_2->setGeometry(QRect(360, 50, 311, 451));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Active, QPalette::Dark, brush1);
        palette1.setBrush(QPalette::Active, QPalette::Text, brush);
        palette1.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Dark, brush1);
        palette1.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Dark, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        groupBox_2->setPalette(palette1);
        QFont font6;
        font6.setFamily(QString::fromUtf8("Serif"));
        font6.setPointSize(13);
        font6.setBold(true);
        font6.setItalic(false);
        font6.setUnderline(false);
        font6.setWeight(75);
        font6.setStrikeOut(false);
        font6.setKerning(true);
        font6.setStyleStrategy(QFont::PreferDefault);
        groupBox_2->setFont(font6);
        groupBox_2->setStyleSheet(QString::fromUtf8("color: rgb(125, 0, 62);"));
        groupBox_2->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        groupBox_2->setFlat(false);
        groupBox_2->setCheckable(false);
        ED_11_FAULT = new QLabel(centralWidget);
        ED_11_FAULT->setObjectName(QString::fromUtf8("ED_11_FAULT"));
        ED_11_FAULT->setGeometry(QRect(370, 260, 241, 21));
        ED_11_FAULT->setFrameShape(QFrame::Box);
        ED_11_FAULT->setFrameShadow(QFrame::Plain);
        ED_11_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_13_STATE = new QLabel(centralWidget);
        ED_13_STATE->setObjectName(QString::fromUtf8("ED_13_STATE"));
        ED_13_STATE->setGeometry(QRect(370, 380, 241, 21));
        ED_13_STATE->setFrameShape(QFrame::Box);
        ED_13_STATE->setFrameShadow(QFrame::Plain);
        ED_13_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_61 = new QLabel(centralWidget);
        label_61->setObjectName(QString::fromUtf8("label_61"));
        label_61->setGeometry(QRect(270, 700, 51, 61));
        label_61->setFont(font2);
        label_61->setFrameShape(QFrame::Box);
        label_61->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        ED_26 = new QLabel(centralWidget);
        ED_26->setObjectName(QString::fromUtf8("ED_26"));
        ED_26->setGeometry(QRect(370, 770, 241, 20));
        ED_26->setFont(font1);
        ED_26->setFrameShape(QFrame::Box);
        ED_26->setFrameShadow(QFrame::Plain);
        ED_26->setAlignment(Qt::AlignCenter);
        ED_16 = new QLabel(centralWidget);
        ED_16->setObjectName(QString::fromUtf8("ED_16"));
        ED_16->setGeometry(QRect(30, 630, 241, 20));
        ED_16->setFont(font1);
        ED_16->setFrameShape(QFrame::Box);
        ED_16->setFrameShadow(QFrame::Plain);
        ED_16->setAlignment(Qt::AlignCenter);
        label_64 = new QLabel(centralWidget);
        label_64->setObjectName(QString::fromUtf8("label_64"));
        label_64->setGeometry(QRect(610, 840, 51, 61));
        label_64->setFont(font2);
        label_64->setFrameShape(QFrame::Box);
        label_64->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_65 = new QLabel(centralWidget);
        label_65->setObjectName(QString::fromUtf8("label_65"));
        label_65->setGeometry(QRect(610, 700, 51, 61));
        label_65->setFont(font2);
        label_65->setFrameShape(QFrame::Box);
        label_65->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_66 = new QLabel(centralWidget);
        label_66->setObjectName(QString::fromUtf8("label_66"));
        label_66->setGeometry(QRect(270, 770, 51, 61));
        label_66->setFont(font2);
        label_66->setFrameShape(QFrame::Box);
        label_66->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        ED_23_FAULT = new QLabel(centralWidget);
        ED_23_FAULT->setObjectName(QString::fromUtf8("ED_23_FAULT"));
        ED_23_FAULT->setGeometry(QRect(370, 600, 241, 21));
        ED_23_FAULT->setFrameShape(QFrame::Box);
        ED_23_FAULT->setFrameShadow(QFrame::Plain);
        ED_23_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_69 = new QLabel(centralWidget);
        label_69->setObjectName(QString::fromUtf8("label_69"));
        label_69->setGeometry(QRect(270, 560, 51, 61));
        label_69->setFont(font2);
        label_69->setFrameShape(QFrame::Box);
        label_69->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        groupBox_3 = new QGroupBox(centralWidget);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setEnabled(true);
        groupBox_3->setGeometry(QRect(20, 530, 311, 451));
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette2.setBrush(QPalette::Active, QPalette::Dark, brush1);
        palette2.setBrush(QPalette::Active, QPalette::Text, brush);
        palette2.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Dark, brush1);
        palette2.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::WindowText, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::Dark, brush1);
        palette2.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        groupBox_3->setPalette(palette2);
        groupBox_3->setFont(font);
        groupBox_3->setStyleSheet(QString::fromUtf8("color: rgb(125, 0, 62);"));
        groupBox_3->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        groupBox_3->setFlat(false);
        groupBox_3->setCheckable(false);
        ED_23 = new QLabel(centralWidget);
        ED_23->setObjectName(QString::fromUtf8("ED_23"));
        ED_23->setGeometry(QRect(370, 560, 241, 20));
        ED_23->setFont(font1);
        ED_23->setFrameShape(QFrame::Box);
        ED_23->setFrameShadow(QFrame::Plain);
        ED_23->setAlignment(Qt::AlignCenter);
        label_71 = new QLabel(centralWidget);
        label_71->setObjectName(QString::fromUtf8("label_71"));
        label_71->setGeometry(QRect(270, 630, 51, 61));
        label_71->setFont(font2);
        label_71->setFrameShape(QFrame::Box);
        label_71->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        ED_16_FAULT = new QLabel(centralWidget);
        ED_16_FAULT->setObjectName(QString::fromUtf8("ED_16_FAULT"));
        ED_16_FAULT->setGeometry(QRect(30, 670, 241, 21));
        ED_16_FAULT->setFrameShape(QFrame::Box);
        ED_16_FAULT->setFrameShadow(QFrame::Plain);
        ED_16_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_74 = new QLabel(centralWidget);
        label_74->setObjectName(QString::fromUtf8("label_74"));
        label_74->setGeometry(QRect(610, 560, 51, 61));
        label_74->setFont(font2);
        label_74->setFrameShape(QFrame::Box);
        label_74->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_75 = new QLabel(centralWidget);
        label_75->setObjectName(QString::fromUtf8("label_75"));
        label_75->setGeometry(QRect(610, 630, 51, 61));
        label_75->setFont(font2);
        label_75->setFrameShape(QFrame::Box);
        label_75->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        ED_20_STATE = new QLabel(centralWidget);
        ED_20_STATE->setObjectName(QString::fromUtf8("ED_20_STATE"));
        ED_20_STATE->setGeometry(QRect(30, 930, 241, 21));
        ED_20_STATE->setFrameShape(QFrame::Box);
        ED_20_STATE->setFrameShadow(QFrame::Plain);
        ED_20_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_19_STATE = new QLabel(centralWidget);
        ED_19_STATE->setObjectName(QString::fromUtf8("ED_19_STATE"));
        ED_19_STATE->setGeometry(QRect(30, 860, 241, 21));
        ED_19_STATE->setFrameShape(QFrame::Box);
        ED_19_STATE->setFrameShadow(QFrame::Plain);
        ED_19_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_17_STATE = new QLabel(centralWidget);
        ED_17_STATE->setObjectName(QString::fromUtf8("ED_17_STATE"));
        ED_17_STATE->setGeometry(QRect(30, 720, 241, 21));
        ED_17_STATE->setFrameShape(QFrame::Box);
        ED_17_STATE->setFrameShadow(QFrame::Plain);
        ED_17_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_15_STATE = new QLabel(centralWidget);
        ED_15_STATE->setObjectName(QString::fromUtf8("ED_15_STATE"));
        ED_15_STATE->setGeometry(QRect(30, 580, 241, 21));
        ED_15_STATE->setFrameShape(QFrame::Box);
        ED_15_STATE->setFrameShadow(QFrame::Plain);
        ED_15_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_20 = new QLabel(centralWidget);
        ED_20->setObjectName(QString::fromUtf8("ED_20"));
        ED_20->setGeometry(QRect(30, 910, 241, 20));
        ED_20->setFont(font1);
        ED_20->setFrameShape(QFrame::Box);
        ED_20->setFrameShadow(QFrame::Plain);
        ED_20->setAlignment(Qt::AlignCenter);
        label_83 = new QLabel(centralWidget);
        label_83->setObjectName(QString::fromUtf8("label_83"));
        label_83->setGeometry(QRect(270, 840, 51, 61));
        label_83->setFont(font2);
        label_83->setFrameShape(QFrame::Box);
        label_83->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        ED_25_STATE = new QLabel(centralWidget);
        ED_25_STATE->setObjectName(QString::fromUtf8("ED_25_STATE"));
        ED_25_STATE->setGeometry(QRect(370, 720, 241, 21));
        ED_25_STATE->setFrameShape(QFrame::Box);
        ED_25_STATE->setFrameShadow(QFrame::Plain);
        ED_25_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_24_FAULT = new QLabel(centralWidget);
        ED_24_FAULT->setObjectName(QString::fromUtf8("ED_24_FAULT"));
        ED_24_FAULT->setGeometry(QRect(370, 670, 241, 21));
        ED_24_FAULT->setFrameShape(QFrame::Box);
        ED_24_FAULT->setFrameShadow(QFrame::Plain);
        ED_24_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_24 = new QLabel(centralWidget);
        ED_24->setObjectName(QString::fromUtf8("ED_24"));
        ED_24->setGeometry(QRect(370, 630, 241, 20));
        ED_24->setFont(font1);
        ED_24->setFrameShape(QFrame::Box);
        ED_24->setFrameShadow(QFrame::Plain);
        ED_24->setAlignment(Qt::AlignCenter);
        ED_28_STATE = new QLabel(centralWidget);
        ED_28_STATE->setObjectName(QString::fromUtf8("ED_28_STATE"));
        ED_28_STATE->setGeometry(QRect(370, 930, 241, 21));
        ED_28_STATE->setFrameShape(QFrame::Box);
        ED_28_STATE->setFrameShadow(QFrame::Plain);
        ED_28_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_18_FAULT = new QLabel(centralWidget);
        ED_18_FAULT->setObjectName(QString::fromUtf8("ED_18_FAULT"));
        ED_18_FAULT->setGeometry(QRect(30, 810, 241, 21));
        ED_18_FAULT->setFrameShape(QFrame::Box);
        ED_18_FAULT->setFrameShadow(QFrame::Plain);
        ED_18_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_92 = new QLabel(centralWidget);
        label_92->setObjectName(QString::fromUtf8("label_92"));
        label_92->setGeometry(QRect(270, 910, 51, 61));
        label_92->setFont(font2);
        label_92->setFrameShape(QFrame::Box);
        label_92->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        ED_20_FAULT = new QLabel(centralWidget);
        ED_20_FAULT->setObjectName(QString::fromUtf8("ED_20_FAULT"));
        ED_20_FAULT->setGeometry(QRect(30, 950, 241, 21));
        ED_20_FAULT->setFrameShape(QFrame::Box);
        ED_20_FAULT->setFrameShadow(QFrame::Plain);
        ED_20_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        groupBox_4 = new QGroupBox(centralWidget);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setEnabled(true);
        groupBox_4->setGeometry(QRect(360, 530, 311, 451));
        QPalette palette3;
        palette3.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette3.setBrush(QPalette::Active, QPalette::Dark, brush1);
        palette3.setBrush(QPalette::Active, QPalette::Text, brush);
        palette3.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::Dark, brush1);
        palette3.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette3.setBrush(QPalette::Disabled, QPalette::WindowText, brush);
        palette3.setBrush(QPalette::Disabled, QPalette::Dark, brush1);
        palette3.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette3.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        groupBox_4->setPalette(palette3);
        groupBox_4->setFont(font);
        groupBox_4->setAutoFillBackground(false);
        groupBox_4->setStyleSheet(QString::fromUtf8("color: rgb(125, 0, 62);"));
        groupBox_4->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        groupBox_4->setFlat(false);
        groupBox_4->setCheckable(false);
        ED_17 = new QLabel(centralWidget);
        ED_17->setObjectName(QString::fromUtf8("ED_17"));
        ED_17->setGeometry(QRect(30, 700, 241, 20));
        ED_17->setFont(font1);
        ED_17->setFrameShape(QFrame::Box);
        ED_17->setFrameShadow(QFrame::Plain);
        ED_17->setAlignment(Qt::AlignCenter);
        ED_27_FAULT = new QLabel(centralWidget);
        ED_27_FAULT->setObjectName(QString::fromUtf8("ED_27_FAULT"));
        ED_27_FAULT->setGeometry(QRect(370, 880, 241, 21));
        ED_27_FAULT->setFrameShape(QFrame::Box);
        ED_27_FAULT->setFrameShadow(QFrame::Plain);
        ED_27_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_96 = new QLabel(centralWidget);
        label_96->setObjectName(QString::fromUtf8("label_96"));
        label_96->setGeometry(QRect(610, 770, 51, 61));
        label_96->setFont(font2);
        label_96->setFrameShape(QFrame::Box);
        label_96->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        ED_15 = new QLabel(centralWidget);
        ED_15->setObjectName(QString::fromUtf8("ED_15"));
        ED_15->setGeometry(QRect(30, 560, 241, 20));
        ED_15->setFont(font1);
        ED_15->setFrameShape(QFrame::Box);
        ED_15->setFrameShadow(QFrame::Plain);
        ED_15->setAlignment(Qt::AlignCenter);
        ED_19_FAULT = new QLabel(centralWidget);
        ED_19_FAULT->setObjectName(QString::fromUtf8("ED_19_FAULT"));
        ED_19_FAULT->setGeometry(QRect(30, 880, 241, 21));
        ED_19_FAULT->setFrameShape(QFrame::Box);
        ED_19_FAULT->setFrameShadow(QFrame::Plain);
        ED_19_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_23_STATE = new QLabel(centralWidget);
        ED_23_STATE->setObjectName(QString::fromUtf8("ED_23_STATE"));
        ED_23_STATE->setGeometry(QRect(370, 580, 241, 21));
        ED_23_STATE->setFrameShape(QFrame::Box);
        ED_23_STATE->setFrameShadow(QFrame::Plain);
        ED_23_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_15_FAULT = new QLabel(centralWidget);
        ED_15_FAULT->setObjectName(QString::fromUtf8("ED_15_FAULT"));
        ED_15_FAULT->setGeometry(QRect(30, 600, 241, 21));
        ED_15_FAULT->setFrameShape(QFrame::Box);
        ED_15_FAULT->setFrameShadow(QFrame::Plain);
        ED_15_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_105 = new QLabel(centralWidget);
        label_105->setObjectName(QString::fromUtf8("label_105"));
        label_105->setGeometry(QRect(610, 910, 51, 61));
        label_105->setFont(font2);
        label_105->setFrameShape(QFrame::Box);
        label_105->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        ED_18_STATE = new QLabel(centralWidget);
        ED_18_STATE->setObjectName(QString::fromUtf8("ED_18_STATE"));
        ED_18_STATE->setGeometry(QRect(30, 790, 241, 21));
        ED_18_STATE->setFrameShape(QFrame::Box);
        ED_18_STATE->setFrameShadow(QFrame::Plain);
        ED_18_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_26_STATE = new QLabel(centralWidget);
        ED_26_STATE->setObjectName(QString::fromUtf8("ED_26_STATE"));
        ED_26_STATE->setGeometry(QRect(370, 790, 241, 21));
        ED_26_STATE->setFrameShape(QFrame::Box);
        ED_26_STATE->setFrameShadow(QFrame::Plain);
        ED_26_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_18 = new QLabel(centralWidget);
        ED_18->setObjectName(QString::fromUtf8("ED_18"));
        ED_18->setGeometry(QRect(30, 770, 241, 20));
        ED_18->setFont(font1);
        ED_18->setFrameShape(QFrame::Box);
        ED_18->setFrameShadow(QFrame::Plain);
        ED_18->setAlignment(Qt::AlignCenter);
        ED_17_FAULT = new QLabel(centralWidget);
        ED_17_FAULT->setObjectName(QString::fromUtf8("ED_17_FAULT"));
        ED_17_FAULT->setGeometry(QRect(30, 740, 241, 21));
        ED_17_FAULT->setFrameShape(QFrame::Box);
        ED_17_FAULT->setFrameShadow(QFrame::Plain);
        ED_17_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_16_STATE = new QLabel(centralWidget);
        ED_16_STATE->setObjectName(QString::fromUtf8("ED_16_STATE"));
        ED_16_STATE->setGeometry(QRect(30, 650, 241, 21));
        ED_16_STATE->setFrameShape(QFrame::Box);
        ED_16_STATE->setFrameShadow(QFrame::Plain);
        ED_16_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_24_STATE = new QLabel(centralWidget);
        ED_24_STATE->setObjectName(QString::fromUtf8("ED_24_STATE"));
        ED_24_STATE->setGeometry(QRect(370, 650, 241, 21));
        ED_24_STATE->setFrameShape(QFrame::Box);
        ED_24_STATE->setFrameShadow(QFrame::Plain);
        ED_24_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_26_FAULT = new QLabel(centralWidget);
        ED_26_FAULT->setObjectName(QString::fromUtf8("ED_26_FAULT"));
        ED_26_FAULT->setGeometry(QRect(370, 810, 241, 21));
        ED_26_FAULT->setFrameShape(QFrame::Box);
        ED_26_FAULT->setFrameShadow(QFrame::Plain);
        ED_26_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_27 = new QLabel(centralWidget);
        ED_27->setObjectName(QString::fromUtf8("ED_27"));
        ED_27->setGeometry(QRect(370, 840, 241, 20));
        ED_27->setFont(font1);
        ED_27->setFrameShape(QFrame::Box);
        ED_27->setFrameShadow(QFrame::Plain);
        ED_27->setAlignment(Qt::AlignCenter);
        ED_28_FAULT = new QLabel(centralWidget);
        ED_28_FAULT->setObjectName(QString::fromUtf8("ED_28_FAULT"));
        ED_28_FAULT->setGeometry(QRect(370, 950, 241, 21));
        ED_28_FAULT->setFrameShape(QFrame::Box);
        ED_28_FAULT->setFrameShadow(QFrame::Plain);
        ED_28_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_28 = new QLabel(centralWidget);
        ED_28->setObjectName(QString::fromUtf8("ED_28"));
        ED_28->setGeometry(QRect(370, 910, 241, 20));
        ED_28->setFont(font1);
        ED_28->setFrameShape(QFrame::Box);
        ED_28->setFrameShadow(QFrame::Plain);
        ED_28->setAlignment(Qt::AlignCenter);
        ED_25 = new QLabel(centralWidget);
        ED_25->setObjectName(QString::fromUtf8("ED_25"));
        ED_25->setGeometry(QRect(370, 700, 241, 20));
        ED_25->setFont(font1);
        ED_25->setFrameShape(QFrame::Box);
        ED_25->setFrameShadow(QFrame::Plain);
        ED_25->setAlignment(Qt::AlignCenter);
        ED_19 = new QLabel(centralWidget);
        ED_19->setObjectName(QString::fromUtf8("ED_19"));
        ED_19->setGeometry(QRect(30, 840, 241, 20));
        ED_19->setFont(font1);
        ED_19->setFrameShape(QFrame::Box);
        ED_19->setFrameShadow(QFrame::Plain);
        ED_19->setAlignment(Qt::AlignCenter);
        ED_25_FAULT = new QLabel(centralWidget);
        ED_25_FAULT->setObjectName(QString::fromUtf8("ED_25_FAULT"));
        ED_25_FAULT->setGeometry(QRect(370, 740, 241, 21));
        ED_25_FAULT->setFrameShape(QFrame::Box);
        ED_25_FAULT->setFrameShadow(QFrame::Plain);
        ED_25_FAULT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ED_27_STATE = new QLabel(centralWidget);
        ED_27_STATE->setObjectName(QString::fromUtf8("ED_27_STATE"));
        ED_27_STATE->setGeometry(QRect(370, 860, 241, 21));
        ED_27_STATE->setFrameShape(QFrame::Box);
        ED_27_STATE->setFrameShadow(QFrame::Plain);
        ED_27_STATE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(271, 190, 50, 21));
        pushButton_2->setFont(font5);
        pushButton_2->setFocusPolicy(Qt::NoFocus);
        pushButton_2->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_2->setDefault(false);
        pushButton_2->setFlat(false);
        com_2 = new QLabel(centralWidget);
        com_2->setObjectName(QString::fromUtf8("com_2"));
        com_2->setGeometry(QRect(270, 150, 51, 20));
        QFont font7;
        font7.setBold(true);
        font7.setWeight(75);
        com_2->setFont(font7);
        com_2->setFrameShape(QFrame::Box);
        com_2->setAlignment(Qt::AlignCenter);
        comboBox_2 = new QComboBox(centralWidget);
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(270, 169, 53, 22));
        comboBox_2->setFont(font3);
        comboBox_2->setMouseTracking(false);
        comboBox_2->setFocusPolicy(Qt::NoFocus);
        comboBox_2->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_2->setLayoutDirection(Qt::LeftToRight);
        comboBox_2->setEditable(false);
        comboBox_2->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_2->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_2->setFrame(true);
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(271, 260, 50, 21));
        pushButton_3->setFont(font5);
        pushButton_3->setFocusPolicy(Qt::NoFocus);
        pushButton_3->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_3->setDefault(false);
        pushButton_3->setFlat(false);
        comboBox_3 = new QComboBox(centralWidget);
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));
        comboBox_3->setGeometry(QRect(270, 239, 53, 22));
        comboBox_3->setFont(font3);
        comboBox_3->setMouseTracking(false);
        comboBox_3->setFocusPolicy(Qt::NoFocus);
        comboBox_3->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_3->setLayoutDirection(Qt::LeftToRight);
        comboBox_3->setEditable(false);
        comboBox_3->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_3->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_3->setFrame(true);
        com_3 = new QLabel(centralWidget);
        com_3->setObjectName(QString::fromUtf8("com_3"));
        com_3->setGeometry(QRect(270, 220, 51, 20));
        com_3->setFont(font7);
        com_3->setFrameShape(QFrame::Box);
        com_3->setAlignment(Qt::AlignCenter);
        com_4 = new QLabel(centralWidget);
        com_4->setObjectName(QString::fromUtf8("com_4"));
        com_4->setGeometry(QRect(270, 290, 51, 20));
        com_4->setFont(font7);
        com_4->setFrameShape(QFrame::Box);
        com_4->setAlignment(Qt::AlignCenter);
        comboBox_4 = new QComboBox(centralWidget);
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));
        comboBox_4->setGeometry(QRect(270, 309, 53, 22));
        comboBox_4->setFont(font3);
        comboBox_4->setMouseTracking(false);
        comboBox_4->setFocusPolicy(Qt::NoFocus);
        comboBox_4->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_4->setLayoutDirection(Qt::LeftToRight);
        comboBox_4->setEditable(false);
        comboBox_4->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_4->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_4->setFrame(true);
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(271, 330, 50, 21));
        pushButton_4->setFont(font5);
        pushButton_4->setFocusPolicy(Qt::NoFocus);
        pushButton_4->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_4->setDefault(false);
        pushButton_4->setFlat(false);
        pushButton_5 = new QPushButton(centralWidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(271, 400, 50, 21));
        pushButton_5->setFont(font5);
        pushButton_5->setFocusPolicy(Qt::NoFocus);
        pushButton_5->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_5->setDefault(false);
        pushButton_5->setFlat(false);
        com_5 = new QLabel(centralWidget);
        com_5->setObjectName(QString::fromUtf8("com_5"));
        com_5->setGeometry(QRect(270, 360, 51, 20));
        com_5->setFont(font7);
        com_5->setFrameShape(QFrame::Box);
        com_5->setAlignment(Qt::AlignCenter);
        comboBox_5 = new QComboBox(centralWidget);
        comboBox_5->setObjectName(QString::fromUtf8("comboBox_5"));
        comboBox_5->setGeometry(QRect(270, 379, 53, 22));
        comboBox_5->setFont(font3);
        comboBox_5->setMouseTracking(false);
        comboBox_5->setFocusPolicy(Qt::NoFocus);
        comboBox_5->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_5->setLayoutDirection(Qt::LeftToRight);
        comboBox_5->setEditable(false);
        comboBox_5->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_5->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_5->setFrame(true);
        com_6 = new QLabel(centralWidget);
        com_6->setObjectName(QString::fromUtf8("com_6"));
        com_6->setGeometry(QRect(270, 430, 51, 20));
        com_6->setFont(font7);
        com_6->setFrameShape(QFrame::Box);
        com_6->setAlignment(Qt::AlignCenter);
        comboBox_6 = new QComboBox(centralWidget);
        comboBox_6->setObjectName(QString::fromUtf8("comboBox_6"));
        comboBox_6->setGeometry(QRect(270, 449, 53, 22));
        comboBox_6->setFont(font3);
        comboBox_6->setMouseTracking(false);
        comboBox_6->setFocusPolicy(Qt::NoFocus);
        comboBox_6->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_6->setLayoutDirection(Qt::LeftToRight);
        comboBox_6->setEditable(false);
        comboBox_6->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_6->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_6->setFrame(true);
        pushButton_6 = new QPushButton(centralWidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(271, 470, 50, 21));
        pushButton_6->setFont(font5);
        pushButton_6->setFocusPolicy(Qt::NoFocus);
        pushButton_6->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_6->setDefault(false);
        pushButton_6->setFlat(false);
        comboBox_14 = new QComboBox(centralWidget);
        comboBox_14->setObjectName(QString::fromUtf8("comboBox_14"));
        comboBox_14->setGeometry(QRect(270, 649, 53, 22));
        comboBox_14->setFont(font3);
        comboBox_14->setMouseTracking(false);
        comboBox_14->setFocusPolicy(Qt::NoFocus);
        comboBox_14->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_14->setLayoutDirection(Qt::LeftToRight);
        comboBox_14->setEditable(false);
        comboBox_14->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_14->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_14->setFrame(true);
        com_13 = new QLabel(centralWidget);
        com_13->setObjectName(QString::fromUtf8("com_13"));
        com_13->setGeometry(QRect(270, 560, 51, 20));
        com_13->setFont(font7);
        com_13->setFrameShape(QFrame::Box);
        com_13->setAlignment(Qt::AlignCenter);
        com_18 = new QLabel(centralWidget);
        com_18->setObjectName(QString::fromUtf8("com_18"));
        com_18->setGeometry(QRect(270, 910, 51, 20));
        com_18->setFont(font7);
        com_18->setStyleSheet(QString::fromUtf8(""));
        com_18->setFrameShape(QFrame::Box);
        com_18->setAlignment(Qt::AlignCenter);
        comboBox_15 = new QComboBox(centralWidget);
        comboBox_15->setObjectName(QString::fromUtf8("comboBox_15"));
        comboBox_15->setGeometry(QRect(270, 719, 53, 22));
        comboBox_15->setFont(font3);
        comboBox_15->setMouseTracking(false);
        comboBox_15->setFocusPolicy(Qt::NoFocus);
        comboBox_15->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_15->setLayoutDirection(Qt::LeftToRight);
        comboBox_15->setEditable(false);
        comboBox_15->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_15->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_15->setFrame(true);
        com_17 = new QLabel(centralWidget);
        com_17->setObjectName(QString::fromUtf8("com_17"));
        com_17->setGeometry(QRect(270, 840, 51, 20));
        com_17->setFont(font7);
        com_17->setFrameShape(QFrame::Box);
        com_17->setAlignment(Qt::AlignCenter);
        com_15 = new QLabel(centralWidget);
        com_15->setObjectName(QString::fromUtf8("com_15"));
        com_15->setGeometry(QRect(270, 700, 51, 20));
        com_15->setFont(font7);
        com_15->setFrameShape(QFrame::Box);
        com_15->setAlignment(Qt::AlignCenter);
        com_16 = new QLabel(centralWidget);
        com_16->setObjectName(QString::fromUtf8("com_16"));
        com_16->setGeometry(QRect(270, 770, 51, 20));
        com_16->setFont(font7);
        com_16->setFrameShape(QFrame::Box);
        com_16->setAlignment(Qt::AlignCenter);
        comboBox_16 = new QComboBox(centralWidget);
        comboBox_16->setObjectName(QString::fromUtf8("comboBox_16"));
        comboBox_16->setGeometry(QRect(270, 789, 53, 22));
        comboBox_16->setFont(font3);
        comboBox_16->setMouseTracking(false);
        comboBox_16->setFocusPolicy(Qt::NoFocus);
        comboBox_16->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_16->setLayoutDirection(Qt::LeftToRight);
        comboBox_16->setEditable(false);
        comboBox_16->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_16->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_16->setFrame(true);
        comboBox_17 = new QComboBox(centralWidget);
        comboBox_17->setObjectName(QString::fromUtf8("comboBox_17"));
        comboBox_17->setGeometry(QRect(270, 859, 53, 22));
        comboBox_17->setFont(font3);
        comboBox_17->setMouseTracking(false);
        comboBox_17->setFocusPolicy(Qt::NoFocus);
        comboBox_17->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_17->setLayoutDirection(Qt::LeftToRight);
        comboBox_17->setEditable(false);
        comboBox_17->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_17->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_17->setFrame(true);
        pushButton_14 = new QPushButton(centralWidget);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));
        pushButton_14->setGeometry(QRect(271, 670, 50, 21));
        pushButton_14->setFont(font5);
        pushButton_14->setFocusPolicy(Qt::NoFocus);
        pushButton_14->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_14->setDefault(false);
        pushButton_14->setFlat(false);
        pushButton_18 = new QPushButton(centralWidget);
        pushButton_18->setObjectName(QString::fromUtf8("pushButton_18"));
        pushButton_18->setGeometry(QRect(271, 950, 50, 21));
        pushButton_18->setFont(font5);
        pushButton_18->setFocusPolicy(Qt::NoFocus);
        pushButton_18->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_18->setDefault(false);
        pushButton_18->setFlat(false);
        comboBox_18 = new QComboBox(centralWidget);
        comboBox_18->setObjectName(QString::fromUtf8("comboBox_18"));
        comboBox_18->setGeometry(QRect(270, 929, 53, 22));
        comboBox_18->setFont(font3);
        comboBox_18->setMouseTracking(false);
        comboBox_18->setFocusPolicy(Qt::NoFocus);
        comboBox_18->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_18->setLayoutDirection(Qt::LeftToRight);
        comboBox_18->setEditable(false);
        comboBox_18->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_18->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_18->setFrame(true);
        pushButton_16 = new QPushButton(centralWidget);
        pushButton_16->setObjectName(QString::fromUtf8("pushButton_16"));
        pushButton_16->setGeometry(QRect(271, 810, 50, 21));
        pushButton_16->setFont(font5);
        pushButton_16->setFocusPolicy(Qt::NoFocus);
        pushButton_16->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_16->setDefault(false);
        pushButton_16->setFlat(false);
        com_14 = new QLabel(centralWidget);
        com_14->setObjectName(QString::fromUtf8("com_14"));
        com_14->setGeometry(QRect(270, 630, 51, 20));
        com_14->setFont(font7);
        com_14->setFrameShape(QFrame::Box);
        com_14->setAlignment(Qt::AlignCenter);
        pushButton_13 = new QPushButton(centralWidget);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));
        pushButton_13->setGeometry(QRect(271, 600, 50, 21));
        pushButton_13->setFont(font5);
        pushButton_13->setFocusPolicy(Qt::NoFocus);
        pushButton_13->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_13->setDefault(false);
        pushButton_13->setFlat(false);
        pushButton_15 = new QPushButton(centralWidget);
        pushButton_15->setObjectName(QString::fromUtf8("pushButton_15"));
        pushButton_15->setGeometry(QRect(271, 740, 50, 21));
        pushButton_15->setFont(font5);
        pushButton_15->setFocusPolicy(Qt::NoFocus);
        pushButton_15->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_15->setDefault(false);
        pushButton_15->setFlat(false);
        comboBox_13 = new QComboBox(centralWidget);
        comboBox_13->setObjectName(QString::fromUtf8("comboBox_13"));
        comboBox_13->setGeometry(QRect(270, 579, 53, 22));
        comboBox_13->setFont(font3);
        comboBox_13->setMouseTracking(false);
        comboBox_13->setFocusPolicy(Qt::NoFocus);
        comboBox_13->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_13->setLayoutDirection(Qt::LeftToRight);
        comboBox_13->setEditable(false);
        comboBox_13->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_13->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_13->setFrame(true);
        pushButton_17 = new QPushButton(centralWidget);
        pushButton_17->setObjectName(QString::fromUtf8("pushButton_17"));
        pushButton_17->setGeometry(QRect(271, 880, 50, 21));
        pushButton_17->setFont(font5);
        pushButton_17->setFocusPolicy(Qt::NoFocus);
        pushButton_17->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_17->setDefault(false);
        pushButton_17->setFlat(false);
        comboBox_22 = new QComboBox(centralWidget);
        comboBox_22->setObjectName(QString::fromUtf8("comboBox_22"));
        comboBox_22->setGeometry(QRect(610, 789, 53, 22));
        comboBox_22->setFont(font3);
        comboBox_22->setMouseTracking(false);
        comboBox_22->setFocusPolicy(Qt::NoFocus);
        comboBox_22->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_22->setLayoutDirection(Qt::LeftToRight);
        comboBox_22->setEditable(false);
        comboBox_22->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_22->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_22->setFrame(true);
        pushButton_23 = new QPushButton(centralWidget);
        pushButton_23->setObjectName(QString::fromUtf8("pushButton_23"));
        pushButton_23->setGeometry(QRect(611, 880, 50, 21));
        pushButton_23->setFont(font5);
        pushButton_23->setFocusPolicy(Qt::NoFocus);
        pushButton_23->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_23->setDefault(false);
        pushButton_23->setFlat(false);
        com_22 = new QLabel(centralWidget);
        com_22->setObjectName(QString::fromUtf8("com_22"));
        com_22->setGeometry(QRect(610, 770, 51, 20));
        com_22->setFont(font7);
        com_22->setFrameShape(QFrame::Box);
        com_22->setAlignment(Qt::AlignCenter);
        com_23 = new QLabel(centralWidget);
        com_23->setObjectName(QString::fromUtf8("com_23"));
        com_23->setGeometry(QRect(610, 840, 51, 20));
        com_23->setFont(font7);
        com_23->setFrameShape(QFrame::Box);
        com_23->setAlignment(Qt::AlignCenter);
        com_21 = new QLabel(centralWidget);
        com_21->setObjectName(QString::fromUtf8("com_21"));
        com_21->setGeometry(QRect(610, 700, 51, 20));
        com_21->setFont(font7);
        com_21->setFrameShape(QFrame::Box);
        com_21->setAlignment(Qt::AlignCenter);
        com_24 = new QLabel(centralWidget);
        com_24->setObjectName(QString::fromUtf8("com_24"));
        com_24->setGeometry(QRect(610, 910, 51, 20));
        com_24->setFont(font7);
        com_24->setFrameShape(QFrame::Box);
        com_24->setAlignment(Qt::AlignCenter);
        pushButton_24 = new QPushButton(centralWidget);
        pushButton_24->setObjectName(QString::fromUtf8("pushButton_24"));
        pushButton_24->setGeometry(QRect(611, 950, 50, 21));
        pushButton_24->setFont(font5);
        pushButton_24->setFocusPolicy(Qt::NoFocus);
        pushButton_24->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_24->setDefault(false);
        pushButton_24->setFlat(false);
        comboBox_19 = new QComboBox(centralWidget);
        comboBox_19->setObjectName(QString::fromUtf8("comboBox_19"));
        comboBox_19->setGeometry(QRect(610, 579, 53, 22));
        comboBox_19->setFont(font3);
        comboBox_19->setMouseTracking(false);
        comboBox_19->setFocusPolicy(Qt::NoFocus);
        comboBox_19->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_19->setLayoutDirection(Qt::LeftToRight);
        comboBox_19->setEditable(false);
        comboBox_19->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_19->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_19->setFrame(true);
        pushButton_21 = new QPushButton(centralWidget);
        pushButton_21->setObjectName(QString::fromUtf8("pushButton_21"));
        pushButton_21->setGeometry(QRect(611, 740, 50, 21));
        pushButton_21->setFont(font5);
        pushButton_21->setFocusPolicy(Qt::NoFocus);
        pushButton_21->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_21->setDefault(false);
        pushButton_21->setFlat(false);
        comboBox_23 = new QComboBox(centralWidget);
        comboBox_23->setObjectName(QString::fromUtf8("comboBox_23"));
        comboBox_23->setGeometry(QRect(610, 859, 53, 22));
        comboBox_23->setFont(font3);
        comboBox_23->setMouseTracking(false);
        comboBox_23->setFocusPolicy(Qt::NoFocus);
        comboBox_23->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_23->setLayoutDirection(Qt::LeftToRight);
        comboBox_23->setEditable(false);
        comboBox_23->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_23->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_23->setFrame(true);
        com_20 = new QLabel(centralWidget);
        com_20->setObjectName(QString::fromUtf8("com_20"));
        com_20->setGeometry(QRect(610, 630, 51, 20));
        com_20->setFont(font7);
        com_20->setFrameShape(QFrame::Box);
        com_20->setAlignment(Qt::AlignCenter);
        pushButton_20 = new QPushButton(centralWidget);
        pushButton_20->setObjectName(QString::fromUtf8("pushButton_20"));
        pushButton_20->setGeometry(QRect(611, 670, 50, 21));
        pushButton_20->setFont(font5);
        pushButton_20->setFocusPolicy(Qt::NoFocus);
        pushButton_20->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_20->setDefault(false);
        pushButton_20->setFlat(false);
        pushButton_19 = new QPushButton(centralWidget);
        pushButton_19->setObjectName(QString::fromUtf8("pushButton_19"));
        pushButton_19->setGeometry(QRect(611, 600, 50, 21));
        pushButton_19->setFont(font5);
        pushButton_19->setFocusPolicy(Qt::NoFocus);
        pushButton_19->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_19->setDefault(false);
        pushButton_19->setFlat(false);
        comboBox_20 = new QComboBox(centralWidget);
        comboBox_20->setObjectName(QString::fromUtf8("comboBox_20"));
        comboBox_20->setGeometry(QRect(610, 649, 53, 22));
        comboBox_20->setFont(font3);
        comboBox_20->setMouseTracking(false);
        comboBox_20->setFocusPolicy(Qt::NoFocus);
        comboBox_20->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_20->setLayoutDirection(Qt::LeftToRight);
        comboBox_20->setEditable(false);
        comboBox_20->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_20->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_20->setFrame(true);
        com_19 = new QLabel(centralWidget);
        com_19->setObjectName(QString::fromUtf8("com_19"));
        com_19->setGeometry(QRect(610, 560, 51, 20));
        com_19->setFont(font7);
        com_19->setFrameShape(QFrame::Box);
        com_19->setAlignment(Qt::AlignCenter);
        comboBox_21 = new QComboBox(centralWidget);
        comboBox_21->setObjectName(QString::fromUtf8("comboBox_21"));
        comboBox_21->setGeometry(QRect(610, 719, 53, 22));
        comboBox_21->setFont(font3);
        comboBox_21->setMouseTracking(false);
        comboBox_21->setFocusPolicy(Qt::NoFocus);
        comboBox_21->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_21->setLayoutDirection(Qt::LeftToRight);
        comboBox_21->setEditable(false);
        comboBox_21->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_21->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_21->setFrame(true);
        comboBox_24 = new QComboBox(centralWidget);
        comboBox_24->setObjectName(QString::fromUtf8("comboBox_24"));
        comboBox_24->setGeometry(QRect(610, 929, 53, 22));
        comboBox_24->setFont(font3);
        comboBox_24->setMouseTracking(false);
        comboBox_24->setFocusPolicy(Qt::NoFocus);
        comboBox_24->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_24->setLayoutDirection(Qt::LeftToRight);
        comboBox_24->setEditable(false);
        comboBox_24->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_24->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_24->setFrame(true);
        pushButton_22 = new QPushButton(centralWidget);
        pushButton_22->setObjectName(QString::fromUtf8("pushButton_22"));
        pushButton_22->setGeometry(QRect(611, 810, 50, 21));
        pushButton_22->setFont(font5);
        pushButton_22->setFocusPolicy(Qt::NoFocus);
        pushButton_22->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_22->setDefault(false);
        pushButton_22->setFlat(false);
        label_37 = new QLabel(centralWidget);
        label_37->setObjectName(QString::fromUtf8("label_37"));
        label_37->setGeometry(QRect(610, 150, 51, 61));
        label_37->setFont(font2);
        label_37->setFrameShape(QFrame::Box);
        label_37->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_52 = new QLabel(centralWidget);
        label_52->setObjectName(QString::fromUtf8("label_52"));
        label_52->setGeometry(QRect(610, 80, 51, 61));
        label_52->setFont(font2);
        label_52->setFrameShape(QFrame::Box);
        label_52->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_58 = new QLabel(centralWidget);
        label_58->setObjectName(QString::fromUtf8("label_58"));
        label_58->setGeometry(QRect(610, 360, 51, 61));
        label_58->setFont(font2);
        label_58->setFrameShape(QFrame::Box);
        label_58->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_54 = new QLabel(centralWidget);
        label_54->setObjectName(QString::fromUtf8("label_54"));
        label_54->setGeometry(QRect(610, 290, 51, 61));
        label_54->setFont(font2);
        label_54->setFrameShape(QFrame::Box);
        label_54->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_60 = new QLabel(centralWidget);
        label_60->setObjectName(QString::fromUtf8("label_60"));
        label_60->setGeometry(QRect(610, 220, 51, 61));
        label_60->setFont(font2);
        label_60->setFrameShape(QFrame::Box);
        label_60->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_50 = new QLabel(centralWidget);
        label_50->setObjectName(QString::fromUtf8("label_50"));
        label_50->setGeometry(QRect(610, 430, 51, 61));
        label_50->setFont(font2);
        label_50->setFrameShape(QFrame::Box);
        label_50->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        com_9 = new QLabel(centralWidget);
        com_9->setObjectName(QString::fromUtf8("com_9"));
        com_9->setGeometry(QRect(610, 220, 51, 22));
        com_9->setFont(font7);
        com_9->setFrameShape(QFrame::Box);
        com_9->setAlignment(Qt::AlignCenter);
        com_12 = new QLabel(centralWidget);
        com_12->setObjectName(QString::fromUtf8("com_12"));
        com_12->setGeometry(QRect(610, 430, 51, 20));
        com_12->setFont(font7);
        com_12->setFrameShape(QFrame::Box);
        com_12->setAlignment(Qt::AlignCenter);
        pushButton_7 = new QPushButton(centralWidget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(611, 120, 50, 21));
        pushButton_7->setFont(font5);
        pushButton_7->setFocusPolicy(Qt::NoFocus);
        pushButton_7->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_7->setDefault(false);
        pushButton_7->setFlat(false);
        com_10 = new QLabel(centralWidget);
        com_10->setObjectName(QString::fromUtf8("com_10"));
        com_10->setGeometry(QRect(610, 290, 51, 20));
        com_10->setFont(font7);
        com_10->setFrameShape(QFrame::Box);
        com_10->setAlignment(Qt::AlignCenter);
        comboBox_12 = new QComboBox(centralWidget);
        comboBox_12->setObjectName(QString::fromUtf8("comboBox_12"));
        comboBox_12->setGeometry(QRect(610, 449, 53, 22));
        comboBox_12->setFont(font3);
        comboBox_12->setMouseTracking(false);
        comboBox_12->setFocusPolicy(Qt::NoFocus);
        comboBox_12->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_12->setLayoutDirection(Qt::LeftToRight);
        comboBox_12->setEditable(false);
        comboBox_12->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_12->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_12->setFrame(true);
        comboBox_11 = new QComboBox(centralWidget);
        comboBox_11->setObjectName(QString::fromUtf8("comboBox_11"));
        comboBox_11->setGeometry(QRect(610, 379, 53, 22));
        comboBox_11->setFont(font3);
        comboBox_11->setMouseTracking(false);
        comboBox_11->setFocusPolicy(Qt::NoFocus);
        comboBox_11->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_11->setLayoutDirection(Qt::LeftToRight);
        comboBox_11->setEditable(false);
        comboBox_11->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_11->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_11->setFrame(true);
        pushButton_11 = new QPushButton(centralWidget);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setGeometry(QRect(610, 400, 50, 21));
        pushButton_11->setFont(font5);
        pushButton_11->setFocusPolicy(Qt::NoFocus);
        pushButton_11->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_11->setDefault(false);
        pushButton_11->setFlat(false);
        pushButton_9 = new QPushButton(centralWidget);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(611, 260, 50, 21));
        pushButton_9->setFont(font5);
        pushButton_9->setFocusPolicy(Qt::NoFocus);
        pushButton_9->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_9->setDefault(false);
        pushButton_9->setFlat(false);
        com_7 = new QLabel(centralWidget);
        com_7->setObjectName(QString::fromUtf8("com_7"));
        com_7->setGeometry(QRect(610, 80, 51, 20));
        com_7->setFont(font7);
        com_7->setFrameShape(QFrame::Box);
        com_7->setAlignment(Qt::AlignCenter);
        pushButton_8 = new QPushButton(centralWidget);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(611, 190, 50, 21));
        pushButton_8->setFont(font5);
        pushButton_8->setFocusPolicy(Qt::NoFocus);
        pushButton_8->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_8->setDefault(false);
        pushButton_8->setFlat(false);
        pushButton_10 = new QPushButton(centralWidget);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setGeometry(QRect(611, 330, 50, 21));
        pushButton_10->setFont(font5);
        pushButton_10->setFocusPolicy(Qt::NoFocus);
        pushButton_10->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_10->setDefault(false);
        pushButton_10->setFlat(false);
        comboBox_7 = new QComboBox(centralWidget);
        comboBox_7->setObjectName(QString::fromUtf8("comboBox_7"));
        comboBox_7->setGeometry(QRect(610, 99, 53, 22));
        comboBox_7->setFont(font3);
        comboBox_7->setMouseTracking(false);
        comboBox_7->setFocusPolicy(Qt::NoFocus);
        comboBox_7->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_7->setLayoutDirection(Qt::LeftToRight);
        comboBox_7->setEditable(false);
        comboBox_7->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_7->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_7->setFrame(true);
        com_8 = new QLabel(centralWidget);
        com_8->setObjectName(QString::fromUtf8("com_8"));
        com_8->setGeometry(QRect(610, 150, 51, 20));
        com_8->setFont(font7);
        com_8->setFrameShape(QFrame::Box);
        com_8->setAlignment(Qt::AlignCenter);
        comboBox_10 = new QComboBox(centralWidget);
        comboBox_10->setObjectName(QString::fromUtf8("comboBox_10"));
        comboBox_10->setGeometry(QRect(610, 309, 53, 22));
        comboBox_10->setFont(font3);
        comboBox_10->setMouseTracking(false);
        comboBox_10->setFocusPolicy(Qt::NoFocus);
        comboBox_10->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_10->setLayoutDirection(Qt::LeftToRight);
        comboBox_10->setEditable(false);
        comboBox_10->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_10->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_10->setFrame(true);
        pushButton_12 = new QPushButton(centralWidget);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setGeometry(QRect(611, 470, 50, 21));
        pushButton_12->setFont(font5);
        pushButton_12->setFocusPolicy(Qt::NoFocus);
        pushButton_12->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_12->setDefault(false);
        pushButton_12->setFlat(false);
        comboBox_8 = new QComboBox(centralWidget);
        comboBox_8->setObjectName(QString::fromUtf8("comboBox_8"));
        comboBox_8->setGeometry(QRect(610, 169, 53, 22));
        comboBox_8->setFont(font3);
        comboBox_8->setMouseTracking(false);
        comboBox_8->setFocusPolicy(Qt::NoFocus);
        comboBox_8->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_8->setLayoutDirection(Qt::LeftToRight);
        comboBox_8->setEditable(false);
        comboBox_8->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_8->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_8->setFrame(true);
        com_11 = new QLabel(centralWidget);
        com_11->setObjectName(QString::fromUtf8("com_11"));
        com_11->setGeometry(QRect(610, 360, 51, 20));
        com_11->setFont(font7);
        com_11->setFrameShape(QFrame::Box);
        com_11->setAlignment(Qt::AlignCenter);
        comboBox_9 = new QComboBox(centralWidget);
        comboBox_9->setObjectName(QString::fromUtf8("comboBox_9"));
        comboBox_9->setGeometry(QRect(610, 239, 53, 22));
        comboBox_9->setFont(font3);
        comboBox_9->setMouseTracking(false);
        comboBox_9->setFocusPolicy(Qt::NoFocus);
        comboBox_9->setContextMenuPolicy(Qt::DefaultContextMenu);
        comboBox_9->setLayoutDirection(Qt::LeftToRight);
        comboBox_9->setEditable(false);
        comboBox_9->setInsertPolicy(QComboBox::InsertAtBottom);
        comboBox_9->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
        comboBox_9->setFrame(true);
        dateTimeEdit = new QDateTimeEdit(centralWidget);
        dateTimeEdit->setObjectName(QString::fromUtf8("dateTimeEdit"));
        dateTimeEdit->setGeometry(QRect(515, 10, 161, 25));
        QFont font8;
        font8.setBold(true);
        font8.setItalic(true);
        font8.setWeight(75);
        dateTimeEdit->setFont(font8);
        dateTimeEdit->setFocusPolicy(Qt::NoFocus);
        dateTimeEdit->setContextMenuPolicy(Qt::NoContextMenu);
        dateTimeEdit->setWrapping(false);
        dateTimeEdit->setFrame(false);
        dateTimeEdit->setReadOnly(true);
        dateTimeEdit->setButtonSymbols(QAbstractSpinBox::NoButtons);
        dateTimeEdit->setMaximumDateTime(QDateTime(QDate(2099, 12, 31), QTime(23, 59, 59)));
        dateTimeEdit->setMaximumDate(QDate(2099, 12, 31));
        dateTimeEdit->setMinimumDate(QDate(1996, 9, 20));
        dateTimeEdit->setCurrentSection(QDateTimeEdit::DaySection);
        dateTimeEdit->setCalendarPopup(false);
        info = new QLabel(centralWidget);
        info->setObjectName(QString::fromUtf8("info"));
        info->setGeometry(QRect(20, 985, 651, 21));
        info->setFont(font1);
        info->setFrameShape(QFrame::Box);
        info->setScaledContents(true);
        lstimag = new QLabel(centralWidget);
        lstimag->setObjectName(QString::fromUtf8("lstimag"));
        lstimag->setGeometry(QRect(19, 5, 151, 41));
        lstimag->setFrameShadow(QFrame::Plain);
        lstimag->setTextFormat(Qt::AutoText);
        lstimag->setPixmap(QPixmap(QString::fromUtf8(":/imag/lst.png")));
        lstimag->setScaledContents(true);
        groupBox_5 = new QGroupBox(centralWidget);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setGeometry(QRect(20, 1010, 653, 81));
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::WindowText, brush1);
        palette4.setBrush(QPalette::Active, QPalette::Dark, brush1);
        palette4.setBrush(QPalette::Active, QPalette::Mid, brush1);
        palette4.setBrush(QPalette::Active, QPalette::Text, brush1);
        palette4.setBrush(QPalette::Active, QPalette::ButtonText, brush1);
        palette4.setBrush(QPalette::Inactive, QPalette::WindowText, brush1);
        palette4.setBrush(QPalette::Inactive, QPalette::Dark, brush1);
        palette4.setBrush(QPalette::Inactive, QPalette::Mid, brush1);
        palette4.setBrush(QPalette::Inactive, QPalette::Text, brush1);
        palette4.setBrush(QPalette::Inactive, QPalette::ButtonText, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::Dark, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::Mid, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::Text, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        groupBox_5->setPalette(palette4);
        QFont font9;
        font9.setFamily(QString::fromUtf8("URW Gothic L"));
        font9.setPointSize(10);
        font9.setBold(true);
        font9.setItalic(true);
        font9.setWeight(75);
        groupBox_5->setFont(font9);
        groupBox_5->setStyleSheet(QString::fromUtf8("font: 75 bold oblique 10pt \"URW Gothic L\";\n"
""));
        fault_screen_button = new QPushButton(groupBox_5);
        fault_screen_button->setObjectName(QString::fromUtf8("fault_screen_button"));
        fault_screen_button->setGeometry(QRect(20, 21, 115, 21));
        QFont font10;
        font10.setFamily(QString::fromUtf8("Sans Serif"));
        font10.setPointSize(9);
        font10.setBold(false);
        font10.setItalic(false);
        font10.setWeight(50);
        fault_screen_button->setFont(font10);
        fault_screen_button->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"background-color: rgb(227, 227, 227);"));
        fault_screen_button->setFlat(false);
        log_finder_button = new QPushButton(groupBox_5);
        log_finder_button->setObjectName(QString::fromUtf8("log_finder_button"));
        log_finder_button->setGeometry(QRect(185, 21, 115, 21));
        log_finder_button->setFont(font10);
        log_finder_button->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"background-color: rgb(227, 227, 227);"));
        log_finder_button->setFlat(false);
        usb_mount = new QPushButton(groupBox_5);
        usb_mount->setObjectName(QString::fromUtf8("usb_mount"));
        usb_mount->setGeometry(QRect(185, 51, 115, 21));
        usb_mount->setFont(font10);
        usb_mount->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"background-color: rgb(227, 227, 227);"));
        usb_unmount = new QPushButton(groupBox_5);
        usb_unmount->setObjectName(QString::fromUtf8("usb_unmount"));
        usb_unmount->setGeometry(QRect(350, 51, 115, 21));
        usb_unmount->setFont(font10);
        usb_unmount->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"background-color: rgb(227, 227, 227);"));
        terminal = new QPushButton(groupBox_5);
        terminal->setObjectName(QString::fromUtf8("terminal"));
        terminal->setGeometry(QRect(515, 21, 115, 21));
        terminal->setFont(font10);
        terminal->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"background-color: rgb(227, 227, 227);"));
        bag_finder_bt = new QPushButton(groupBox_5);
        bag_finder_bt->setObjectName(QString::fromUtf8("bag_finder_bt"));
        bag_finder_bt->setGeometry(QRect(350, 21, 115, 21));
        bag_finder_bt->setFont(font10);
        bag_finder_bt->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"background-color: rgb(227, 227, 227);"));
        screenshot_bt = new QPushButton(groupBox_5);
        screenshot_bt->setObjectName(QString::fromUtf8("screenshot_bt"));
        screenshot_bt->setGeometry(QRect(515, 51, 115, 21));
        screenshot_bt->setFont(font10);
        screenshot_bt->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"background-color: rgb(227, 227, 227);"));
        screenshot_bt->setFlat(false);
        system_monitor = new QPushButton(groupBox_5);
        system_monitor->setObjectName(QString::fromUtf8("system_monitor"));
        system_monitor->setGeometry(QRect(20, 50, 115, 21));
        system_monitor->setFont(font10);
        system_monitor->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"background-color: rgb(227, 227, 227);"));
        system_monitor->setFlat(false);
        crntmac = new QLabel(centralWidget);
        crntmac->setObjectName(QString::fromUtf8("crntmac"));
        crntmac->setGeometry(QRect(490, 980, 181, 31));
        crntmac->setFont(font7);
        Creator_label = new QLabel(centralWidget);
        Creator_label->setObjectName(QString::fromUtf8("Creator_label"));
        Creator_label->setGeometry(QRect(533, 1090, 140, 15));
        Creator_label->setStyleSheet(QString::fromUtf8("font: italic 9pt \"Utopia\";"));
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(0, 0, 100, 30));
        gridLayout_4 = new QGridLayout(layoutWidget);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        silentmode_bt = new QPushButton(centralWidget);
        silentmode_bt->setObjectName(QString::fromUtf8("silentmode_bt"));
        silentmode_bt->setGeometry(QRect(470, 10, 28, 28));
        silentmode_bt->setFocusPolicy(Qt::NoFocus);
        silentmode_bt->setContextMenuPolicy(Qt::NoContextMenu);
        silentmode_bt->setStyleSheet(QString::fromUtf8("background-color: rgb(248, 248, 248);\n"
"image: url(:/imag/unmute.png);\n"
"background-image: url(:/imag/unmute.png);\n"
"border: 0px;"));
        ED_01_lcc = new QPushButton(centralWidget);
        ED_01_lcc->setObjectName(QString::fromUtf8("ED_01_lcc"));
        ED_01_lcc->setGeometry(QRect(30, 80, 241, 21));
        ED_01_lcc->setFocusPolicy(Qt::NoFocus);
        ED_01_lcc->setContextMenuPolicy(Qt::NoContextMenu);
        ED_01_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_01_lcc->setFlat(true);
        ED_02_lcc = new QPushButton(centralWidget);
        ED_02_lcc->setObjectName(QString::fromUtf8("ED_02_lcc"));
        ED_02_lcc->setGeometry(QRect(30, 150, 241, 21));
        ED_02_lcc->setFocusPolicy(Qt::NoFocus);
        ED_02_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_02_lcc->setFlat(true);
        ED_03_lcc = new QPushButton(centralWidget);
        ED_03_lcc->setObjectName(QString::fromUtf8("ED_03_lcc"));
        ED_03_lcc->setGeometry(QRect(30, 220, 241, 21));
        ED_03_lcc->setFocusPolicy(Qt::NoFocus);
        ED_03_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_03_lcc->setFlat(true);
        ED_04_lcc = new QPushButton(centralWidget);
        ED_04_lcc->setObjectName(QString::fromUtf8("ED_04_lcc"));
        ED_04_lcc->setGeometry(QRect(30, 290, 241, 21));
        ED_04_lcc->setFocusPolicy(Qt::NoFocus);
        ED_04_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_04_lcc->setFlat(true);
        ED_05_lcc = new QPushButton(centralWidget);
        ED_05_lcc->setObjectName(QString::fromUtf8("ED_05_lcc"));
        ED_05_lcc->setGeometry(QRect(30, 360, 241, 21));
        ED_05_lcc->setFocusPolicy(Qt::NoFocus);
        ED_05_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_05_lcc->setFlat(true);
        ED_06_lcc = new QPushButton(centralWidget);
        ED_06_lcc->setObjectName(QString::fromUtf8("ED_06_lcc"));
        ED_06_lcc->setGeometry(QRect(30, 430, 241, 21));
        ED_06_lcc->setFocusPolicy(Qt::NoFocus);
        ED_06_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_06_lcc->setFlat(true);
        ED_09_lcc = new QPushButton(centralWidget);
        ED_09_lcc->setObjectName(QString::fromUtf8("ED_09_lcc"));
        ED_09_lcc->setGeometry(QRect(370, 80, 241, 21));
        ED_09_lcc->setFocusPolicy(Qt::NoFocus);
        ED_09_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_09_lcc->setFlat(true);
        ED_10_lcc = new QPushButton(centralWidget);
        ED_10_lcc->setObjectName(QString::fromUtf8("ED_10_lcc"));
        ED_10_lcc->setGeometry(QRect(370, 150, 241, 21));
        ED_10_lcc->setFocusPolicy(Qt::NoFocus);
        ED_10_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_10_lcc->setFlat(true);
        ED_12_lcc = new QPushButton(centralWidget);
        ED_12_lcc->setObjectName(QString::fromUtf8("ED_12_lcc"));
        ED_12_lcc->setGeometry(QRect(370, 290, 241, 21));
        ED_12_lcc->setFocusPolicy(Qt::NoFocus);
        ED_12_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_12_lcc->setFlat(true);
        ED_11_lcc = new QPushButton(centralWidget);
        ED_11_lcc->setObjectName(QString::fromUtf8("ED_11_lcc"));
        ED_11_lcc->setGeometry(QRect(370, 220, 241, 21));
        ED_11_lcc->setFocusPolicy(Qt::NoFocus);
        ED_11_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_11_lcc->setFlat(true);
        ED_13_lcc = new QPushButton(centralWidget);
        ED_13_lcc->setObjectName(QString::fromUtf8("ED_13_lcc"));
        ED_13_lcc->setGeometry(QRect(370, 360, 241, 21));
        ED_13_lcc->setFocusPolicy(Qt::NoFocus);
        ED_13_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_13_lcc->setFlat(true);
        ED_14_lcc = new QPushButton(centralWidget);
        ED_14_lcc->setObjectName(QString::fromUtf8("ED_14_lcc"));
        ED_14_lcc->setGeometry(QRect(370, 430, 241, 21));
        ED_14_lcc->setFocusPolicy(Qt::NoFocus);
        ED_14_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_14_lcc->setFlat(true);
        ED_16_lcc = new QPushButton(centralWidget);
        ED_16_lcc->setObjectName(QString::fromUtf8("ED_16_lcc"));
        ED_16_lcc->setGeometry(QRect(30, 630, 241, 21));
        ED_16_lcc->setFocusPolicy(Qt::NoFocus);
        ED_16_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_16_lcc->setFlat(true);
        ED_18_lcc = new QPushButton(centralWidget);
        ED_18_lcc->setObjectName(QString::fromUtf8("ED_18_lcc"));
        ED_18_lcc->setGeometry(QRect(30, 770, 241, 21));
        ED_18_lcc->setFocusPolicy(Qt::NoFocus);
        ED_18_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_18_lcc->setFlat(true);
        ED_20_lcc = new QPushButton(centralWidget);
        ED_20_lcc->setObjectName(QString::fromUtf8("ED_20_lcc"));
        ED_20_lcc->setGeometry(QRect(30, 910, 241, 21));
        ED_20_lcc->setFocusPolicy(Qt::NoFocus);
        ED_20_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_20_lcc->setFlat(true);
        ED_15_lcc = new QPushButton(centralWidget);
        ED_15_lcc->setObjectName(QString::fromUtf8("ED_15_lcc"));
        ED_15_lcc->setGeometry(QRect(30, 560, 241, 21));
        ED_15_lcc->setFocusPolicy(Qt::NoFocus);
        ED_15_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_15_lcc->setFlat(true);
        ED_17_lcc = new QPushButton(centralWidget);
        ED_17_lcc->setObjectName(QString::fromUtf8("ED_17_lcc"));
        ED_17_lcc->setGeometry(QRect(30, 700, 241, 21));
        ED_17_lcc->setFocusPolicy(Qt::NoFocus);
        ED_17_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_17_lcc->setFlat(true);
        ED_19_lcc = new QPushButton(centralWidget);
        ED_19_lcc->setObjectName(QString::fromUtf8("ED_19_lcc"));
        ED_19_lcc->setGeometry(QRect(30, 840, 241, 21));
        ED_19_lcc->setFocusPolicy(Qt::NoFocus);
        ED_19_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_19_lcc->setFlat(true);
        ED_23_lcc = new QPushButton(centralWidget);
        ED_23_lcc->setObjectName(QString::fromUtf8("ED_23_lcc"));
        ED_23_lcc->setGeometry(QRect(370, 560, 241, 21));
        ED_23_lcc->setFocusPolicy(Qt::NoFocus);
        ED_23_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_23_lcc->setFlat(true);
        ED_27_lcc = new QPushButton(centralWidget);
        ED_27_lcc->setObjectName(QString::fromUtf8("ED_27_lcc"));
        ED_27_lcc->setGeometry(QRect(370, 840, 241, 21));
        ED_27_lcc->setFocusPolicy(Qt::NoFocus);
        ED_27_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_27_lcc->setFlat(true);
        ED_25_lcc = new QPushButton(centralWidget);
        ED_25_lcc->setObjectName(QString::fromUtf8("ED_25_lcc"));
        ED_25_lcc->setGeometry(QRect(370, 700, 241, 21));
        ED_25_lcc->setFocusPolicy(Qt::NoFocus);
        ED_25_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_25_lcc->setFlat(true);
        ED_24_lcc = new QPushButton(centralWidget);
        ED_24_lcc->setObjectName(QString::fromUtf8("ED_24_lcc"));
        ED_24_lcc->setGeometry(QRect(370, 630, 241, 21));
        ED_24_lcc->setFocusPolicy(Qt::NoFocus);
        ED_24_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_24_lcc->setFlat(true);
        ED_26_lcc = new QPushButton(centralWidget);
        ED_26_lcc->setObjectName(QString::fromUtf8("ED_26_lcc"));
        ED_26_lcc->setGeometry(QRect(370, 770, 241, 21));
        ED_26_lcc->setFocusPolicy(Qt::NoFocus);
        ED_26_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_26_lcc->setFlat(true);
        ED_28_lcc = new QPushButton(centralWidget);
        ED_28_lcc->setObjectName(QString::fromUtf8("ED_28_lcc"));
        ED_28_lcc->setGeometry(QRect(370, 910, 241, 21));
        ED_28_lcc->setFocusPolicy(Qt::NoFocus);
        ED_28_lcc->setStyleSheet(QString::fromUtf8("QPushButton:pressed	{\n"
"border: 2px solid black;\n"
"}"));
        ED_28_lcc->setFlat(true);
        FAULTS = new QDockWidget(centralWidget);
        FAULTS->setObjectName(QString::fromUtf8("FAULTS"));
        FAULTS->setEnabled(true);
        FAULTS->setGeometry(QRect(0, 23, 1020, 500));
        sizePolicy1.setHeightForWidth(FAULTS->sizePolicy().hasHeightForWidth());
        FAULTS->setSizePolicy(sizePolicy1);
        FAULTS->setMinimumSize(QSize(1020, 500));
        FAULTS->setMaximumSize(QSize(1020, 524287));
        FAULTS->setAutoFillBackground(false);
        FAULTS->setStyleSheet(QString::fromUtf8("gridline-color: rgb(0, 0, 0);\n"
""));
        FAULTS->setFloating(true);
        FAULTS->setFeatures(QDockWidget::AllDockWidgetFeatures);
        dockWidgetContents_6 = new QWidget();
        dockWidgetContents_6->setObjectName(QString::fromUtf8("dockWidgetContents_6"));
        gridLayout = new QGridLayout(dockWidgetContents_6);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        tabWidget = new QTabWidget(dockWidgetContents_6);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setFocusPolicy(Qt::NoFocus);
        tabWidget->setStyleSheet(QString::fromUtf8("QTabBar::tab:!selected	{\n"
"	font: 75 9pt \"Sans Serif\";\n"
"	background-color: rgb(193, 193, 193);\n"
"	border-top-left-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	margin-left: px;\n"
"	margin-right: px;\n"
"	border: 1px solid black;\n"
"	border-bottom-color: black;\n"
"	min-width: 10ex;\n"
"}\n"
"QTabBar::tab:selected	{\n"
"	background-color: rgb(255, 255, 255);\n"
"	font: 75  9pt \"Sans Serif\";\n"
"	border-top-left-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	margin-left: px;\n"
"	margin-right: px;\n"
"	border: 1px solid black;\n"
"	border-bottom-color: rgb(255, 255, 255);\n"
"	min-width: 10ex;\n"
"}\n"
"QTabWidget::pane	{\n"
"	border: 1px solid black\n"
"}"));
        tabWidget->setTabShape(QTabWidget::Rounded);
        real_time_tab = new QWidget();
        real_time_tab->setObjectName(QString::fromUtf8("real_time_tab"));
        gridLayout_3 = new QGridLayout(real_time_tab);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        frame_2 = new QFrame(real_time_tab);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        sizePolicy.setHeightForWidth(frame_2->sizePolicy().hasHeightForWidth());
        frame_2->setSizePolicy(sizePolicy);
        frame_2->setMinimumSize(QSize(0, 50));
        frame_2->setMaximumSize(QSize(16777215, 80));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        line_10 = new QFrame(frame_2);
        line_10->setObjectName(QString::fromUtf8("line_10"));
        line_10->setGeometry(QRect(0, 25, 971, 17));
        line_10->setFrameShadow(QFrame::Plain);
        line_10->setLineWidth(3);
        line_10->setFrameShape(QFrame::HLine);
        label_11 = new QLabel(frame_2);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(0, 0, 971, 32));
        label_11->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 0, 127);"));
        label_12 = new QLabel(frame_2);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(0, 35, 971, 44));
        label_12->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(97, 97, 97);"));
        save_flt_button = new QPushButton(frame_2);
        save_flt_button->setObjectName(QString::fromUtf8("save_flt_button"));
        save_flt_button->setGeometry(QRect(704, 44, 221, 26));
        QFont font11;
        font11.setFamily(QString::fromUtf8("Sans Serif"));
        font11.setPointSize(10);
        font11.setBold(false);
        font11.setItalic(false);
        font11.setWeight(50);
        save_flt_button->setFont(font11);
        save_flt_button->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        line_11 = new QFrame(frame_2);
        line_11->setObjectName(QString::fromUtf8("line_11"));
        line_11->setGeometry(QRect(240, 0, 20, 101));
        line_11->setFrameShadow(QFrame::Plain);
        line_11->setLineWidth(2);
        line_11->setFrameShape(QFrame::VLine);
        line_12 = new QFrame(frame_2);
        line_12->setObjectName(QString::fromUtf8("line_12"));
        line_12->setGeometry(QRect(490, 0, 20, 101));
        line_12->setFrameShadow(QFrame::Plain);
        line_12->setLineWidth(2);
        line_12->setFrameShape(QFrame::VLine);
        faultstartdate = new QDateTimeEdit(frame_2);
        faultstartdate->setObjectName(QString::fromUtf8("faultstartdate"));
        faultstartdate->setGeometry(QRect(27, 44, 194, 25));
        faultstartdate->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        faultstartdate->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        faultstartdate->setButtonSymbols(QAbstractSpinBox::NoButtons);
        faultstartdate->setDate(QDate(2019, 4, 6));
        faultstartdate->setCalendarPopup(true);
        faultenddate = new QDateTimeEdit(frame_2);
        faultenddate->setObjectName(QString::fromUtf8("faultenddate"));
        faultenddate->setGeometry(QRect(277, 44, 194, 25));
        faultenddate->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        faultenddate->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        faultenddate->setDate(QDate(2019, 4, 6));
        faultenddate->setCalendarPopup(true);
        line_18 = new QFrame(frame_2);
        line_18->setObjectName(QString::fromUtf8("line_18"));
        line_18->setGeometry(QRect(650, 0, 20, 101));
        line_18->setFrameShadow(QFrame::Plain);
        line_18->setLineWidth(2);
        line_18->setFrameShape(QFrame::VLine);
        grep_mv3d_exp = new QComboBox(frame_2);
        grep_mv3d_exp->setObjectName(QString::fromUtf8("grep_mv3d_exp"));
        grep_mv3d_exp->setGeometry(QRect(540, 44, 81, 25));
        grep_mv3d_exp->setFont(font11);
        grep_mv3d_exp->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));

        gridLayout_3->addWidget(frame_2, 0, 0, 1, 1);

        faulttable = new QTableWidget(real_time_tab);
        if (faulttable->columnCount() < 5)
            faulttable->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        __qtablewidgetitem->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem->setFont(font7);
        __qtablewidgetitem->setBackground(QColor(0, 85, 255));
        faulttable->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        __qtablewidgetitem1->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem1->setFont(font7);
        __qtablewidgetitem1->setBackground(QColor(0, 85, 255));
        faulttable->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        __qtablewidgetitem2->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem2->setFont(font7);
        __qtablewidgetitem2->setBackground(QColor(0, 85, 255));
        faulttable->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        __qtablewidgetitem3->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem3->setFont(font7);
        __qtablewidgetitem3->setBackground(QColor(0, 85, 255));
        faulttable->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        __qtablewidgetitem4->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem4->setFont(font7);
        __qtablewidgetitem4->setBackground(QColor(0, 85, 255));
        faulttable->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        if (faulttable->rowCount() < 1)
            faulttable->setRowCount(1);
        faulttable->setObjectName(QString::fromUtf8("faulttable"));
        sizePolicy1.setHeightForWidth(faulttable->sizePolicy().hasHeightForWidth());
        faulttable->setSizePolicy(sizePolicy1);
        faulttable->setMinimumSize(QSize(0, 0));
        faulttable->setStyleSheet(QString::fromUtf8("gridline-color: rgb(0, 0, 0);\n"
"background-color: rgb(199, 199, 199);"));
        faulttable->setFrameShape(QFrame::NoFrame);
        faulttable->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        faulttable->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        faulttable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        faulttable->setAlternatingRowColors(false);
        faulttable->setShowGrid(true);
        faulttable->setGridStyle(Qt::SolidLine);
        faulttable->setSortingEnabled(false);
        faulttable->setWordWrap(false);
        faulttable->setRowCount(1);
        faulttable->horizontalHeader()->setVisible(false);
        faulttable->horizontalHeader()->setCascadingSectionResizes(true);
        faulttable->horizontalHeader()->setDefaultSectionSize(188);
        faulttable->horizontalHeader()->setHighlightSections(true);
        faulttable->horizontalHeader()->setMinimumSectionSize(30);
        faulttable->horizontalHeader()->setProperty("showSortIndicator", QVariant(false));
        faulttable->horizontalHeader()->setStretchLastSection(false);
        faulttable->verticalHeader()->setVisible(false);
        faulttable->verticalHeader()->setStretchLastSection(false);

        gridLayout_3->addWidget(faulttable, 1, 0, 1, 1);

        tabWidget->addTab(real_time_tab, QString());
        dsplay_tab = new QWidget();
        dsplay_tab->setObjectName(QString::fromUtf8("dsplay_tab"));
        gridLayout_5 = new QGridLayout(dsplay_tab);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        frame_3 = new QFrame(dsplay_tab);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        sizePolicy.setHeightForWidth(frame_3->sizePolicy().hasHeightForWidth());
        frame_3->setSizePolicy(sizePolicy);
        frame_3->setMinimumSize(QSize(0, 50));
        frame_3->setMaximumSize(QSize(16777215, 80));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        line_13 = new QFrame(frame_3);
        line_13->setObjectName(QString::fromUtf8("line_13"));
        line_13->setGeometry(QRect(0, 25, 971, 17));
        line_13->setFrameShadow(QFrame::Plain);
        line_13->setLineWidth(3);
        line_13->setFrameShape(QFrame::HLine);
        label_13 = new QLabel(frame_3);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(0, 0, 971, 32));
        label_13->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 0, 127);"));
        label_14 = new QLabel(frame_3);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(0, 35, 971, 44));
        label_14->setStyleSheet(QString::fromUtf8("font: 75 bold 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(97, 97, 97);"));
        fault_display_button = new QPushButton(frame_3);
        fault_display_button->setObjectName(QString::fromUtf8("fault_display_button"));
        fault_display_button->setGeometry(QRect(615, 44, 131, 26));
        fault_display_button->setFont(font11);
        fault_display_button->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        line_14 = new QFrame(frame_3);
        line_14->setObjectName(QString::fromUtf8("line_14"));
        line_14->setGeometry(QRect(226, 0, 20, 95));
        line_14->setFrameShadow(QFrame::Plain);
        line_14->setLineWidth(2);
        line_14->setFrameShape(QFrame::VLine);
        line_15 = new QFrame(frame_3);
        line_15->setObjectName(QString::fromUtf8("line_15"));
        line_15->setGeometry(QRect(463, 0, 20, 101));
        line_15->setFrameShadow(QFrame::Plain);
        line_15->setLineWidth(2);
        line_15->setFrameShape(QFrame::VLine);
        faultstartdate_disp = new QDateTimeEdit(frame_3);
        faultstartdate_disp->setObjectName(QString::fromUtf8("faultstartdate_disp"));
        faultstartdate_disp->setGeometry(QRect(19, 44, 194, 25));
        faultstartdate_disp->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        faultstartdate_disp->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        faultstartdate_disp->setButtonSymbols(QAbstractSpinBox::NoButtons);
        faultstartdate_disp->setDate(QDate(2019, 4, 6));
        faultstartdate_disp->setCalendarPopup(true);
        faultenddate_disp = new QDateTimeEdit(frame_3);
        faultenddate_disp->setObjectName(QString::fromUtf8("faultenddate_disp"));
        faultenddate_disp->setGeometry(QRect(257, 44, 194, 25));
        faultenddate_disp->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        faultenddate_disp->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        faultenddate_disp->setDate(QDate(2019, 4, 6));
        faultenddate_disp->setCalendarPopup(true);
        line_16 = new QFrame(frame_3);
        line_16->setObjectName(QString::fromUtf8("line_16"));
        line_16->setGeometry(QRect(765, 0, 20, 81));
        line_16->setFrameShadow(QFrame::Plain);
        line_16->setLineWidth(2);
        line_16->setFrameShape(QFrame::VLine);
        fault_browser_button = new QPushButton(frame_3);
        fault_browser_button->setObjectName(QString::fromUtf8("fault_browser_button"));
        fault_browser_button->setGeometry(QRect(801, 44, 141, 26));
        fault_browser_button->setFont(font11);
        fault_browser_button->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        grep_mv3d_disp = new QComboBox(frame_3);
        grep_mv3d_disp->setObjectName(QString::fromUtf8("grep_mv3d_disp"));
        grep_mv3d_disp->setGeometry(QRect(490, 44, 82, 25));
        grep_mv3d_disp->setFont(font11);
        grep_mv3d_disp->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        line_17 = new QFrame(frame_3);
        line_17->setObjectName(QString::fromUtf8("line_17"));
        line_17->setGeometry(QRect(580, 0, 20, 81));
        line_17->setFrameShadow(QFrame::Plain);
        line_17->setLineWidth(2);
        line_17->setFrameShape(QFrame::VLine);

        gridLayout_5->addWidget(frame_3, 0, 0, 1, 1);

        disp_faulttable = new QTableWidget(dsplay_tab);
        if (disp_faulttable->columnCount() < 6)
            disp_faulttable->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        __qtablewidgetitem5->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem5->setFont(font7);
        __qtablewidgetitem5->setBackground(QColor(0, 85, 255));
        disp_faulttable->setHorizontalHeaderItem(0, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        __qtablewidgetitem6->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem6->setFont(font7);
        __qtablewidgetitem6->setBackground(QColor(0, 85, 255));
        disp_faulttable->setHorizontalHeaderItem(1, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        __qtablewidgetitem7->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem7->setFont(font7);
        __qtablewidgetitem7->setBackground(QColor(0, 85, 255));
        disp_faulttable->setHorizontalHeaderItem(2, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        __qtablewidgetitem8->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem8->setFont(font7);
        __qtablewidgetitem8->setBackground(QColor(0, 85, 255));
        disp_faulttable->setHorizontalHeaderItem(3, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        __qtablewidgetitem9->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem9->setFont(font7);
        __qtablewidgetitem9->setBackground(QColor(0, 85, 255));
        disp_faulttable->setHorizontalHeaderItem(4, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        __qtablewidgetitem10->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter|Qt::AlignCenter);
        __qtablewidgetitem10->setFont(font7);
        __qtablewidgetitem10->setBackground(QColor(0, 85, 255));
        disp_faulttable->setHorizontalHeaderItem(5, __qtablewidgetitem10);
        if (disp_faulttable->rowCount() < 1)
            disp_faulttable->setRowCount(1);
        disp_faulttable->setObjectName(QString::fromUtf8("disp_faulttable"));
        sizePolicy1.setHeightForWidth(disp_faulttable->sizePolicy().hasHeightForWidth());
        disp_faulttable->setSizePolicy(sizePolicy1);
        disp_faulttable->setMinimumSize(QSize(0, 0));
        disp_faulttable->setStyleSheet(QString::fromUtf8("gridline-color: rgb(0, 0, 0);\n"
"background-color: rgb(199, 199, 199);"));
        disp_faulttable->setFrameShape(QFrame::NoFrame);
        disp_faulttable->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        disp_faulttable->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        disp_faulttable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        disp_faulttable->setAlternatingRowColors(false);
        disp_faulttable->setShowGrid(true);
        disp_faulttable->setGridStyle(Qt::SolidLine);
        disp_faulttable->setSortingEnabled(false);
        disp_faulttable->setWordWrap(false);
        disp_faulttable->setRowCount(1);
        disp_faulttable->horizontalHeader()->setVisible(false);
        disp_faulttable->horizontalHeader()->setCascadingSectionResizes(true);
        disp_faulttable->horizontalHeader()->setDefaultSectionSize(188);
        disp_faulttable->horizontalHeader()->setHighlightSections(true);
        disp_faulttable->horizontalHeader()->setMinimumSectionSize(30);
        disp_faulttable->horizontalHeader()->setProperty("showSortIndicator", QVariant(false));
        disp_faulttable->horizontalHeader()->setStretchLastSection(false);
        disp_faulttable->verticalHeader()->setVisible(false);

        gridLayout_5->addWidget(disp_faulttable, 1, 0, 1, 1);

        tabWidget->addTab(dsplay_tab, QString());

        gridLayout->addWidget(tabWidget, 1, 0, 1, 1);

        FAULTS->setWidget(dockWidgetContents_6);
        bagdec = new QDockWidget(centralWidget);
        bagdec->setObjectName(QString::fromUtf8("bagdec"));
        bagdec->setGeometry(QRect(0, 23, 1550, 1000));
        bagdec->setMinimumSize(QSize(1550, 1000));
        bagdec->setMaximumSize(QSize(1550, 1000));
        bagdec->setFloating(true);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));
        gridLayout_2 = new QGridLayout(dockWidgetContents);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        frame = new QFrame(dockWidgetContents);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setMinimumSize(QSize(0, 90));
        frame->setStyleSheet(QString::fromUtf8(""));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        grep_mv3d = new QComboBox(frame);
        grep_mv3d->setObjectName(QString::fromUtf8("grep_mv3d"));
        grep_mv3d->setGeometry(QRect(33, 51, 82, 25));
        grep_mv3d->setFont(font11);
        grep_mv3d->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        grepperbox = new QComboBox(frame);
        grepperbox->setObjectName(QString::fromUtf8("grepperbox"));
        grepperbox->setGeometry(QRect(586, 51, 131, 25));
        grepperbox->setFont(font11);
        grepperbox->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        line = new QFrame(frame);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(140, 0, 20, 91));
        line->setAutoFillBackground(false);
        line->setFrameShadow(QFrame::Plain);
        line->setLineWidth(2);
        line->setFrameShape(QFrame::VLine);
        line_2 = new QFrame(frame);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(0, 30, 1531, 16));
        line_2->setFrameShadow(QFrame::Plain);
        line_2->setLineWidth(2);
        line_2->setFrameShape(QFrame::HLine);
        line_3 = new QFrame(frame);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setGeometry(QRect(740, 0, 20, 91));
        line_3->setFrameShadow(QFrame::Plain);
        line_3->setLineWidth(2);
        line_3->setFrameShape(QFrame::VLine);
        grepdate = new QDateTimeEdit(frame);
        grepdate->setObjectName(QString::fromUtf8("grepdate"));
        grepdate->setGeometry(QRect(1120, 51, 151, 25));
        grepdate->setFont(font11);
        grepdate->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        grepdate->setDate(QDate(2019, 2, 27));
        grepdate->setCalendarPopup(true);
        line_4 = new QFrame(frame);
        line_4->setObjectName(QString::fromUtf8("line_4"));
        line_4->setGeometry(QRect(1080, 0, 20, 91));
        line_4->setFrameShadow(QFrame::Plain);
        line_4->setLineWidth(2);
        line_4->setFrameShape(QFrame::VLine);
        label = new QLabel(frame);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 151, 38));
        QFont font12;
        font12.setFamily(QString::fromUtf8("Sans Serif"));
        font12.setPointSize(10);
        font12.setBold(true);
        font12.setItalic(false);
        font12.setWeight(75);
        label->setFont(font12);
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 0, 0);\n"
"font: 75 bold 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(frame);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(550, 0, 199, 38));
        label_2->setFont(font12);
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 0, 0);\n"
"font: 75 bold 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        label_2->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(frame);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(1090, 0, 211, 38));
        label_3->setFont(font12);
        label_3->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 0, 0);\n"
"font: 75 bold 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        label_3->setAlignment(Qt::AlignCenter);
        call_button = new QPushButton(frame);
        call_button->setObjectName(QString::fromUtf8("call_button"));
        call_button->setGeometry(QRect(1330, 51, 168, 26));
        call_button->setFont(font11);
        call_button->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        label_4 = new QLabel(frame);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(1300, 0, 231, 38));
        label_4->setFont(font12);
        label_4->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 0, 0);\n"
"font: 75 bold 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        label_4->setAlignment(Qt::AlignCenter);
        label_5 = new QLabel(frame);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(0, 39, 1531, 50));
        label_5->setStyleSheet(QString::fromUtf8("background-color: rgb(65, 65, 65);"));
        line_5 = new QFrame(frame);
        line_5->setObjectName(QString::fromUtf8("line_5"));
        line_5->setGeometry(QRect(1290, 0, 20, 91));
        line_5->setFrameShadow(QFrame::Plain);
        line_5->setLineWidth(2);
        line_5->setFrameShape(QFrame::VLine);
        label_6 = new QLabel(frame);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(750, 0, 341, 37));
        label_6->setFont(font12);
        label_6->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 0, 0);\n"
"font: 75 bold 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        label_6->setAlignment(Qt::AlignCenter);
        manuelactive = new QRadioButton(frame);
        manuelactive->setObjectName(QString::fromUtf8("manuelactive"));
        manuelactive->setGeometry(QRect(256, 51, 81, 25));
        manuelactive->setFocusPolicy(Qt::NoFocus);
        manuelactive->setStyleSheet(QString::fromUtf8("font: bold 9pt \"Sans Serif\";\n"
"\n"
"\n"
""));
        manuelactive->setIconSize(QSize(24, 24));
        manuelcombo = new QComboBox(frame);
        manuelcombo->setObjectName(QString::fromUtf8("manuelcombo"));
        manuelcombo->setGeometry(QRect(770, 51, 91, 25));
        manuelcombo->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 9pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        manuellabel = new QTextEdit(frame);
        manuellabel->setObjectName(QString::fromUtf8("manuellabel"));
        manuellabel->setGeometry(QRect(896, 51, 171, 25));
        manuellabel->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        manuellabel->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        label_10 = new QLabel(frame);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(352, 0, 198, 38));
        label_10->setFont(font12);
        label_10->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 0, 0);\n"
"font: 75 bold 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        label_10->setAlignment(Qt::AlignCenter);
        line_9 = new QFrame(frame);
        line_9->setObjectName(QString::fromUtf8("line_9"));
        line_9->setGeometry(QRect(341, 0, 20, 91));
        line_9->setFrameShadow(QFrame::Plain);
        line_9->setLineWidth(2);
        line_9->setFrameShape(QFrame::VLine);
        log_selection_box = new QComboBox(frame);
        log_selection_box->setObjectName(QString::fromUtf8("log_selection_box"));
        log_selection_box->setGeometry(QRect(374, 51, 155, 25));
        log_selection_box->setFont(font11);
        log_selection_box->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"font: 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        line_6 = new QFrame(frame);
        line_6->setObjectName(QString::fromUtf8("line_6"));
        line_6->setGeometry(QRect(543, 0, 20, 91));
        line_6->setFrameShadow(QFrame::Plain);
        line_6->setLineWidth(2);
        line_6->setFrameShape(QFrame::VLine);
        quickactive = new QRadioButton(frame);
        quickactive->setObjectName(QString::fromUtf8("quickactive"));
        quickactive->setGeometry(QRect(166, 51, 76, 25));
        quickactive->setFocusPolicy(Qt::NoFocus);
        quickactive->setStyleSheet(QString::fromUtf8("font: bold 9pt \"Sans Serif\";\n"
"\n"
"\n"
""));
        quickactive->setIconSize(QSize(24, 24));
        label_7 = new QLabel(frame);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(150, 0, 200, 38));
        label_7->setFont(font12);
        label_7->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 0, 0);\n"
"font: 75 bold 10pt \"Sans Serif\";\n"
"color: rgb(255, 255, 255);"));
        label_7->setAlignment(Qt::AlignCenter);
        label_5->raise();
        manuelcombo->raise();
        call_button->raise();
        label_6->raise();
        grepdate->raise();
        log_selection_box->raise();
        manuellabel->raise();
        label_4->raise();
        label_7->raise();
        label_10->raise();
        label->raise();
        label_2->raise();
        grepperbox->raise();
        manuelactive->raise();
        label_3->raise();
        quickactive->raise();
        grep_mv3d->raise();
        line_5->raise();
        line_6->raise();
        line_4->raise();
        line_3->raise();
        line->raise();
        line_2->raise();
        line_9->raise();

        gridLayout_2->addWidget(frame, 0, 0, 1, 1);

        bagdecision = new QTextBrowser(dockWidgetContents);
        bagdecision->setObjectName(QString::fromUtf8("bagdecision"));
        bagdecision->setFont(font11);
        bagdecision->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"color: rgb(50, 244, 131);\n"
"font: 10pt \"Sans Serif\";"));

        gridLayout_2->addWidget(bagdecision, 1, 0, 1, 1);

        bagdec->setWidget(dockWidgetContents);
        alper->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(alper);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 693, 23));
        alper->setMenuBar(menuBar);
        statusBar = new QStatusBar(alper);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        alper->setStatusBar(statusBar);

        retranslateUi(alper);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(alper);
    } // setupUi

    void retranslateUi(QMainWindow *alper)
    {
        alper->setWindowTitle(QApplication::translate("alper", "EDS CONTROL STATION", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        alper->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        groupBox->setTitle(QApplication::translate("alper", "TB2-1(WEST)", 0, QApplication::UnicodeUTF8));
        ED_2_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_6->setText(QApplication::translate("alper", "ED_06(3D0039)", 0, QApplication::UnicodeUTF8));
        ED_3_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_2->setText(QApplication::translate("alper", "ED_02(3D0040)", 0, QApplication::UnicodeUTF8));
        ED_2_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_6_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_1->setText(QApplication::translate("alper", "ED_01(3D0037)", 0, QApplication::UnicodeUTF8));
        ED_1_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_5_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_6_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_4->setText(QApplication::translate("alper", "ED_04(3D0036)", 0, QApplication::UnicodeUTF8));
        ED_5->setText(QApplication::translate("alper", "ED_05(3D0038)", 0, QApplication::UnicodeUTF8));
        ED_3->setText(QApplication::translate("alper", "ED_03(3D0035)", 0, QApplication::UnicodeUTF8));
        ED_1_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_3_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_4_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_5_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_4_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        label_19->setText(QString());
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        com->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        label_26->setText(QString());
        label_27->setText(QString());
        label_28->setText(QString());
        label_29->setText(QString());
        label_30->setText(QString());
        pushButton->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        ED_10_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_10_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_9_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_12->setText(QApplication::translate("alper", "ED_12(3D0022)", 0, QApplication::UnicodeUTF8));
        ED_12_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_9->setText(QApplication::translate("alper", "ED_09(3D0025)", 0, QApplication::UnicodeUTF8));
        ED_11->setText(QApplication::translate("alper", "ED_11(3D0023)", 0, QApplication::UnicodeUTF8));
        ED_10->setText(QApplication::translate("alper", "ED_10(3D0017)", 0, QApplication::UnicodeUTF8));
        ED_11_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_14_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_14->setText(QApplication::translate("alper", "ED_14(3D0032)", 0, QApplication::UnicodeUTF8));
        ED_14_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_13->setText(QApplication::translate("alper", "ED_13(3D0033)", 0, QApplication::UnicodeUTF8));
        ED_12_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_13_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_9_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("alper", "TB2-3(MID-WEST)", 0, QApplication::UnicodeUTF8));
        ED_11_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_13_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        label_61->setText(QString());
        ED_26->setText(QApplication::translate("alper", "ED_26(3D0045)", 0, QApplication::UnicodeUTF8));
        ED_16->setText(QApplication::translate("alper", "ED_16(3D0028)", 0, QApplication::UnicodeUTF8));
        label_64->setText(QString());
        label_65->setText(QString());
        label_66->setText(QString());
        ED_23_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        label_69->setText(QString());
        groupBox_3->setTitle(QApplication::translate("alper", "TB2-4(MID-EAST)", 0, QApplication::UnicodeUTF8));
        ED_23->setText(QApplication::translate("alper", "ED_23(3D0044)", 0, QApplication::UnicodeUTF8));
        label_71->setText(QString());
        ED_16_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        label_74->setText(QString());
        label_75->setText(QString());
        ED_20_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_19_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_17_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_15_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_20->setText(QApplication::translate("alper", "ED_20(3D0024)", 0, QApplication::UnicodeUTF8));
        label_83->setText(QString());
        ED_25_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_24_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_24->setText(QApplication::translate("alper", "ED_24(3D0046)", 0, QApplication::UnicodeUTF8));
        ED_28_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_18_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        label_92->setText(QString());
        ED_20_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        groupBox_4->setTitle(QApplication::translate("alper", "TB2-6(EAST)", 0, QApplication::UnicodeUTF8));
        ED_17->setText(QApplication::translate("alper", "ED_17(3D0021)", 0, QApplication::UnicodeUTF8));
        ED_27_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        label_96->setText(QString());
        ED_15->setText(QApplication::translate("alper", "ED_15(3D0020)", 0, QApplication::UnicodeUTF8));
        ED_19_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_23_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_15_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        label_105->setText(QString());
        ED_18_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_26_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_18->setText(QApplication::translate("alper", "ED_18(3D0026)", 0, QApplication::UnicodeUTF8));
        ED_17_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_16_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_24_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        ED_26_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_27->setText(QApplication::translate("alper", "ED_27(3D0041)", 0, QApplication::UnicodeUTF8));
        ED_28_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_28->setText(QApplication::translate("alper", "ED_28(3D0042)", 0, QApplication::UnicodeUTF8));
        ED_25->setText(QApplication::translate("alper", "ED_25(3D0043)", 0, QApplication::UnicodeUTF8));
        ED_19->setText(QApplication::translate("alper", "ED_19(3D0027)", 0, QApplication::UnicodeUTF8));
        ED_25_FAULT->setText(QApplication::translate("alper", "FAULT:", 0, QApplication::UnicodeUTF8));
        ED_27_STATE->setText(QApplication::translate("alper", "STATE:", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        com_2->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        pushButton_3->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        comboBox_3->clear();
        comboBox_3->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        com_3->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        com_4->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        comboBox_4->clear();
        comboBox_4->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        pushButton_4->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        pushButton_5->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        com_5->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        comboBox_5->clear();
        comboBox_5->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        com_6->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        comboBox_6->clear();
        comboBox_6->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        pushButton_6->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        comboBox_14->clear();
        comboBox_14->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        com_13->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        com_18->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        comboBox_15->clear();
        comboBox_15->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        com_17->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        com_15->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        com_16->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        comboBox_16->clear();
        comboBox_16->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        comboBox_17->clear();
        comboBox_17->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        pushButton_14->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        pushButton_18->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        comboBox_18->clear();
        comboBox_18->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        pushButton_16->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        com_14->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        pushButton_13->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        pushButton_15->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        comboBox_13->clear();
        comboBox_13->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        pushButton_17->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        comboBox_22->clear();
        comboBox_22->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        pushButton_23->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        com_22->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        com_23->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        com_21->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        com_24->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        pushButton_24->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        comboBox_19->clear();
        comboBox_19->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        pushButton_21->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        comboBox_23->clear();
        comboBox_23->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        com_20->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        pushButton_20->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        pushButton_19->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        comboBox_20->clear();
        comboBox_20->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        com_19->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        comboBox_21->clear();
        comboBox_21->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        comboBox_24->clear();
        comboBox_24->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        pushButton_22->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        label_37->setText(QString());
        label_52->setText(QString());
        label_58->setText(QString());
        label_54->setText(QString());
        label_60->setText(QString());
        label_50->setText(QString());
        com_9->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        com_12->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        pushButton_7->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        com_10->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        comboBox_12->clear();
        comboBox_12->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        comboBox_11->clear();
        comboBox_11->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        pushButton_11->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        pushButton_9->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        com_7->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        pushButton_8->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        pushButton_10->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        comboBox_7->clear();
        comboBox_7->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        com_8->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        comboBox_10->clear();
        comboBox_10->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        pushButton_12->setText(QApplication::translate("alper", "RESET", 0, QApplication::UnicodeUTF8));
        comboBox_8->clear();
        comboBox_8->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        com_11->setText(QApplication::translate("alper", "COM", 0, QApplication::UnicodeUTF8));
        comboBox_9->clear();
        comboBox_9->insertItems(0, QStringList()
         << QApplication::translate("alper", "SCC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IAC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "DPP", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
        );
        dateTimeEdit->setDisplayFormat(QApplication::translate("alper", "dd/MM/yyyy     h:mm AP", 0, QApplication::UnicodeUTF8));
        info->setText(QApplication::translate("alper", "INFO:", 0, QApplication::UnicodeUTF8));
        lstimag->setText(QString());
        groupBox_5->setTitle(QApplication::translate("alper", "APPLICATIONS", 0, QApplication::UnicodeUTF8));
        fault_screen_button->setText(QApplication::translate("alper", "FAULT SCREEN", 0, QApplication::UnicodeUTF8));
        log_finder_button->setText(QApplication::translate("alper", "LOG SCREEN", 0, QApplication::UnicodeUTF8));
        usb_mount->setText(QApplication::translate("alper", "MOUNT USB", 0, QApplication::UnicodeUTF8));
        usb_unmount->setText(QApplication::translate("alper", "UNMOUNT USB", 0, QApplication::UnicodeUTF8));
        terminal->setText(QApplication::translate("alper", "OPEN TERMINAL", 0, QApplication::UnicodeUTF8));
        bag_finder_bt->setText(QApplication::translate("alper", "BAG FINDER", 0, QApplication::UnicodeUTF8));
        screenshot_bt->setText(QApplication::translate("alper", "SCREENSHOT", 0, QApplication::UnicodeUTF8));
        system_monitor->setText(QApplication::translate("alper", "SYSTEM MONITOR", 0, QApplication::UnicodeUTF8));
        crntmac->setText(QString());
        Creator_label->setText(QApplication::translate("alper", "Created by ALPER SAGLIK", 0, QApplication::UnicodeUTF8));
        silentmode_bt->setText(QString());
        FAULTS->setWindowTitle(QApplication::translate("alper", "                                                                                                       FAULT SCREEN", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("alper", "               START TIME                                  END TIME                          MV3D NO                                 EXPORT", 0, QApplication::UnicodeUTF8));
        label_12->setText(QString());
        save_flt_button->setText(QApplication::translate("alper", "EXPORT FAULT LOGS", 0, QApplication::UnicodeUTF8));
        faultstartdate->setDisplayFormat(QApplication::translate("alper", "ddd dd MMMM yyyy", 0, QApplication::UnicodeUTF8));
        faultenddate->setDisplayFormat(QApplication::translate("alper", "ddd dd MMMM yyyy", 0, QApplication::UnicodeUTF8));
        grep_mv3d_exp->clear();
        grep_mv3d_exp->insertItems(0, QStringList()
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0037", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0040", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0035", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0036", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0038", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0039", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0025", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0017", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0023", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0022", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0033", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0032", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0020", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0028", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0021", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0026", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0027", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0024", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0044", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0046", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0043", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0045", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0041", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0042", 0, QApplication::UnicodeUTF8)
        );
        QTableWidgetItem *___qtablewidgetitem = faulttable->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("alper", "MV3D NO", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = faulttable->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("alper", "FAULT CAUSE", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = faulttable->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("alper", "FAULT START", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = faulttable->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("alper", "FAULT END", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem4 = faulttable->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("alper", "DURATION", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(real_time_tab), QApplication::translate("alper", "REAL-TIME", 0, QApplication::UnicodeUTF8));
        label_13->setText(QApplication::translate("alper", "               START TIME                             END TIME                      MV3D NO                DISPLAY                      BROWSE FILE", 0, QApplication::UnicodeUTF8));
        label_14->setText(QString());
        fault_display_button->setText(QApplication::translate("alper", "DISPLAY", 0, QApplication::UnicodeUTF8));
        faultstartdate_disp->setDisplayFormat(QApplication::translate("alper", "ddd dd MMMM yyyy", 0, QApplication::UnicodeUTF8));
        faultenddate_disp->setDisplayFormat(QApplication::translate("alper", "ddd dd MMMM yyyy", 0, QApplication::UnicodeUTF8));
        fault_browser_button->setText(QApplication::translate("alper", "SEARCH", 0, QApplication::UnicodeUTF8));
        grep_mv3d_disp->clear();
        grep_mv3d_disp->insertItems(0, QStringList()
         << QApplication::translate("alper", "ALL", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0037", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0040", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0035", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0036", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0038", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0039", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0025", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0017", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0023", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0022", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0033", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0032", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0020", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0028", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0021", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0026", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0027", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0024", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0044", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0046", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0043", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0045", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0041", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0042", 0, QApplication::UnicodeUTF8)
        );
        QTableWidgetItem *___qtablewidgetitem5 = disp_faulttable->horizontalHeaderItem(0);
        ___qtablewidgetitem5->setText(QApplication::translate("alper", "DATE", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem6 = disp_faulttable->horizontalHeaderItem(1);
        ___qtablewidgetitem6->setText(QApplication::translate("alper", "MV3D NO", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem7 = disp_faulttable->horizontalHeaderItem(2);
        ___qtablewidgetitem7->setText(QApplication::translate("alper", "FAULT CAUSE", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem8 = disp_faulttable->horizontalHeaderItem(3);
        ___qtablewidgetitem8->setText(QApplication::translate("alper", "FAULT START", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem9 = disp_faulttable->horizontalHeaderItem(4);
        ___qtablewidgetitem9->setText(QApplication::translate("alper", "FAULT END", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem10 = disp_faulttable->horizontalHeaderItem(5);
        ___qtablewidgetitem10->setText(QApplication::translate("alper", "DURATION", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(dsplay_tab), QApplication::translate("alper", "DISPLAY", 0, QApplication::UnicodeUTF8));
        bagdec->setWindowTitle(QApplication::translate("alper", "                                                                                                                                                                                       LOG SCREEN", 0, QApplication::UnicodeUTF8));
        grep_mv3d->clear();
        grep_mv3d->insertItems(0, QStringList()
         << QApplication::translate("alper", "3D0037", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0040", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0035", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0036", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0038", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0039", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0025", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0017", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0023", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0022", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0033", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0032", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0020", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0028", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0021", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0026", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0027", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0024", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0044", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0046", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0043", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0045", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0041", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "3D0042", 0, QApplication::UnicodeUTF8)
        );
        grepperbox->clear();
        grepperbox->insertItems(0, QStringList()
         << QApplication::translate("alper", "Bag Decision", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "Array Test", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "Flow Switch", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "HVPS Arc", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "Bad Detectors", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "IQTK Log", 0, QApplication::UnicodeUTF8)
        );
        grepdate->setDisplayFormat(QApplication::translate("alper", "dd MMM yyyy", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("alper", "MV3D NO", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("alper", "QUICK SEARCH", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("alper", "DATE", 0, QApplication::UnicodeUTF8));
        call_button->setText(QApplication::translate("alper", "CALL", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("alper", "LIST", 0, QApplication::UnicodeUTF8));
        label_5->setText(QString());
        label_6->setText(QApplication::translate("alper", "MANUEL SEARCH", 0, QApplication::UnicodeUTF8));
        manuelactive->setText(QApplication::translate("alper", "MANUEL", 0, QApplication::UnicodeUTF8));
        manuelcombo->clear();
        manuelcombo->insertItems(0, QStringList()
         << QApplication::translate("alper", "DIAGSERV", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "BHS LOG", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "BMS LOG", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "BIT LOG", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "SCS LOG", 0, QApplication::UnicodeUTF8)
        );
        label_10->setText(QApplication::translate("alper", "LOGS", 0, QApplication::UnicodeUTF8));
        log_selection_box->clear();
        log_selection_box->insertItems(0, QStringList()
         << QApplication::translate("alper", "Last Modified Logs", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "Detailed Logs", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("alper", "All Logs", 0, QApplication::UnicodeUTF8)
        );
        quickactive->setText(QApplication::translate("alper", "QUICK", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("alper", "SEARCH METHOD", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class alper: public Ui_alper {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ALPER_H
